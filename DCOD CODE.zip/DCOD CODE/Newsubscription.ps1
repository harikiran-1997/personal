﻿$ClientSPapplicationId = "4ccbea72-0082-450a-9328-267aa9b8cff3"
$ClientSPSecret = "VFM8Q~-7oObwMz98SQq7Vu1Chc4.JuQCNO4VsaLj"
$ClientTenantID = "83030971-88c6-461e-8552-c8ee9d60e0b7"
$ClientSubscriptionID = "72250b51-de0a-41fd-9844-959c79c3bda6"
$adminobjectid = "c1f01848-99ac-472a-9cfb-d1e7a42198b2"
$readerobjectid = "d0dc4a0f-fb6f-4eec-8744-51bebd4774ce"
$domaincode = "DQA"
$customernumber = "99900001"
$billingscope = "/providers/Microsoft.Billing/billingAccounts/52677160/enrollmentAccounts/262969"
$networkid = "050000"

$clientspobjectid = "1d315a43-f65e-42cf-94cc-59cf2826b487"

$securesecret = $ClientSPSecret | ConvertTo-SecureString -AsPlainText -Force
$cred = New-Object -TypeName PSCredential -ArgumentList $ClientSPApplicationId, $securesecret
Clear-AzContext -Force
Connect-AzAccount -ServicePrincipal -Credential $cred -Tenant $ClientTenantID

$aliasname = "DCT"+$domaincode+"-"+$customernumber+"-"+$networkid+ "-alias"
$subscriptionName = "DCT"+$domaincode+"-"+$customernumber+"-"+$networkid
<#
$subdetails = Get-AzSubscriptionAlias -AliasName $aliasname -ErrorAction SilentlyContinue
 if($subdetails){
    $subscriptionid = (Get-AzSubscription -SubscriptionName $subscriptionName).id
    Write-Host "##vso[task.setvariable variable=clientsubid;issecret=true]"$subscriptionid
}

else{

    #Create a new subscription
    Write-Host "create a new subscription"
    $newsubscriptionalias = New-AzSubscriptionAlias -AliasName $aliasname -SubscriptionName $subscriptionName -BillingScope $billingscope -Workload "Production"
    $clientsubscriptionid = $newsubscriptionalias.SubscriptionId
    Write-Host "##vso[task.setvariable variable=clientsubid]$clientsubscriptionid"
}

#>
 
    $adminrole = New-AzRoleAssignment -ObjectId $adminobjectid -RoleDefinitionName "Contributor" -Scope "/subscriptions/3eaac90f-5478-4814-9fe4-731f85e2a32d" -ErrorAction SilentlyContinue
    start-sleep -s 60

#Assign Reader Role to Automation Reader Group
$getreaderrole = Get-AzRoleAssignment -ObjectId $readerobjectid -RoleDefinitionName "Reader" -Scope "/subscriptions/3eaac90f-5478-4814-9fe4-731f85e2a32d" -ErrorAction SilentlyContinue
if($getreaderrole){
    Write-Host "Reader role is already assigned"
}
else{
    $readerrole = New-AzRoleAssignment -ObjectId $readerobjectid -RoleDefinitionName "Reader" -Scope "/subscriptions/3eaac90f-5478-4814-9fe4-731f85e2a32d" -ErrorAction SilentlyContinue
    start-sleep -s 60
}
