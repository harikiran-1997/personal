# .NET Core App with Integrated Security in Docker

## Prerequisites

- Docker
- SQL Server instance with integrated security enabled
- Domain Controller (AD acting as Key Distribution Server)

## Setup

1. **Generate Keytab File**

    ```bash
    ktutil
    ktutil: add_entry -password -p myUserName@MY.COMPANY.LOCAL -k 1 -e RC4-HMAC
    # Enter password when prompted
    ktutil: write_kt myUserName.keytab
    ktutil: exit
    ```

2. **Build Docker Image**

    ```bash
    docker build -t my-secure-app .
    ```

3. **Run Docker Container**

    ```bash
    docker run -d --name secure-app-container my-secure-app
    ```

4. **Attach to Docker Container to See Output**

    ```bash
    docker attach secure-app-container
    ```

## Handling Kerberos Ticket Expiration

Ensure to handle Kerberos ticket and keytab expiration as described in the main instructions.

## Note

Modify the connection string, `krb5.conf`, and other configurations as per your environment settings.
