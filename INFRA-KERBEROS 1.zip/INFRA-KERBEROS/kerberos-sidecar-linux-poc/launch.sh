#!/bin/bash

kinit myUserName -k -t /app/myUserName.keytab
dotnet MyApplication.dll
