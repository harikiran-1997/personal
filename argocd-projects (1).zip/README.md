# Hudson Bay ArgoCD repository for Continuous Deployment

Repository holds the ArgoCD configurations and application configurations that are used in provisioning the application to the kubernetes cluster in Devops subscription.

## ArgoCD Configuration list in Hudson Bay currently

1. [HBC Base Applications](./apps/base/)
2. [Dev Environment - HBC Applications](./environments/dev/)
3. [QA Environment - HBC Applications](./environments/qa/)
4. [STAGING Environment - HBC Applications](./environments/qa/)
5. [PROD Environment - HBC Applications](./environments/prod/)
6. [ArgoCD App of Apps - Dev](./argo%20applications/dev/)
7. [ArgoCD App of Apps - QA](./argo%20applications/qa/)
8. [ArgoCD App of Apps - Prod](./argo%20applications/prod/)
9. [ArgoCD root projects](./projects/)
10. [ArgoCD root repositories](./repos/)
11. [ArgoCD manifest templates for reference](./argo%20templates/)
12. [ArgoCD User Management](./argousermanagement/)


## Authors

Module is maintained by **HBCM DevOps**

## Copyright

Copyright @ HudsonBayCapital. All Rights Reserved.