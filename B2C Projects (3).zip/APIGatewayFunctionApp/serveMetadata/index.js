/*
 * Function:       serveMetadata
 * Purpose:        Returns the OIDC configuration/metadata used to find JWK(s) used to sign APIGateway requests
 * Author:         Robin Frousheger (Telstra Purple)
 * Date Created:   2022-02-18
 */

// Always
'use strict';

// NPM Modules setup

// Start Azure Application Insights before doing anything else
const applicationinsights = require('applicationinsights');
applicationinsights.setup()
    .setSendLiveMetrics(process.env.appInsights_liveMetrics)
    .start();

// Use AAD Managed Service Identity to authenticate AppInsights ingestion
const { DefaultAzureCredential } = require('@azure/identity');
const azureCredential = new DefaultAzureCredential();
applicationinsights.defaultClient.config.aadTokenCredential = azureCredential;

const { hashAlgorithms } = require('../b2c-shared');

const cacheControl = process.env.cacheControl || 'max-age=900';

/*
 * Main Function Start
 */

module.exports = async function (context) {
    context.log.verbose('OIDC metadata requested.');

    // Construct issuer/jwks url from URL this function is hosted from, keeping only the origin
    let base_url;

    if (typeof context.bindings.req.headers === 'object' &&
        context.bindings.req.headers &&
        typeof context.bindings.req.headers['x-forwarded-host'] === 'string' &&
        context.bindings.req.headers['x-forwarded-host'].endsWith('donateblood.com.au')
    ) {
        base_url = new URL('https://' + context.bindings.req.headers['x-forwarded-host']);
    } else {
        base_url = new URL(new URL(context.bindings.req.originalUrl).origin);
    }

    context.log.verbose('Using base url:', base_url.href);

    const issuer_url = new URL(base_url);
    issuer_url.pathname = process.env.jwt_issuer || 'v1/oauth';

    const jwks_uri = new URL(base_url);
    jwks_uri.pathname = process.env.jwks_endpoint || 'v1/oauth/keys';

    context.bindings.res = {
        status: 200,
        headers: {
            'Cache-Control': cacheControl,
            'Content-Type': 'application/json'
        },
        body: {
            issuer: issuer_url.href,
            jwks_uri: jwks_uri.href,
            id_token_signing_alg_values_supported: Object.keys(hashAlgorithms)
        }
    };
};
