/*
 * Function:       serveJWKS
 * Purpose:        Returns the JSON Web Keys used to sign APIGateway requests
 * Author:         Robin Frousheger (Telstra Purple)
 * Date Created:   2022-02-18
 */

// Always
'use strict';

// NPM Modules setup

// Start Azure Application Insights before doing anything else
const applicationinsights = require('applicationinsights');
applicationinsights.setup()
    .setSendLiveMetrics(process.env.appInsights_liveMetrics)
    .start();

// Use AAD Managed Service Identity to authenticate AppInsights ingestion
const { DefaultAzureCredential } = require('@azure/identity');
const azureCredential = new DefaultAzureCredential();
applicationinsights.defaultClient.config.aadTokenCredential = azureCredential;

const { parseKeyVaultKeyIdentifier, KeyClient } = require('@azure/keyvault-keys');
const { contextPropagatingHttpTrigger, ecSignatureAlgorithms } = require('../b2c-shared');

const cacheControl = process.env.cacheControl || 'max-age=900';

/*
 * Main Function Start
 */

const httpTrigger = async function (context) {
    const keyDetails = parseKeyVaultKeyIdentifier(process.env.keyvaultUrl);
    const keyClient = new KeyClient(keyDetails.vaultUrl, azureCredential);

    const keys = [];

    const functionResponse = {
        status: 200,
        headers: {
            'Cache-Control': cacheControl,
            'Content-Type': 'application/json'
        },
        body: {
            keys: null
        }
    };

    try {
        context.log.verbose('JWKS requested.');

        // Retrieve all versions of the specified key and return as a JWKS
        for await (const keyProperies of keyClient.listPropertiesOfKeyVersions(keyDetails.name)) {
            const { key } = await keyClient.getKey(keyProperies.name, { version: keyProperies.version });

            const jwk = {
                kid: keyProperies.version,
                kty: key.kty,
                key_ops: ['sign', 'verify'],
                use: 'sig',
            };

            /*
             * Currently unused properties
             * d:  RSA Private Key Exponent or EC Private Key D component
             * dp: RSA Private Key Parameter
             * dq: RSA Private Key Parameter
             * k:  Symmetric Key
             * p:  RSA Secret Prime
             * q:  RSA Secret Prime, with p < q
             * qi: RSA Private Key Parameter
             */

            switch (key.kty) {
                case 'RSA':
                    jwk.alg = 'RS256';
                    ['e', 'n'].forEach((property) => { jwk[property] = key[property].toString('base64url'); });
                    break;
                case 'EC':
                    jwk.alg = ecSignatureAlgorithms[key.crv];
                    // This is a bit of a cheat, as a normal string 'toString' doesn't use the base64url argument e.g. crv property :)
                    ['crv', 'x', 'y'].forEach((property) => { jwk[property] = key[property].toString('base64url'); });
                    break;
                default:
                    break;
            }

            keys.push(jwk);
        }
    } catch (error) {
        functionResponse.status = 500;
        functionResponse.body = error.toString();
    }

    context.log.info(`Retrieved ${keys.length} key(s)`);
    context.log.verbose('Keys:', JSON.stringify(keys));

    functionResponse.body.keys = keys;
    context.bindings.res = functionResponse;
};

module.exports = async function (context) {
    return contextPropagatingHttpTrigger(context, applicationinsights, httpTrigger);
};
