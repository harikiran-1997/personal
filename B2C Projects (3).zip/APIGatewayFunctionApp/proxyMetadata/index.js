/*
 * Function:       proxyMetada
 * Purpose:        Proxies the metadata from APIGateway AWS Lamba through to B2C
 * Author:         Robin Frousheger (Telstra Purple)
 * Date Created:   2022-02-25
 */

// Always
'use strict';

// NPM Modules setup

// Start Azure Application Insights before doing anything else
const applicationinsights = require('applicationinsights');
applicationinsights.setup()
    .setSendLiveMetrics(process.env.appInsights_liveMetrics)
    .start();

// Use AAD Managed Service Identity to authenticate AppInsights ingestion
const { DefaultAzureCredential } = require('@azure/identity');
const azureCredential = new DefaultAzureCredential();
applicationinsights.defaultClient.config.aadTokenCredential = azureCredential;

const { format } = require('node:util');

const { globalAgent } = require('node:https');
globalAgent.keepAlive = true;

const axios = require('axios');
axios.httpsAgent = globalAgent;

const { contextPropagatingHttpTrigger } = require('../b2c-shared');

const cacheControl = process.env.cacheControl || 'max-age=900';

/*
 * Main Function Start
 */

const httpTrigger = async function (context) {
    const metadata_url = new URL(process.env.metadata_endpoint);

    // Construct jwks url from URL this function is hosted from, keeping only the origin
    let jwks_proxy_url;

    if (typeof context.bindings.req.headers === 'object' &&
        context.bindings.req.headers &&
        typeof context.bindings.req.headers['x-forwarded-host'] === 'string' &&
        context.bindings.req.headers['x-forwarded-host'].endsWith('donateblood.com.au')
    ) {
        jwks_proxy_url = new URL('https://' + context.bindings.req.headers['x-forwarded-host']);
    } else {
        jwks_proxy_url = new URL(new URL(context.bindings.req.originalUrl).origin);
    }

    jwks_proxy_url.pathname = process.env.proxy_prefix || 'proxy/idp';

    context.log.verbose('Using base proxy url:', jwks_proxy_url.href);

    const functionResponse = {
        status: 200,
        headers: {
            'Cache-Control': cacheControl,
            'Content-Type': 'application/json'
        },
        body: {}
    };

    try {
        context.log.verbose('Proxy metadata requested. URL:', metadata_url.href);

        // Collect metadata from APIGateway AWS Lamba
        const metadata = await axios.get(metadata_url.href, {}, {
            headers: {
                'Content-Type': 'application/json'
            }
        })
            .then(function (response) {
                context.log.verbose(response);

                // Adjust cache-control with any received cache-control header
                if (typeof response.headers === 'object' &&
                    'cache-control' in response.headers &&
                    typeof response.headers['cache-control'] === 'string' &&
                    response.headers['cache-control']
                ) {
                    context.log.verbose('Using received cache-control header:', response.headers['cache-control']);
                    functionResponse.headers['Cache-Control'] = response.headers['cache-control'];
                }

                context.log.info('SUCCEEDED: Metadata received:', response.status, response.statusText, JSON.stringify(response.data));
                return response.data;
            })
            .catch(function (error) {
                // Something happened in setting up the request that triggered an Error
                context.log.error(error.status, error.name, error.message);
                functionResponse.body.developerMessage = format(error.status, error.name, error.message);
                functionResponse.status = functionResponse.body.status = 409;
            });

        functionResponse.body = metadata;

        // Adjust metadata with modified jwks_uri with us as proxy
        if (typeof metadata === 'object' &&
            'jwks_uri' in metadata &&
            typeof metadata.jwks_uri === 'string' &&
            metadata.jwks_uri
        ) {
            const jwks_uri = new URL(metadata.jwks_uri);
            jwks_proxy_url.pathname += jwks_uri.pathname;
            functionResponse.body.jwks_uri = jwks_proxy_url.href;
        }
    } catch (error) {
        context.log.error('FAILED: An unexpected error has occurred:', JSON.stringify(error));
        functionResponse.body.developerMessage = format('FAILED: An unexpected error has occurred:', JSON.stringify(error));
        functionResponse.status = functionResponse.body.status = 409;
    }

    context.log.verbose('Response to be sent back:', JSON.stringify(functionResponse));

    context.bindings.res = functionResponse;
};

module.exports = async function (context) {
    return contextPropagatingHttpTrigger(context, applicationinsights, httpTrigger);
};
