/*
 * Function:       CallFirebaseAnalyticsGCFHttpTrigger
 * Purpose:        Calls the Firebase Analytics Google Cloud Function endpoint to post the analytics data in json format.
 * Author:         Adeel Nasir (Kloud)
 * Date Created:   August 19th 2019
 */

// Always
'use strict';

// NPM Modules setup

// Start Azure Application Insights before doing anything else
const applicationinsights = require('applicationinsights');
applicationinsights.setup()
    .setSendLiveMetrics(process.env.appInsights_liveMetrics)
    .start();

// Use AAD Managed Service Identity to authenticate AppInsights ingestion
const { DefaultAzureCredential } = require('@azure/identity');
const azureCredential = new DefaultAzureCredential();
applicationinsights.defaultClient.config.aadTokenCredential = azureCredential;

const { format } = require('node:util');

const { globalAgent } = require('node:https');
globalAgent.keepAlive = true;

const axios = require('axios');
axios.httpsAgent = globalAgent;

const { contextPropagatingHttpTrigger, verifyBodyParameters } = require('../b2c-shared');

const cacheControl = process.env.cacheControl || 'no-store';

/*
 * Main Function Start
 */

const httpTrigger = async function (context) {
    const bodyParameters = {
        screen_name: null,
        tracking_id: null
    };

    const functionResponse = {
        status: 200,
        headers: {
            'Cache-Control': cacheControl,
            'Content-Type': 'application/json'
        },
        body: {
            version: '2.0.0',
            status: 200,
            userMessage: null,

            // Debug Mode Return Values
            code: null,
            developerMessage: null,
            moreInfo: null,
            requestId: context.invocationId
        }
    };

    try {
        const apiKey = process.env.gcf_apiKey;
        const apiUrl = process.env.gcf_endPoint;

        const timestamp = new Date;

        context.log.verbose('Received request body:', JSON.stringify(context.bindings.req.body));

        /*
         * **********************************
         * Validate the incoming Request data
         * **********************************
         */

        verifyBodyParameters(context, bodyParameters);

        context.log.info('Received parameters:', JSON.stringify(bodyParameters));

        // Populate the json data object
        const data = {
            api_key: apiKey,
            user_pseudo_id: bodyParameters.tracking_id,
            event_date: timestamp.toISOString().substring(0, 10).replace(/-/g, ''),
            event_timestamp: timestamp.valueOf(),
            event_name: 'screen_view',
            key: 'firebase_screen_class',
            value: {
                string_value: bodyParameters.screen_name,
                int_value: null,
                float_value: null,
                double_value: null
            },
            event_value_in_usd: null
        };

        // Only continue if body parameters have been received
        if (Object.values(bodyParameters).filter((value) => value !== null).length === Object.keys(bodyParameters).length) {
            context.log.info('Calling Firebase analytics endpoint:', apiUrl);

            // Attempt to call Firebase Analytics GCF endpoint
            await axios.post(apiUrl, data)
                .then(function (response) {
                    context.log.verbose(response);
                    context.log.info('SUCCEEDED: API call:', response.status, response.statusText, JSON.stringify(response.data));
                    functionResponse.statusCode = functionResponse.body.status = response.status;
                })
                .catch(function (error) {
                    // Something happened in setting up the request that triggered an Error
                    context.log.error(error.status, error.name, error.message);
                    functionResponse.body.developerMessage = format(error.status, error.name, error.message);
                    functionResponse.status = functionResponse.body.status = 409;
                });
        }
    } catch (error) {
        context.log.error('FAILED: An unexpected error has occurred:', JSON.stringify(error));
        functionResponse.body.developerMessage = format('FAILED: An unexpected error has occurred:', JSON.stringify(error));
        functionResponse.status = functionResponse.body.status = 409;
    }

    context.log.verbose('Response to be sent back:', JSON.stringify(functionResponse));

    context.bindings.res = functionResponse;
};

module.exports = async function (context) {
    return contextPropagatingHttpTrigger(context, applicationinsights, httpTrigger);
};
