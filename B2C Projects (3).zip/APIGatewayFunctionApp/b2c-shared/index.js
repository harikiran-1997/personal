/*
 * Module:         b2c-shared
 * Purpose:        Module of shared code to streamline API functions
 * Author:         Robin Frousheger (Telstra Purple)
 * Date Created:   2022-02-24
 */

// Always
'use strict';

const { format } = require('node:util');

/*
 * As per https://github.com/microsoft/ApplicationInsights-node.js#azure-functions
 * To link request and dependency calls correctly
 */
module.exports.contextPropagatingHttpTrigger = async function (context, applicationinsights, httpTrigger) {
    // Start an AppInsights Correlation Context using the provided Function context
    const correlationContext = applicationinsights.startOperation(context, context.bindings.req);

    // Wrap the Function runtime with correlationContext
    return applicationinsights.wrapWithCorrelationContext(async () => {
        const startTime = Date.now(); // Start trackRequest timer

        // Run the Function
        await httpTrigger(context);

        const duration = Date.now() - startTime;

        // Track Request on completion
        applicationinsights.defaultClient.trackRequest({
            name: context.bindings.req.method + ' ' + context.bindings.req.url,
            resultCode: context.bindings.res.status,
            success: true,
            url: context.bindings.req.url,
            duration: duration,
            id: correlationContext.operation.parentId
        });
        applicationinsights.defaultClient.flush();
    }, correlationContext)();
};

// Define the mapping of EC curve to signature algorithm
const ecSignatureAlgorithms = {
    'P-256': 'ES256',
    'P-384': 'ES385',
    'P-521': 'ES512',
};

module.exports.ecSignatureAlgorithms = ecSignatureAlgorithms;

// Define the possible signature algorithm --> hash algorithm mappings
const hashAlgorithms = {
    'RS256': 'SHA256',
    'RS384': 'SHA384',
    'RS512': 'SHA512',
    'ES256': 'SHA256',
    'ES384': 'SHA384',
    'ES512': 'SHA512',
    'ES256K': 'SHA256',
    'PS256': 'SHA256',
    'PS384': 'SHA384',
    'PS512': 'SHA512',
    'HS256': 'SHA256',
    'HS384': 'SHA384',
    'HS512': 'SHA512',
};

module.exports.hashAlgorithms = hashAlgorithms;

module.exports.verifyBodyParameters = function (context, bodyParameters) {
    if (typeof context.bindings.req.body !== 'object' ||
        !context.bindings.req.body
    ) {
        context.log.error('InvalidParameter: Body is missing.');
        throw new Error('InvalidParameter: Body is missing.');
    } else {
        Object.keys(bodyParameters).forEach(parameter => {
            if (typeof context.bindings.req.body[parameter] === 'string' &&
                context.bindings.req.body[parameter]
            ) {
                bodyParameters[parameter] = context.bindings.req.body[parameter];
            } else {
                context.log.error('InvalidParameter: %s is missing.', parameter);
                throw new Error(format('InvalidParameter: %s is missing.', parameter));
            }
        });
    }
};
