const gulp = require('gulp');
const log = require('fancy-log');

gulp.task('build', done => {

    const destPath = './dist';

    log('******************** START *************************');
    log('START: Gulp starting for api_gateway_function_app.');

    /*
     * ********************************************* STEP 1 ******************************* //
     * ------------------------------------------------------------------------------------ //
     * ---------- Copy the required files for root folder ------------------------------------- //
     * -- Required to run 'func azure functionapp publish apigateway-env' command vis VS code-- //
     * ------------------------------------------------------------------------------------ //
     */

    log('-----------------------------------------');

    log('START - Copy the files for api_gateway_function_app.');
    gulp.src(
        [
            './**',         //Select all json files
            '!./dist',  //Ignore the dist folder
            '!./dist/**', //Ignore the dist folder content
            '!./Gulpfile.js', //Ignore the gulpfile.js
            '!./*.ps1', //Ignore the PS deploy file
            '!./local.settings.*' // Eww, do not include the local settings!
        ])
        .pipe(gulp.dest(`${destPath}`));

    log('END - Copy the files for api_gateway_function_app on root folder.');

    log('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~');

    log('END: gulping for api_gateway_function_app.');
    log('******************** END *************************');

    done();
});
