/*
 * Function:       CallActivatePendingOSCUserHttpTrigger
 * Purpose:        Calls the API gateway endpoint which internally calls OSC to activate pending OSC User.
 * Author:         Adeel Nasir (Kloud)
 * Date Created:   July 26th 2019
 */

// Always
'use strict';

// NPM Modules setup

// Start Azure Application Insights before doing anything else
const applicationinsights = require('applicationinsights');
applicationinsights.setup()
    .setSendLiveMetrics(process.env.appInsights_liveMetrics)
    .start();

// Use AAD Managed Service Identity to authenticate AppInsights ingestion
const { DefaultAzureCredential } = require('@azure/identity');
const azureCredential = new DefaultAzureCredential();
applicationinsights.defaultClient.config.aadTokenCredential = azureCredential;

const { format } = require('node:util');
const { createHash, randomUUID } = require('node:crypto');

const { globalAgent } = require('node:https');
globalAgent.keepAlive = true;

const axios = require('axios');
axios.httpsAgent = globalAgent;

const { parseKeyVaultKeyIdentifier, CryptographyClient, KeyClient } = require('@azure/keyvault-keys');

const jsonwebtoken = require('jsonwebtoken');

const { contextPropagatingHttpTrigger, ecSignatureAlgorithms, hashAlgorithms, verifyBodyParameters } = require('../b2c-shared');

const cacheControl = process.env.cacheControl || 'no-store';

/*
 * Main Function Start
 */

const httpTrigger = async function (context) {
    const bodyParameters = {
        extension_ContactId: null,
        objectId: null,
        userPrincipalName: null
    };

    const functionResponse = {
        status: 409,
        headers: {
            'Cache-Control': cacheControl,
            'Content-Type': 'application/json'
        },
        body: {
            version: '2.0.0',
            status: 409,
            userMessage: 'We weren\'t able to complete your last request. Please try again later.',

            // Debug Mode Return Values
            code: null,
            developerMessage: null,
            moreInfo: null,
            requestId: context.invocationId
        }
    };

    try {
        /*
         * Get configuration data from environment variables
         */

        const apiGatewaySecretKey = process.env.apiGatewaySecretKey;
        const apiUrl = process.env.userActivation_endPoint;

        const keyDetails = parseKeyVaultKeyIdentifier(process.env.keyVaultUrl);
        const keyClient = new KeyClient(keyDetails.vaultUrl, azureCredential);

        const metadata_endpoint = process.env.metadata_endpoint;

        // Construct issuer from URL where this function was called, keeping only the origin
        const issuer_url = new URL(new URL(context.bindings.req.originalUrl).origin);
        issuer_url.pathname = process.env.jwt_issuer || 'v1/oauth';

        const defaultSignatureAlgorithm = process.env.signatureAlgorithm || 'HS256';
        const signatureMethod = process.env.signatureMethod || 'secret';

        // Adding/Subtracting timestampOffset to 'not-before' and 'expires' to allow for time difference between servers
        const timestampOffset = process.env.timestampOffset || 5 * 60 * 1000; // Milliseconds

        // Token expires 20 minutes after the 'issued-at-time'
        const tokenExpiry = process.env.timestampOffset || 20 * 60 * 1000; // Milliseconds

        /*
         * Validate the incoming Request data
         */

        context.log.verbose('Received request body:', JSON.stringify(context.bindings.req.body));

        verifyBodyParameters(context, bodyParameters);

        context.log.info('Received parameters:', JSON.stringify(bodyParameters));

        /*
         * Attempt to find the correct audience and signature algorithm
         */

        let audience = null;
        let signatureAlgorithm = defaultSignatureAlgorithm;

        const metadata = await axios.get(metadata_endpoint, {}, {
            headers: {
                'Content-Type': 'application/json'
            }
        })
            .then(function (response) {
                context.log.verbose(response);
                context.log.info('SUCCEEDED: Metadata received:', response.status, response.statusText, JSON.stringify(response.data));
                return response.data;
            })
            .catch(function (error) {
                // Something happened in setting up the request that triggered an Error
                context.log.error(error.status, error.name, error.message);
                functionResponse.body.developerMessage = format(error.status, error.name, error.message);
                functionResponse.status = functionResponse.body.status = 409;
            });

        if (typeof metadata === 'object' &&
            'issuer' in metadata &&
            typeof metadata.issuer === 'string' &&
            metadata.issuer
        ) {
            audience = metadata.issuer;
        }

        context.log.verbose('Found audience:', JSON.stringify(audience));

        if (signatureMethod === 'secret') {
            signatureAlgorithm = 'HS256';
        } else {
            // If the configured default algorithm is NOT in the response set, use the first from the response
            if (typeof metadata === 'object' &&
                'id_token_signing_alg_values_supported' in metadata &&
                typeof metadata.id_token_signing_alg_values_supported === 'object' &&
                metadata.id_token_signing_alg_values_supported
            ) {
                if (!metadata.id_token_signing_alg_values_supported.includes(signatureAlgorithm)) {
                    signatureAlgorithm = metadata.id_token_signing_alg_values_supported[0];

                    context.log.verbose('Using signatureAlgorithm:', JSON.stringify(signatureAlgorithm));
                }
            }
        }

        // Only continue if body parameters have been received and an audience found
        if (Object.values(bodyParameters).filter((value) => value !== null).length === Object.keys(bodyParameters).length &&
            audience !== null
        ) {
            // 'issued-at-time'
            const timestamp = new Date;
            const tokenIssuedInSeconds = Math.floor(timestamp.valueOf() / 1000);

            // Adding/Subtracting timestampOffset to 'not-before' and 'expires' to allow for time difference between servers
            const notBeforeInSeconds = Math.floor((timestamp.valueOf() - timestampOffset) / 1000);
            const tokenExpiryInSeconds = Math.floor((timestamp.valueOf() + tokenExpiry + timestampOffset) / 1000);

            const jwtHeader = {
                typ: 'JWT'
            };

            const jwtPayload = {
                aud: audience,
                iss: issuer_url.href,
                contact_id: bodyParameters.extension_ContactId,
                object_id: bodyParameters.objectId,
                user_principal_name: bodyParameters.userPrincipalName,
                nbf: notBeforeInSeconds,
                iat: tokenIssuedInSeconds,
                exp: tokenExpiryInSeconds,
                jti: randomUUID()
            };

            let jwt;

            if (signatureMethod === 'secret') {
                // Push the key id and algorithm into the header
                jwtHeader.kid = signatureMethod;
                jwtHeader.alg = signatureAlgorithm;

                context.log.verbose('Using signatureAlgorithm:', JSON.stringify(signatureAlgorithm));

                context.log.verbose('Signing with secretKey');
                jwt = jsonwebtoken.sign(jwtPayload, apiGatewaySecretKey);
            } else {
                // Get the signing key used to sign the hash/digest
                context.log.verbose('Get key:', keyDetails.name);
                const key = await keyClient.getKey(keyDetails.name);

                context.log.verbose('Key Details:', key);

                if (key.keyType === 'EC') {
                    signatureAlgorithm = ecSignatureAlgorithms[key.key.crv];
                }

                // Push the key id and algorithm into the header
                jwtHeader.kid = key.properties.version;
                jwtHeader.alg = signatureAlgorithm;

                context.log.verbose('Using signatureAlgorithm:', JSON.stringify(signatureAlgorithm));

                // Create JWT data: 'header'.'payload'
                const jwtData = format('%s.%s', Buffer.from(JSON.stringify(jwtHeader)).toString('base64url'), Buffer.from(JSON.stringify(jwtPayload)).toString('base64url'));

                // Create hash from JWT data
                const hash = createHash(hashAlgorithms[signatureAlgorithm]).update(jwtData).digest();
                context.log.verbose('Hash generated:', hash);

                // Get the client to remotely sign the data
                context.log.verbose('Get client:', key);
                const client = new CryptographyClient(key, azureCredential);

                // Call key vault to sign the data with the key securely
                context.log.verbose('Get signature:', client);
                const jwtSignature = await client.sign(jwtHeader.alg, hash);

                // Append the signature so we end up with: 'header'.'payload'.'signature'
                jwt = format('%s.%s', jwtData, Buffer.from(jwtSignature.result).toString('base64url'));
            }

            context.log.verbose('JWT signed:', jwt);

            context.log.info('Calling user activation endpoint:', apiUrl);

            // Attempt to call user activation endpoint
            await axios.post(apiUrl, {}, {
                headers: {
                    Authorization: 'Bearer ' + jwt
                }
            })
                .then(function (response) {
                    context.log.verbose(response);
                    context.log.info('SUCCEEDED: User activated successfully:', response.status, response.statusText, JSON.stringify(response.data));
                    functionResponse.statusCode = functionResponse.body.status = response.status;
                })
                .catch(function (error) {
                    // Something happened in setting up the request that triggered an Error
                    context.log.error(error.status, error.name, error.message);
                    functionResponse.body.developerMessage = format(error.status, error.name, error.message);
                    functionResponse.status = functionResponse.body.status = 409;
                });
        }
    } catch (error) {
        context.log.error('FAILED: An unexpected error has occurred:', JSON.stringify(error));
        functionResponse.body.developerMessage = format('FAILED: An unexpected error has occurred:', JSON.stringify(error));
        functionResponse.status = functionResponse.body.status = 409;
    }

    context.log.verbose('Response to be sent back:', JSON.stringify(functionResponse));

    context.bindings.res = functionResponse;
};

module.exports = async function (context) {
    return contextPropagatingHttpTrigger(context, applicationinsights, httpTrigger);
};
