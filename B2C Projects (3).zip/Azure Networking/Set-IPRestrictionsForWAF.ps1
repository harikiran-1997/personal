#Requires -Version 5
#Requires -Module Az.Accounts
#Requires -Module Az.Websites

[CmdletBinding(PositionalBinding = $false)]

Param (
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [ValidateSet("bld", "dev", "dv2", "tst", "uat", "stg")] #,"prd" # Don't automatically update prod, be carefull!
    [string]
    $Environment = "uat",

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    # Apigateway and oscapi are not currently passing through the ARCL WAF
    # They cannot current be IP restricted due to OSC not publishing their source IP list
    # We could automate the inclusion/update of Azure AD/B2C IP ranges, but not worth it due to the OSC point above
    [ValidateSet("arcbsadmin", "authbroker")] #,"apigateway","oscapi"
    [string]
    $Application = "authbroker",

    [ValidateRange(100, [int]::MaxValue - 101)]
    [int]
    $StartingPriority = 100
)

Set-StrictMode -Version Latest
$ErrorActionPreference = [System.Management.Automation.ActionPreference]::Stop

$ARCBS_WAF_Addresses = @(
    @{CIDR = "45.60.0.0/16"; Description = "Incapsula WAF"}
    @{CIDR = "45.64.64.0/22"; Description = "Incapsula WAF"}
    @{CIDR = "45.223.0.0/16"; Description = "Incapsula WAF"}
    @{CIDR = "103.28.248.0/22"; Description = "Incapsula WAF"}
    @{CIDR = "107.154.0.0/16"; Description = "Incapsula WAF"}
    @{CIDR = "149.126.72.0/21"; Description = "Incapsula WAF"}
    @{CIDR = "185.11.124.0/22"; Description = "Incapsula WAF"}
    @{CIDR = "192.230.64.0/18"; Description = "Incapsula WAF"}
    @{CIDR = "198.143.32.0/19"; Description = "Incapsula WAF"}
    @{CIDR = "199.83.128.0/21"; Description = "Incapsula WAF"}
    @{CIDR = "2a02:e980::/29"; Description = "Incapsula WAF"}

    @{CIDR = "203.41.139.109/32"; Description = "Lifeblood"}
    @{CIDR = "203.41.139.88/32"; Description = "Lifeblood"}
    @{CIDR = "103.246.36.0/24"; Description = "Lifeblood"}
    @{CIDR = "170.176.245.0/24"; Description = "Lifeblood"}
    @{CIDR = "148.64.2.0/24"; Description = "Lifeblood"}
    @{CIDR = "34.87.243.0/24"; Description = "Lifeblood"}
    @{CIDR = "168.149.171.0/24"; Description = "Lifeblood"}

    @{CIDR = "117.20.71.49/32"; Description = "Lifeblood Staff Member"}
    @{CIDR = "1.144.105.110/32"; Description = "Lifeblood Rita Nand Modem"}
    @{CIDR = "49.179.141.203/32"; Description = "Lifeblood Rita Nand Handset"}
    @{CIDR = "125.254.20.238/32"; Description = "Lifeblood Amy Rozsa"}
    @{CIDR = "210.50.88.177/32"; Description = "Lifeblood Saira Nadeem"}
    @{CIDR = "118.127.122.144/32"; Description = "Ticket #203258"}
    @{CIDR = "203.51.27.138/32"; Description = "Lifeblood Ruchi Shetty"}
    @{CIDR = "101.116.236.203/32"; Description = "Lifeblood Sandeep Khullar"}
    @{CIDR = "122.110.76.53/32"; Description = "Lifeblood Bharat Anand"}
    @{CIDR = "203.217.56.148/32"; Description = "Lifeblood Michael Staniforth"}
    @{CIDR = "49.176.235.109/32"; Description = "Lifeblood Matt Holt"}
    @{CIDR = "149.167.80.62/32"; Description = "Lifeblood Andrew Cunningham"}
    @{CIDR = "49.199.18.230/32"; Description = "Lifeblood Sarah Hayward"}
    @{CIDR = "103.246.36.14/32"; Description = "Lifeblood Adrian Li-Hung-Shun 1"}
    @{CIDR = "124.150.42.231/32"; Description = "Lifeblood Adrian Li-Hung-Shun 2"}
    @{CIDR = "180.150.49.2/32"; Description = "Lifeblood Anil Samuel"}
    @{CIDR = "101.188.158.177/32"; Description = "Lifeblood Suzanne Vila"}
    @{CIDR = "60.229.162.124/32"; Description = "Lifeblood Lisa Hammill 1"}
    @{CIDR = "148.64.2.16/32"; Description = "Lifeblood Lisa Hammill 2"}
    @{CIDR = "101.116.196.53/32"; Description = "Ticket #193895"}
    @{CIDR = "59.102.110.168/32"; Description = "Ticket #196196"}
    @{CIDR = "14.200.15.244/32"; Description = "Ticket #196196"}
    @{CIDR = "180.150.38.196/32"; Description = "Ticket #196335"}
    @{CIDR = "123.243.223.148/32"; Description = "Ticket #202327"}
    @{CIDR = "101.116.25.177/32"; Description = "Ticket #203024"}
    @{CIDR = "101.116.40.57/32"; Description = "Ticket ???"}
    @{CIDR = "180.150.39.209/32"; Description = "Ticket #203248"}
    @{CIDR = "1.128.111.29/32"; Description = "Ticket #203258"}
    @{CIDR = "101.165.130.23/32"; Description = "Ticket #203862"}
    @{CIDR = "49.184.169.226/32"; Description = "Ticket #203862"}
    @{CIDR = "101.116.127.22/32"; Description = "Ticket #204035"}
    @{CIDR = "60.234.58.34/32"; Description = "Ticket #204035"}
    @{CIDR = "120.19.78.57/32"; Description = "Ticket #206881"}
    @{CIDR = "101.116.219.142/32"; Description = "Ticket #207621"}
    @{CIDR = "210.50.233.27/32"; Description = "Ticket #207621"}
    @{CIDR = "118.127.122.148/32"; Description = "Ticket #207828"}
)

$ARCBS_OSC_Addresses = @(
    #"45.60.0.0/16"
    #"45.64.64.0/22"
    #"45.223.0.0/16"
    #"103.28.248.0/22"
    #"107.154.0.0/16"
    #"149.126.72.0/21"
    #"185.11.124.0/22"
    #"192.230.64.0/18"
    #"198.143.32.0/19"
    #"199.83.128.0/21"
    #"2a02:e980::/29"
)

$RGName = "rg-$($Environment)-ciam"

if ($Environment -notmatch "prd") {
    $AppName = "$($Application)-$($Environment)"
} else {
    $AppName = $Application
}

if ($Application -match "oscapi") {
    $IPAddressArray = $ARCBS_OSC_Addresses
} else {
    $IPAddressArray = $ARCBS_WAF_Addresses
}

$Priority = $StartingPriority

try {
    $RestrictionConfig = Get-AzWebAppAccessRestrictionConfig -ResourceGroupName $RGName -Name $AppName
    $ExistingIPRules = $RestrictionConfig.MainSiteAccessRestrictions

    foreach ($Entry in $IPAddressArray) {
        $CIDR = $Entry["CIDR"]
        $Description = $Entry["Description"]
        $IPRuleName = "ARCL $($Priority)"

        Write-Progress -Activity "Update IPAddress Restrictions for $AppName" -Status "In Progress" -PercentComplete (($IPAddressArray.IndexOf($Entry) + 1) / $IPAddressArray.Count * 100) -CurrentOperation "Adding/Updating rule $IPRuleName ..."

        $CurrentRule = @($ExistingIPRules | Where-Object -Property Priority -EQ -Value $Priority)
        if ($CurrentRule.Count -gt 1) {
            foreach ($Rule in $CurrentRule[1..($CurrentRule.Count - 1)]) {
                Write-Warning -Message "Removing duplicate rule $Priority/$IPRuleName on application $AppName"
                Remove-AzWebAppAccessRestrictionRule -ResourceGroupName $RGName -WebAppName $AppName -Name $Rule.RuleName
            }
        }

        if (-not $CurrentRule) {
            Write-Verbose -Message "Adding rule $IPRuleName on application $AppName"
            Add-AzWebAppAccessRestrictionRule -ResourceGroupName $RGName -WebAppName $AppName -Priority $Priority -Name $IPRuleName -Description $Description -Action Allow -IpAddress $CIDR
        } elseif ($CurrentRule[0].RuleName -ne $IPRuleName -or $CurrentRule[0].Description -ne $Description -or $CurrentRule[0].IpAddress -ne $CIDR) {
            # For some reason, there is no such powershell command to UPDATE a rule, only delete and re-create ... classic Microsoft ...
            Write-Verbose -Message "Updating rule $IPRuleName on application $AppName"
            Remove-AzWebAppAccessRestrictionRule -ResourceGroupName $RGName -WebAppName $AppName -Name $CurrentRule[0].RuleName
            Add-AzWebAppAccessRestrictionRule -ResourceGroupName $RGName -WebAppName $AppName -Priority $Priority -Name $IPRuleName -Description $Description -Action Allow -IpAddress $CIDR
        } else {
            Write-Verbose -Message "No Change Needed for rule $IPRuleName on application $AppName"
        }
        $Priority++
    }

    while ($ExtraRules = @($ExistingIPRules | Where-Object -Property Priority -EQ -Value $Priority)) {
        foreach ($Rule in $ExtraRules) {
            Write-Verbose -Message "Removing excess rule $($Rule.RuleName) for application $AppName"
            $null = Remove-AzWebAppAccessRestrictionRule -ResourceGroupName $RGName -WebAppName $AppName -Name $Rule.RuleName -PassThru
        }
        $Priority++
    }
} finally {
    Write-Progress -Activity "Update IPAddress Restrictions for $AppName" -Status "Completed" -PercentComplete 100 -Completed
}
