const gulp = require('gulp');
const log = require('fancy-log');

const destPath = './dist/';

gulp.task('build', done => {

    log('******************** START *************************');
    log('START: Gulp starting to generate distributable code.');

    /*
     * ********************************************* STEP 1 ******************************* //
     * ------------------------------------------------------------------------------------ //
     * ---------- Copy the required files for root folder ------------------------------------- //
     * -- Required to run 'func azure functionapp publish oscapi-env' command vis VS code-- //
     * ------------------------------------------------------------------------------------ //
     */

    log('-----------------------------------------');

    log('Starting to copy the files on dist folder.');

    gulp.src(
        [
            './**',         //Select all json files
            '!./dist',  //Ignore the dist folder
            '!./dist/**', //Ignore the dist folder content
            '!./Gulpfile.js', //Ignore the gulpfile.js
            '!./*.ps1', //Ignore the PS deploy file
            '!./local.settings.*' // Eww, do not include the local settings!
        ])
        .pipe(gulp.dest(`${destPath}`));

    log('Ended copying the files on dist folder.');

    log('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~');

    log('END: gulping to generate distributable code.');
    log('******************** END *************************');

    done();
});
