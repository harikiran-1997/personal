/*
    Function:       SetUserStatus
    Notes:          HTTP Trigger to be called by Replying Party / Service Provider applications
    Purpose:        Set a user's status to enable / disable.
    Author:         Warwick Jaensch (Kloud Solutions)
    Date Created:   March 26th 2018
    Revision History:
    Name:           Date:         Description:

*/

// The NPM Modeules to include
const appInsights = require("applicationinsights");
appInsights.setup()
    .setSendLiveMetrics(process.env.appInsights_liveMetrics)
    .start();

const auth = require("basic-auth");
const https = require("https");
const request = require("request");

https.globalAgent.keepAlive = true;

// Get a token to access the Graph API
function acquireTokenForApplication(context, tenantId, clientId, clientSecret, resource, now, callback) {
    context.log.info(`Acquiring token for application '${clientId}' for tenant '${tenantId}'...`);

    const tokenCache = global.tokenCache || {};
    const tokenCacheKey = new Buffer.from(`${tenantId}::${resource}::${clientId}::${clientSecret}`).toString("base64");
    const tokenCacheValue = tokenCache[tokenCacheKey];

    if (typeof tokenCacheValue !== "undefined" && tokenCacheValue && now + 300 < tokenCacheValue.expires_on) {
        context.log.info(`Acquired token for application '${clientId}' from client for tenant '${tenantId}'.`);

        context.log.info(`Before callback in acquireTokenForApplication`);
        callback(null, null, tokenCacheValue.access_token);
        return;
    }
    context.log.info(`Cached token not found, acquiring new token`);
    let graphUrl = `https://login.microsoftonline.com/${encodeURIComponent(tenantId)}/oauth2/token`;
    context.log.info(`graphUrl created to acquire token: '${graphUrl}' for tenant '${tenantId}'...`);
    request.post({
        url: graphUrl,
        form: {
            "grant_type": "client_credentials",
            "client_id": clientId,
            "client_secret": clientSecret,
            "resource": resource
        }
    }, (err, response, responseBody) => {
        context.log.info(`response.statusCode received in acquire token function:${response.statusCode}`);
        context.log.info(`error received in acquire token function:${err}`);
        context.log.info(`response received in acquire token function:${response}`);
        context.log.info(`response body received in acquire token function:${responseBody}`);
        if (err) {
            context.log.error(`FAILED: Acquired token for application '${clientId}' from server for tenant '${tenantId}'. Error: ${err}.`);
            callback(err);
            return;
        }

        if (!isSuccessStatusCode(response.statusCode)) {
            if(responseBody!=="undefined")
            {
                const errorResult = JSON.parse(responseBody);

                context.log.warn(`FAILED: Acquired token for application '${clientId}' from server for tenant '${tenantId}'. Error code: ${errorResult.error}. Error message: ${errorResult.error_description}`);

                callback(null, {
                    code: errorResult.error,
                    message: errorResult.error_description
                });
            }
            else
            {
                context.log.info(`error responseBody under function acquireTokenForApplication is undefined.`);
            }
            return;
        }

        context.log.info(`SUCCEEDED: Acquired token for application '${clientId}' from server for tenant '${tenantId}'.`);

        const result = JSON.parse(responseBody);
        tokenCache[tokenCacheKey] = result;
        global.tokenCache = tokenCache;
        callback(null, null, result.access_token);
    });
}

function createBadRequestErrorResponse(errorCode, errorMessage) {
    return createErrorResponse(400, errorCode, errorMessage);
}

function createNotFoundErrorResponse(errorCode, errorMessage) {
    return createErrorResponse(404, errorCode, errorMessage);
}

function createConflictErrorResponse(errorCode, errorMessage) {
    return createErrorResponse(409, errorCode, errorMessage);
}

function createOKResponse(context, user, clientId, userToBeUpdated) {
    var email = '';
    if(user.signInNames.length > 0)
    {
        email = user.signInNames[0].value;
    }
    else
    {
        email = user.userPrincipalName;
    }
    const res = {
        body: {
            objectId: user.objectId,
            accountEnabled: userToBeUpdated.accountEnabled,
            email: email,
            userPrincipalName: user.userPrincipalName
        }
    };

    // Set the extension properties
    res.body.extension_ContactId = getExtensionProperty(user, clientId, "ContactId");
    res.body.extension_PhoneNumber =  getExtensionProperty(user, clientId, "AuthenticationPhoneNumber");

    context.log.info(`Response to be sent back: '${JSON.stringify(res)}'.`);

    return res;
}

function createErrorResponse(statusCode, errorCode, errorMessage) {
    return {
        status: statusCode,
        body: {
            "version": "1.0.0",
            "status": statusCode,
            "userCode": errorCode,
            "userMessage": errorMessage
        }
    };
}

function createInternalServerErrorErrorResponse() {
    return createErrorResponse(500, "InternalServerError", "An unexpected error has occurred.");
}

function createUnauthorizedErrorResponse() {
    return createErrorResponse(401, "Unauthorized", "Access is denied.");
}

// Get ExtensionProperty function
function getExtensionProperty(user, clientId, extensionPropertyName) {
    return user[`extension_${clientId.replace(/-/g, "")}_${extensionPropertyName}`];
}

function isSuccessStatusCode(statusCode) {
    return statusCode >= 200 && statusCode < 300;
}

function getUser(context, tenantId, accessToken, userId, callback) {
    context.log.info(`Getting user '${userId}' for tenant '${tenantId}'...`);
    let graphUrl = `https://graph.windows.net/${encodeURIComponent(tenantId)}/users/${encodeURIComponent(userId)}?api-version=1.6`;
    context.log.info(`graphUrl created to get the user: '${graphUrl}' for tenant '${tenantId}'...`);
    request.get({
        url: graphUrl,
        auth: {
            bearer: accessToken
        }
    }, (err, response, responseBody) => {
        if (err) {
            context.log.error(`FAILED: Got user '${userId}' for tenant '${tenantId}'. Error: ${err}.`);

            callback(err);
            return;
        }

        if (!isSuccessStatusCode(response.statusCode)) {

            if(responseBody!=="undefined")
            {
                const errorResult = JSON.parse(responseBody);

                context.log.warn(`FAILED: Got user '${userId}' for tenant '${tenantId}'. Error code: ${errorResult["odata.error"].code}. Error description: ${errorResult["odata.error"].message.value}.`);

                callback(null, {
                    code: errorResult["odata.error"].code,
                    message: errorResult["odata.error"].message.value
                });
            }
            else
            {
                context.log.info(`error responseBody under function getUser is undefined.`);
            }
            return;
        }

        const user = JSON.parse(responseBody);

        context.log.info(`SUCCEEDED: Got user ['${user.objectId}', '${user.userPrincipalName}'] for tenant '${tenantId}'.`);

        callback(null, null, user);
    });
}

// Update User function
function updateUser(context, tenantId, accessToken, user, callback) {
    context.log.info(`Updating user '${user.objectId}' for tenant '${tenantId}'...`);
    let graphUrl = `https://graph.windows.net/${encodeURIComponent(tenantId)}/users/${encodeURIComponent(user.objectId)}?api-version=1.6`;
    context.log.info(`graphUrl created to update user: '${graphUrl}' for tenant '${tenantId}'...`);

    request.patch({
        url: graphUrl,
        auth: {
            bearer: accessToken
        },
        body: user,
        json: true
    }, (err, response, responseBody) => {
        context.log.info(`response.statusCode received in update user function:${response.statusCode}`);
        context.log.info(`error received in update user function:${err}`);
        context.log.info(`response received in update user function:${response}`);
        context.log.info(`response body received in update user function:${responseBody}`);
        if (err) {
            context.log.error(`FAILED: Updated user '${user.objectId}' for tenant '${tenantId}'. Error: ${err}.`);

            callback(err);
            return;
        }

        if (!isSuccessStatusCode(response.statusCode)) {
            if(responseBody!=="undefined")
            {
                const errorResult = JSON.parse(responseBody);

                context.log.warn(`FAILED: Updated user '${user.objectId}' for tenant '${tenantId}'. Error code: ${errorResult["odata.error"].code}. Error message: ${errorResult["odata.error"].message.value}`);

                callback(null, {
                    code: errorResult["odata.error"].code,
                    message: errorResult["odata.error"].message.value
                });
            }
            else
            {
                context.log.info(`error responseBody under function updateUser is undefined.`);
            }
            return;
        }

        context.log.info(`SUCCEEDED: Updated user '${user.objectId}' for tenant '${tenantId}'.`);

        callback(null, null);
    });
}

// This function will invalidate all refresh tokens for the specified user by resetting the refreshTokensValidFromDateTime to the current date-time.
// Typically this operation is performed if the user has a lost or stolen device, after calling this function access to a given application requires
// sign-in again.
function invalidateUserToken(context, tenantId, accessToken, user, callback) {
    context.log.info(`Invalidating tokens for user '${user.objectId}' in tenant '${tenantId}'...`);
    let graphUrl = `https://graph.windows.net/${encodeURIComponent(tenantId)}/users/${encodeURIComponent(user.objectId)}/invalidateAllRefreshTokens?api-version=1.6`;
    context.log.info(`graphUrl created to invalidate UserToken: '${graphUrl}' for tenant '${tenantId}'...`);
    // No request body needed and is omitted from request.post action.
    // On success no response body is returned; otherwise, the response body contains error details.
    request.post({
        url: graphUrl,
        auth: {
            bearer: accessToken
        },
        json: true
    }, (err, response, responseBody) => {
        if (err) {
            context.log.error(`FAILED: Could not invalidate token for user '${user.objectId}' in tenant '${tenantId}'. Error: ${err}.`);

            callback(err);
            return;
        }

        if (!isSuccessStatusCode(response.statusCode)) {
            if(responseBody!=="undefined")
            {
                const errorResult = JSON.parse(responseBody);

                context.log.warn(`FAILED: Could not invalidate token for user '${user.objectId}' in tenant '${tenantId}'. Error code: ${errorResult["odata.error"].code}. Error message: ${errorResult["odata.error"].message.value}`);

                callback(null, {
                    code: errorResult["odata.error"].code,
                    message: errorResult["odata.error"].message.value
                });
            }
            else
            {
                context.log.info(`error responseBody under function invalidateUserToken is undefined.`);
            }
            return;
        }

        context.log.info(`SUCCEEDED: Invalidated user '${user.objectId}' in tenant '${tenantId}'.`);

        callback(null, null);
    });
}

module.exports = function (context, req) {
    try {
        var client = auth(req);

        // Return Unauthorised response
        if (typeof client === "undefined" || !client) {
            context.res = createUnauthorizedErrorResponse();
            context.done();
            return;
        }

        // Return Parameters Missing response
        if (typeof req.body === "undefined" || !req.body) {
            context.res = createBadRequestErrorResponse("InvalidRequest", "Parameters are missing.");
            context.done();
            return;
        }

        // **********************************
        // Validate the incoming Request data
        // **********************************

        // We must have the User.
        if ((typeof req.body.objectId === "undefined" || typeof req.body.objectId !== "string" || !req.body.objectId) && (typeof req.body.userPrincipalName === "undefined" || typeof req.body.userPrincipalName !== "string" || !req.body.userPrincipalName)) {
            context.res = createBadRequestErrorResponse("InvalidRequest", "User is missing.");
            context.done();
            return;
        }

        // We must have the action -> Disable or Enable
        if (typeof req.body.actionName === "undefined" || typeof req.body.actionName !== "string" || !req.body.actionName) {
            context.res = createBadRequestErrorResponse("InvalidRequest", "Action is missing.");
            context.done();
            return;
        }

        context.log.info(`Received request body: '${JSON.stringify(req.body)}'.`);

        // Validate the tenant name
        if (typeof process.env.tenantId === "undefined" || !process.env.tenantId) {
            context.res = createBadRequestErrorResponse("InvalidTenant", "Tenant is invalid.");
            context.done();
            return;
        }

        // Validate the Actions
        const actionNames = [
            "disable",
            "enable"
        ];

        if (!actionNames.includes(req.body.actionName)) {
            context.res = createBadRequestErrorResponse("InvalidAction", "Action is invalid.");
            context.done();
            return;
        }

        // Current Date/Time
        const now = Math.round(new Date().getTime() / 1000);

        acquireTokenForApplication(context, process.env.tenantId, client.name, client.pass, "https://graph.windows.net", now, (err, error, accessToken) => {
            context.log.info(`inside callback after acquireTokenForApplication`);
            try {
                if (err) {
                    context.res = createInternalServerErrorErrorResponse();
                    context.done();
                    return;
                }

                if (error) {
                    context.res = createInternalServerErrorErrorResponse();
                    context.done();
                    return;
                }
                context.log.info(`before getting user after acquireTokenForApplication`);
                getUser(context, process.env.tenantId, accessToken, req.body.objectId || req.body.userPrincipalName, (err, error, user) => {
                    try {
                        if (err) {
                            context.res = createInternalServerErrorErrorResponse();
                            context.done();
                            return;
                        }

                        if (error) {
                            if (error.code === "Request_ResourceNotFound") {
                                context.res = createNotFoundErrorResponse("UserNotFound", "User isn't found.");
                            } else {
                                context.res = createInternalServerErrorErrorResponse();
                            }

                            context.done();
                            return;
                        }
                        // Populate the user object to be patched, dont patch the whole user object, it gave error because get user returned "<thumbnailPhoto@odata.mediaEditLink >" which cant be patched.
                        const userToBeUpdated = {
                            objectId: user.objectId
                        };

                        // Process the action
                        var InvalidateTokens = false;
                        switch (req.body.actionName) {
                            case "disable": {
                                userToBeUpdated.accountEnabled = false;
                                InvalidateTokens = true;
                                break;
                            }

                            case "enable": {
                                userToBeUpdated.accountEnabled = true;
                                break;
                            }
                        }

                        // Now update the user
                        updateUser(context, process.env.tenantId, accessToken, userToBeUpdated, (err, error) => {
                            try {
                                if (err) {userToBeUpdatedrorResponse();
                                    context.done();
                                    return;
                                }

                                if (error) {
                                    context.res = createInternalServerErrorErrorResponse();
                                    context.done();
                                    return;
                                }

                                // Now invalidate the user token
                                if (InvalidateTokens) {
                                    invalidateUserToken(context, process.env.tenantId, accessToken, user, (err, error) => {
                                        try {
                                            if (err) {
                                                context.res = createInternalServerErrorErrorResponse();
                                                context.done();
                                                return;
                                            }

                                            if (error) {
                                                context.res = createInternalServerErrorErrorResponse();
                                                context.done();
                                                return;
                                            }
                                            context.res = createOKResponse(context, user, process.env.graphApplicationClientId, userToBeUpdated);
                                            context.done();
                                        } catch (err) {
                                            context.log.error(`FAILED: Could not invalidate refresh token. Error: ${err}.`);

                                            context.res = createInternalServerErrorErrorResponse();
                                            context.done();
                                            return;
                                        }
                                    });
                                }
                                else {
                                    context.res = createOKResponse(context, user, process.env.graphApplicationClientId, userToBeUpdated);
                                    context.done();
                                }
                            } catch (err) {
                                context.log.error(`FAILED: An unexpected error has occurred. Error: ${err}.`);

                                context.res = createInternalServerErrorErrorResponse();
                                context.done();
                            }
                        });
                    } catch (err) {
                        context.log.error(`FAILED: An unexpected error has occurred. Error: ${err}.`);

                        context.res = createInternalServerErrorErrorResponse();
                        context.done();
                    }
                });
            } catch (err) {
                context.log.error(`FAILED: An unexpected error has occurred. Error: ${err}.`);

                context.res = createInternalServerErrorErrorResponse();
                context.done();
            }
        });
    } catch (err) {
        context.log.error(`FAILED: An unexpected error has occurred. Error: ${err}.`);

        context.res = createInternalServerErrorErrorResponse();
        context.done();
    }
};
