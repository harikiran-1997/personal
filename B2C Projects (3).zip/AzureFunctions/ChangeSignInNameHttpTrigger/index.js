/*
    Function:       ChangeSignInName
    Notes:          HTTP Trigger to be called by Replying Party / Service Provider applications
    Purpose:        Change a user's sign-in name.
    Author:         Warwick Jaensch (Kloud Solutions)
    Date Created:   March 26th 2018
    Revision History:
    Name:           Date:         Description:

*/

// The NPM Modeules to include
const appInsights = require("applicationinsights");
appInsights.setup()
    .setSendLiveMetrics(process.env.appInsights_liveMetrics)
    .start();

const auth = require("basic-auth");
const https = require("https");
const request = require("request");
const _ = require("underscore");

https.globalAgent.keepAlive = true;

// Get a token to access the Graph API
function acquireTokenForApplication(context, tenantId, clientId, clientSecret, resource, now, callback) {
    context.log.info(`Acquiring token for application '${clientId}' for tenant '${tenantId}'...`);

    // Check to see if we have the token cached
    const tokenCache = global.tokenCache || {};
    const tokenCacheKey = new Buffer.from(`${tenantId}::${resource}::${clientId}::${clientSecret}`).toString("base64");
    const tokenCacheValue = tokenCache[tokenCacheKey];

    if (typeof tokenCacheValue !== "undefined" && tokenCacheValue && now + 300 < tokenCacheValue.expires_on) {
        context.log.info(`Acquired token for application '${clientId}' from client for tenant '${tenantId}'.`);

        callback(null, null, tokenCacheValue.access_token);
        return;
    }

    // We have no cached token so we need get a new token.
    request.post({
        url: `https://login.microsoftonline.com/${encodeURIComponent(tenantId)}/oauth2/token`,
        form: {
            "grant_type": "client_credentials",
            "client_id": clientId,
            "client_secret": clientSecret,
            "resource": resource
        }
    }, (err, response, responseBody) => {
        if (err) {
            context.log.error(`FAILED: Acquired token for application '${clientId}' from server for tenant '${tenantId}'. Error: ${err}.`);
            callback(err);
            return;
        }

        // Couldn't get a token
        if (!isSuccessStatusCode(response.statusCode)) {
            const errorResult = JSON.parse(responseBody);

            context.log.warn(`FAILED: Acquired token for application '${clientId}' from server for tenant '${tenantId}'. Error code: ${errorResult.error}. Error message: ${errorResult.error_description}`);

            callback(null, {
                code: errorResult.error,
                message: errorResult.error_description
            });

            return;
        }

        context.log.info(`SUCCEEDED: Acquired token for application '${clientId}' from server for tenant '${tenantId}'.`);

        // We received a token so save it to the cache.
        const result = JSON.parse(responseBody);
        tokenCache[tokenCacheKey] = result;
        global.tokenCache = tokenCache;
        callback(null, null, result.access_token);
    });
}

// Create Bad Request Response
function createBadRequestErrorResponse(errorCode, errorMessage) {
    return createErrorResponse(400, errorCode, errorMessage);
}

// User not found error
function createNotFoundErrorResponse(errorCode, errorMessage) {
    return createErrorResponse(404, errorCode, errorMessage);
}

// Create Conflict Error Response
function createConflictErrorResponse(errorCode, errorMessage) {
    return createErrorResponse(409, errorCode, errorMessage);
}

// OK Response
function createOKResponse(context, user, clientId, userToBeUpdated) {
    const res = {
        body: {
            objectId: user.objectId,
            accountEnabled: user.accountEnabled,
            email: userToBeUpdated.signInNames[0].value,//because userToBeUpdated has the latest sign in name which is updated, to avoid another call to graph API we just return what got updated
            userPrincipalName: user.userPrincipalName
        }
    };

    // Set the extension properties
    res.body.extension_ContactId = getExtensionProperty(user, clientId, "ContactId");
    res.body.extension_PhoneNumber =  getExtensionProperty(user, clientId, "AuthenticationPhoneNumber");

    context.log.info(`Response to be sent back: '${JSON.stringify(res)}'.`);

    return res;
}

// Error response
function createErrorResponse(statusCode, errorCode, errorMessage) {
    return {
        status: statusCode,
        body: {
            "version": "1.0.0",
            "status": statusCode,
            "userCode": errorCode,
            "userMessage": errorMessage
        }
    };
}

// Internal Server Error
function createInternalServerErrorErrorResponse() {
    return createErrorResponse(500, "InternalServerError", "An unexpected error has occurred.");
}

// Unauthorised Error Response
function createUnauthorizedErrorResponse() {
    return createErrorResponse(401, "Unauthorized", "Access is denied.");
}

// Get ExtensionProperty function
function getExtensionProperty(user, clientId, extensionPropertyName) {
    return user[`extension_${clientId.replace(/-/g, "")}_${extensionPropertyName}`];
}

// Check we have a success code
function isSuccessStatusCode(statusCode) {
    return statusCode >= 200 && statusCode < 300;
}

// Get ExtensionProperty function
function getExtensionProperty(user, clientId, extensionPropertyName) {
    return user[`extension_${clientId.replace(/-/g, "")}_${extensionPropertyName}`];
}

// Set ExtensionProperty function
function setExtensionProperty(user, clientId, extensionPropertyName, extensionPropertyValue) {
    user[`extension_${clientId.replace(/-/g, "")}_${extensionPropertyName}`] = extensionPropertyValue;
}

// Get user function
function getUser(context, tenantId, accessToken, userId, callback) {
    context.log.info(`Getting user '${userId}' for tenant '${tenantId}'...`);

    // Get
    request.get({
        url: `https://graph.windows.net/${encodeURIComponent(tenantId)}/users/${encodeURIComponent(userId)}?api-version=1.6`,
        auth: {
            bearer: accessToken
        }
    }, (err, response, responseBody) => {
        // We have an error
        if (err) {
            context.log.error(`FAILED: Got user '${userId}' for tenant '${tenantId}'. Error: ${err}.`);

            callback(err);
            return;
        }

        if (!isSuccessStatusCode(response.statusCode)) {
            const errorResult = JSON.parse(responseBody);

            context.log.warn(`FAILED: Got user '${userId}' for tenant '${tenantId}'. Error code: ${errorResult["odata.error"].code}. Error description: ${errorResult["odata.error"].message.value}.`);

            callback(null, {
                code: errorResult["odata.error"].code,
                message: errorResult["odata.error"].message.value
            });

            return;
        }

        // Success
        const user = JSON.parse(responseBody);
        context.log.info(`SUCCEEDED: Got user ['${user.objectId}', '${user.userPrincipalName}'] for tenant '${tenantId}'.`);
        callback(null, null, user);
    });
}

// Update User function
function updateUser(context, tenantId, accessToken, user, callback) {
    context.log.info(`Updating user '${user.objectId}' for tenant '${tenantId}'...`);

    let url = `https://graph.windows.net/${encodeURIComponent(tenantId)}/users/${encodeURIComponent(user.objectId)}?api-version=1.6`;
    context.log.info("updateUser url:" + url);
    // Update
    request.patch({
        url: url,
        auth: {
            bearer: accessToken
        },
        body: user,
        json: true
    }, (err, response, responseBody) => {
        if (err) {
            context.log.error(`FAILED: Updated user '${user.objectId}' for tenant '${tenantId}'. Error: ${err}.`);

            callback(err);
            return;
        }

        if (!isSuccessStatusCode(response.statusCode)) {
            const errorResult = responseBody;

            context.log.warn(`FAILED: Updated user '${user.objectId}' for tenant '${tenantId}'. Error code: ${errorResult["odata.error"].code}. Error message: ${errorResult["odata.error"].message.value}`);

            callback(null, {
                code: errorResult["odata.error"].code,
                message: errorResult["odata.error"].message.value
            });

            return;
        }

        // Success
        context.log.info(`SUCCEEDED: Updated user '${user.objectId}' for tenant '${tenantId}'.`);
        callback(null, null);
    });
}

// This function will invalidate all refresh tokens for the specified user by resetting the refreshTokensValidFromDateTime to the current date-time.
// Typically this operation is performed if the user has a lost or stolen device, after calling this function access to a given application requires
// sign-in again.
function invalidateUserToken(context, tenantId, accessToken, user, callback) {
    context.log.info(`Invalidating tokens for user '${user.objectId}' in tenant '${tenantId}'...`);

    // No request body needed and is omitted from request.post action.
    // On success no response body is returned; otherwise, the response body contains error details.
    request.post({
        url: `https://graph.windows.net/${encodeURIComponent(tenantId)}/users/${encodeURIComponent(user.objectId)}/invalidateAllRefreshTokens?api-version=1.6`,
        auth: {
            bearer: accessToken
        },
        json: true
    }, (err, response, responseBody) => {
        if (err) {
            context.log.error(`FAILED: Could not invalidate token for user '${user.objectId}' in tenant '${tenantId}'. Error: ${err}.`);

            callback(err);
            return;
        }

        if (!isSuccessStatusCode(response.statusCode)) {
            const errorResult = JSON.parse(responseBody);

            context.log.warn(`FAILED: Could not invalidate token for user '${user.objectId}' in tenant '${tenantId}'. Error code: ${errorResult["odata.error"].code}. Error message: ${errorResult["odata.error"].message.value}`);

            callback(null, {
                code: errorResult["odata.error"].code,
                message: errorResult["odata.error"].message.value
            });

            return;
        }

        context.log.info(`SUCCEEDED: Invalidated user '${user.objectId}' in tenant '${tenantId}'.`);

        callback(null, null);
    });
}

// Main function entry point
module.exports = function (context, req) {
    try {
        var client = auth(req);

        // Return Unauthorised response
        if (typeof client === "undefined" || !client) {
            context.res = createUnauthorizedErrorResponse();
            context.done();
            return;
        }

        // Return Parameters Missing response
        if (typeof req.body === "undefined" || !req.body) {
            context.res = createBadRequestErrorResponse("InvalidRequest", "Parameters are missing.");
            context.done();
            return;
        }

        // **********************************
        // Validate the incoming Request data
        // **********************************

        // We must have the User.
        if ((typeof req.body.objectId === "undefined" || typeof req.body.objectId !== "string" || !req.body.objectId) && (typeof req.body.userPrincipalName === "undefined" || typeof req.body.userPrincipalName !== "string" || !req.body.userPrincipalName)) {
            context.res = createBadRequestErrorResponse("InvalidRequest", "User is missing.");
            context.done();
            return;
        }

        // We must have the current sign-in name.
        if (typeof req.body.currentSignInName === "undefined" || typeof req.body.currentSignInName !== "string" || !req.body.currentSignInName) {
            context.res = createBadRequestErrorResponse("InvalidRequest", "Current sign-in name is missing.");
            context.done();
            return;
        }

        // We must have the new sign-in name.
        if (typeof req.body.newSignInName === "undefined" || typeof req.body.newSignInName !== "string" || !req.body.newSignInName) {
            context.res = createBadRequestErrorResponse("InvalidRequest", "New sign-in name is missing.");
            context.done();
            return;
        }

        context.log.info(`Received request body: '${JSON.stringify(req.body)}'.`);

        // Validate the tenant name
        if (typeof process.env.tenantId === "undefined" || !process.env.tenantId) {
            context.res = createBadRequestErrorResponse("InvalidTenant", "Tenant is invalid.");
            context.done();
            return;
        }

        // Current Date/Time
        const now = Math.round(new Date().getTime() / 1000);

        // Get an access token
        acquireTokenForApplication(context, process.env.tenantId, client.name, client.pass, "https://graph.windows.net", now, (err, error, accessToken) => {
            try {
                if (err) {
                    context.res = createInternalServerErrorErrorResponse();
                    context.done();
                    return;
                }

                if (error) {
                    context.res = createInternalServerErrorErrorResponse();
                    context.done();
                    return;
                }

                // Get the User
                getUser(context, process.env.tenantId, accessToken, req.body.objectId || req.body.userPrincipalName, (err, error, user) => {
                    try {
                        if (err) {
                            context.res = createInternalServerErrorErrorResponse();
                            context.done();
                            return;
                        }

                        if (error) {
                            if (error.code === "Request_ResourceNotFound") {
                                context.res = createNotFoundErrorResponse("UserNotFound", "User isn't found.");
                            } else {
                                context.res = createInternalServerErrorErrorResponse();
                            }

                            context.done();
                            return;
                        }

                        const signInName = _.find(user.signInNames, x => x.type === "emailAddress");

                        if (!signInName || signInName.value !== req.body.currentSignInName) {
                            context.res = createConflictErrorResponse("InvalidSignInName", `The passed sign-in name '${req.body.currentSignInName}' doesn't match the recorded sign-in name.`);
                            context.done();
                            return;
                        }
                        let signinName = req.body.newSignInName.trim();
                        // Check that the sign-in name isnt used

                        // If the sign-in name isnt used then assign to current user
                        // Populate the user object to be patched, dont patch the whole user object, it gave error because get user returned "<thumbnailPhoto@odata.mediaEditLink >" which cant be patched.

                        const userToBeUpdated = {
                            objectId: user.objectId,
                            signInNames: [
                                {
                                    type: "emailAddress",
                                    value: signinName
                                }
                            ],
                            displayName: signinName
                        };

                        // Set the masked email address
                        setExtensionProperty(userToBeUpdated, process.env.graphApplicationClientId, "MaskedAuthenticationEmail", signinName.replace(/^(.)(.*)(.@.*)$/, (_, a, b, c) => a + b.replace(/./g, '*') + c));

                        // Now update the user
                        updateUser(context, process.env.tenantId, accessToken, userToBeUpdated, (err, error) => {
                            try {
                                if (err) {
                                    context.res = createInternalServerErrorErrorResponse();
                                    context.done();
                                    return;
                                }

                                if (error) {
                                    if (error.code === "Request_BadRequest") {
                                        context.res = createConflictErrorResponse("InvalidUser", `User already exists. ${error.message}`);
                                    } else {
                                        context.res = createInternalServerErrorErrorResponse();
                                    }
                                    context.done();
                                    return;
                                }

                                //Success: call invalidateUserTokens
                                invalidateUserToken(context, process.env.tenantId, accessToken, user, (err, error) => {
                                    try {
                                        if (err) {
                                            context.res = createInternalServerErrorErrorResponse();
                                            context.done();
                                            return;
                                        }

                                        if (error) {
                                            context.res = createInternalServerErrorErrorResponse();
                                            context.done();
                                            return;
                                        }
                                        context.res = createOKResponse(context, user, process.env.graphApplicationClientId, userToBeUpdated);
                                        context.done();
                                    } catch (err) {
                                        context.log.error(`FAILED: Could not invalidate refresh token. Error: ${err}.`);

                                        context.res = createInternalServerErrorErrorResponse();
                                        context.done();
                                        return;
                                    }
                                });
                            } catch (err) {
                                context.log.error(`FAILED: An unexpected error has occurred. Error: ${err}.`);

                                context.res = createInternalServerErrorErrorResponse();
                                context.done();
                            }
                        });
                    } catch (err) {
                        context.log.error(`FAILED: An unexpected error has occurred. Error: ${err}.`);

                        context.res = createInternalServerErrorErrorResponse();
                        context.done();
                    }
                });
            } catch (err) {
                context.log.error(`FAILED: An unexpected error has occurred. Error: ${err}.`);

                context.res = createInternalServerErrorErrorResponse();
                context.done();
            }
        });
    } catch (err) {
        context.log.error(`FAILED: An unexpected error has occurred. Error: ${err}.`);

        context.res = createInternalServerErrorErrorResponse();
        context.done();
    }
};
