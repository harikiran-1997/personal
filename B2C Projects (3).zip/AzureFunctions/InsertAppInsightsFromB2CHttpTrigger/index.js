/*
    Function:       InsertAppInsightsFromB2CHttpTrigger
    Notes:          HTTP Trigger to be called by Replying Party / Service Provider applications
    Purpose:        Inserts an application insights custom event to track if user actually clicked/succeeded the login at B2C level.
    Author:         Adeel Nasir (Kloud Solutions)
    Date Created:   February 19th 2019
    Revision History:
    Name:           Date:         Description:

*/

// The NPM Modeules to include
const appInsights = require("applicationinsights");
appInsights.setup()
    .setSendLiveMetrics(process.env.appInsights_liveMetrics)
    .start();

const auth = require("basic-auth");
const https = require("https");
const request = require("request");

https.globalAgent.keepAlive = true;

let appInsightsClient = appInsights.defaultClient;
// Get a token to access the Graph API
function acquireTokenForApplication(context, tenantId, clientId, clientSecret, resource, now, callback) {
    context.log.info(`App Insights Rest API Acquiring token for application '${clientId}' for tenant '${tenantId}'...`);

    // Check to see if we have the token cached
    const tokenCache = global.tokenCache || {};
    const tokenCacheKey = new Buffer.from(`${tenantId}::${resource}::${clientId}::${clientSecret}`).toString("base64");
    const tokenCacheValue = tokenCache[tokenCacheKey];

    if (typeof tokenCacheValue !== "undefined" && tokenCacheValue && now + 300 < tokenCacheValue.expires_on) {
        context.log.info(`App Insights Rest API Acquired token for application '${clientId}' from client for tenant '${tenantId}'.`);

        callback(null, null, tokenCacheValue.access_token);
        return;
    }

    // We have no cached token so we need get a new token.
    request.post({
        url: `https://login.microsoftonline.com/${encodeURIComponent(tenantId)}/oauth2/token`,
        form: {
            "grant_type": "client_credentials",
            "client_id": clientId,
            "client_secret": clientSecret,
            "resource": resource
        }
    }, (err, response, responseBody) => {
        if (err) {
            context.log.error(`App Insights Rest API FAILED: Acquired token for application '${clientId}' from server for tenant '${tenantId}'. Error: ${err}.`);
            callback(err);
            return;
        }

        // Couldn't get a token
        if (!isSuccessStatusCode(response.statusCode)) {
            const errorResult = JSON.parse(responseBody);

            context.log.warn(`App Insights Rest API FAILED: Acquired token for application '${clientId}' from server for tenant '${tenantId}'. Error code: ${errorResult.error}. Error message: ${errorResult.error_description}`);

            callback(null, {
                code: errorResult.error,
                message: errorResult.error_description
            });

            return;
        }

        context.log.info(`App Insights Rest API SUCCEEDED: Acquired token for application '${clientId}' from server for tenant '${tenantId}'.`);

        // We received a token so save it to the cache.
        const result = JSON.parse(responseBody);
        tokenCache[tokenCacheKey] = result;
        global.tokenCache = tokenCache;
        callback(null, null, result.access_token);
    });
}

// Create OK response
function createOKResponse(message) {
    const res = {
        body: {
            message: message
        }
    };
    return res;
}

// Create Error Response, 409 should be returned for B2C
//https://docs.microsoft.com/en-us/azure/active-directory-b2c/validation-technical-profile
function createErrorResponse(errorMessage) {
    return {
        status: statusCode,
        body: {
            "version": "1.0.0",
            "status": 409,
            "userMessage": errorMessage
        }
    };
}


// Check is success
function isSuccessStatusCode(statusCode) {
    return statusCode >= 200 && statusCode < 300;
}


// Main function entry point
module.exports = function (context, req) {
    try {
        var client = auth(req);

        // Return Unauthorised response
        if (typeof client === "undefined" || !client) {
            context.res = createErrorResponse("App Insights Rest API: Access is denied.")
            context.done();
            return;
        }

        // Return Parameters Missing response
        if (typeof req.body === "undefined" || !req.body) {
            context.res = createErrorResponse("App Insights Rest API Parameters are missing.");
            context.done();
            return;
        }

        // **********************************
        // Validate the incoming Request data
        // **********************************

        let eventName = "Unknown";
        let correlationId = "Unknown";
        let clientIpAddress = "Unknown";
        let policyId = "Unknown";
        let eventSource = "RestAPI";
        // We must have the event name.
        if (typeof req.body.eventName !== "undefined" && typeof req.body.eventName === "string" && req.body.eventName) {
            eventName = req.body.eventName;
        }
        // We must have the CorrelationId.
        if (typeof req.body.correlationId !== "undefined" && typeof req.body.correlationId === "string" && req.body.correlationId) {
            correlationId = req.body.correlationId;
        }
        // We must have the client IP address.
        if (typeof req.body.clientIpAddress !== "undefined" && typeof req.body.clientIpAddress === "string" && req.body.clientIpAddress) {
            clientIpAddress = req.body.clientIpAddress;
        }
        // We must have the PolicyId.
        if (typeof req.body.policyId !== "undefined" && typeof req.body.policyId === "string" && req.body.policyId) {
            policyId = req.body.policyId;
        }

        context.log.info(`App Insights Rest API received request body: '${JSON.stringify(req.body)}'.`);

        // Validate the tenant name
        if (typeof process.env.tenantId === "undefined" || !process.env.tenantId) {
            context.res = createErrorResponse("App Insights Rest API Tenant is invalid.");
            context.done();
            return;
        }

        // Current Date/Time
        const now = Math.round(new Date().getTime() / 1000);

	    //Get a token to access the Graph API
        acquireTokenForApplication(context, process.env.tenantId, client.name, client.pass, "https://graph.windows.net", now, (err, error, accessToken) => {
            try {
                if (err) {
                    context.res = createErrorResponse("App Insights Rest API: An unexpected error has occurred.");
                    context.done();
                    return;
                }

                if (error) {
                    context.res = createErrorResponse("App Insights Rest API: An unexpected error has occurred.");
                    context.done();
                    return;
                }

                //insert into app insights
                appInsightsClient.trackEvent(
                    {
                        name: eventName,
                        properties: {
                            CorrelationId: correlationId,
                            ClientIpAddress: clientIpAddress,
                            ClientId: req.body.clientId,
                            PolicyId: policyId,
                            eventSource: eventSource,
                            signInName: req.body.signInName
                        }
                });

                // Return the user details.
                context.res = createOKResponse("App Insights event logged");
                context.done();

            } catch (err) {
                context.log.error(`App Insights Rest API FAILED: An unexpected error has occurred. Error: ${err}.`);

                context.res = createErrorResponse("App Insights Rest API: An unexpected error has occurred.");
                context.done();
            }
        });

    } catch (err) {
        context.log.error(`App Insights Rest API FAILED: An unexpected error has occurred. Error: ${err}.`);

        context.res = createErrorResponse("App Insights Rest API: An unexpected error has occurred.");
        context.done();
    }
};
