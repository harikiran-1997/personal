/*
    Function:       DataSyncEngineHttpTrigger
    Notes:          HTTP Trigger to be called by B2C activation user journey to sync data between broker and Azure AD B2C
    Purpose:        Syncs data between broker and Azure AD B2C during the activation user journey.
    Author:         Adeel Nasir (Kloud Solutions)
    Date Created:   01 May 2020
    Revision History:
    Name:           Date:         Description:

*/

const SYNC_DELAY = 3000; // milliseconds

// The NPM Modeules to include
const appInsights = require("applicationinsights");
appInsights.setup()
    .setSendLiveMetrics(process.env.appInsights_liveMetrics)
    .start();

const auth = require("basic-auth");
const https = require("https");

const util = require('util');
const setTimeoutPromise = util.promisify(setTimeout);

https.globalAgent.keepAlive = true;

// Create OK response
function createOKResponse(message) {
    const res = {
        body: {
            message: message
        }
    };
    return res;
}

// Create Error Response, 409 should be returned for B2C
//https://docs.microsoft.com/en-us/azure/active-directory-b2c/validation-technical-profile
function createErrorResponse(errorMessage) {
    var statusCode = 409;
    return {
        status: statusCode,
        body: {
            "version": "1.0.0",
            "status": statusCode,
            "userMessage": errorMessage
        }
    };
}

// Main function entry point
module.exports = async function (context, req) {
    try {
        var client = auth(req);

        // Return Unauthorised response
        if (typeof client === "undefined" || !client) {
            context.res = createErrorResponse("Access is denied.")
            context.done();
            return;
        }

        // Return Parameters Missing response
        if (typeof req.body === "undefined" || !req.body) {
            context.res = createErrorResponse("Parameters are missing.");
            context.done();
            return;
        }

        // **********************************
        // Validate the incoming Request data
        // **********************************

        context.log.info(`Received request body: '${JSON.stringify(req.body)}'.`);

        let email = "Unknown";
        let contactId = "Unknown";
        let objectId = "Unknown";

        // We should have the email.
        if (typeof req.body.email !== "undefined" && typeof req.body.email === "string" && req.body.email) {
            email = req.body.email;
        }

        // We should have the contactId.
        if (typeof req.body.contactId !== "undefined" && typeof req.body.contactId === "string" && req.body.contactId) {
            contactId = req.body.contactId;
        }

        // We should have the objectId.
        if (typeof req.body.objectId !== "undefined" && typeof req.body.objectId === "string" && req.body.objectId) {
            objectId = req.body.objectId;
        }

        context.log.info(`Starting the delay promise`);

        await setTimeoutPromise(SYNC_DELAY).then(
            () => {
            context.log.info(`Waited ${SYNC_DELAY}ms for email: '${email}', contactId: '${contactId}' and objectId: '${objectId}'.`);
            },
            (reason) => {
                context.log.info(`Wait for ${SYNC_DELAY}ms failed: '${reason}'.`);
            }
        );

        context.log.info(`Finished the delay promise`);

        // Return the user details.
        context.res = createOKResponse("Data Sync Completed.");
        context.done();
    } catch (err) {
        context.log.error(`Data Sync Engine Rest API FAILED: An unexpected error has occurred. Error: ${err}.`);

        context.res = createErrorResponse("Data Sync Engine Rest API: An unexpected error has occurred.");
        context.done();
    }
};
