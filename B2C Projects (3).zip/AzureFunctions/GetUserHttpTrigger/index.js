/*
    Function:       GetUser
    Notes:          HTTP Trigger to be called by Replying Party / Service Provider applications
    Purpose:        Get a user's details including the account status.
    Author:         Warwick Jaensch (Kloud Solutions)
    Date Created:   March 26th 2018
    Revision History:
    Name:           Date:         Description:

*/

// The NPM Modeules to include
const appInsights = require("applicationinsights");
appInsights.setup()
    .setSendLiveMetrics(process.env.appInsights_liveMetrics)
    .start();

const auth = require("basic-auth");
const https = require("https");
const request = require("request");

https.globalAgent.keepAlive = true;

// Get a token to access the Graph API
function acquireTokenForApplication(context, tenantId, clientId, clientSecret, resource, now, callback) {
    context.log.info(`Acquiring token for application '${clientId}' for tenant '${tenantId}'...`);

    // Check to see if we have the token cached
    const tokenCache = global.tokenCache || {};
    const tokenCacheKey = new Buffer.from(`${tenantId}::${resource}::${clientId}::${clientSecret}`).toString("base64");
    const tokenCacheValue = tokenCache[tokenCacheKey];

    if (typeof tokenCacheValue !== "undefined" && tokenCacheValue && now + 300 < tokenCacheValue.expires_on) {
        context.log.info(`Acquired token for application '${clientId}' from client for tenant '${tenantId}'.`);

        callback(null, null, tokenCacheValue.access_token);
        return;
    }

    // We have no cached token so we need get a new token.
    request.post({
        url: `https://login.microsoftonline.com/${encodeURIComponent(tenantId)}/oauth2/token`,
        form: {
            "grant_type": "client_credentials",
            "client_id": clientId,
            "client_secret": clientSecret,
            "resource": resource
        }
    }, (err, response, responseBody) => {
        if (err) {
            context.log.error(`FAILED: Acquired token for application '${clientId}' from server for tenant '${tenantId}'. Error: ${err}.`);
            callback(err);
            return;
        }

        // Couldn't get a token
        if (!isSuccessStatusCode(response.statusCode)) {
            const errorResult = JSON.parse(responseBody);

            context.log.warn(`FAILED: Acquired token for application '${clientId}' from server for tenant '${tenantId}'. Error code: ${errorResult.error}. Error message: ${errorResult.error_description}`);

            callback(null, {
                code: errorResult.error,
                message: errorResult.error_description
            });

            return;
        }

        context.log.info(`SUCCEEDED: Acquired token for application '${clientId}' from server for tenant '${tenantId}'.`);

        // We received a token so save it to the cache.
        const result = JSON.parse(responseBody);
        tokenCache[tokenCacheKey] = result;
        global.tokenCache = tokenCache;
        callback(null, null, result.access_token);
    });
}

// Create Bad Request Response
function createBadRequestErrorResponse(errorCode, errorMessage) {
    return createErrorResponse(400, errorCode, errorMessage);
}

// Create not found respose
function createNotFoundErrorResponse(errorCode, errorMessage) {
    return createErrorResponse(404, errorCode, errorMessage);
}

// Create OK response
function createOKResponse(context, user, clientId, now) {
    var email = '';
    if(user.signInNames.length > 0)
    {
        email = user.signInNames[0].value;
    }
    else
    {
        email = user.userPrincipalName;
    }
    const res = {
        body: {
            objectId: user.objectId,
            accountEnabled: user.accountEnabled,
            email: email,
            userPrincipalName: user.userPrincipalName
        }
    };

    // Set the extension properties
    res.body.extension_ContactId = getExtensionProperty(user, clientId, "ContactId");
    res.body.extension_PhoneNumber =  getExtensionProperty(user, clientId, "AuthenticationPhoneNumber");

    context.log.info(`Response to be sent back: '${JSON.stringify(res)}'.`);

    return res;
}

// Create Error Response
function createErrorResponse(statusCode, errorCode, errorMessage) {
    return {
        status: statusCode,
        body: {
            "version": "1.0.0",
            "status": statusCode,
            "userCode": errorCode,
            "userMessage": errorMessage
        }
    };
}

// Create Internal Server Response
function createInternalServerErrorErrorResponse() {
    return createErrorResponse(500, "InternalServerError", "An unexpected error has occurred.");
}

// Create Unauthorised Error Response
function createUnauthorizedErrorResponse() {
    return createErrorResponse(401, "Unauthorized", "Access is denied.");
}

// Get ExtensionProperty function
function getExtensionProperty(user, clientId, extensionPropertyName) {
    return user[`extension_${clientId.replace(/-/g, "")}_${extensionPropertyName}`];
}

// Check is success
function isSuccessStatusCode(statusCode) {
    return statusCode >= 200 && statusCode < 300;
}

// Get user from local directory.
function getUser(context, tenantId, accessToken, userId, callback) {
    context.log.info(`Getting user '${userId}' for tenant '${tenantId}'...`);

    // Try to get
    request.get({
        url: `https://graph.windows.net/${encodeURIComponent(tenantId)}/users/${encodeURIComponent(userId)}?api-version=1.6`,
        auth: {
            bearer: accessToken
        }
    }, (err, response, responseBody) => {
        if (err) {
            context.log.error(`FAILED: Got user '${userId}' for tenant '${tenantId}'. Error: ${err}.`);

            callback(err);
            return;
        }

        // We have an error
        if (!isSuccessStatusCode(response.statusCode)) {
            const errorResult = JSON.parse(responseBody);

            context.log.warn(`FAILED: Got user '${userId}' for tenant '${tenantId}'. Error code: ${errorResult["odata.error"].code}. Error description: ${errorResult["odata.error"].message.value}.`);

            callback(null, {
                code: errorResult["odata.error"].code,
                message: errorResult["odata.error"].message.value
            });

            return;
        }

        // We found the user
        const user = JSON.parse(responseBody);
        context.log.info(`SUCCEEDED: Got user ['${user.objectId}', '${user.userPrincipalName}'] for tenant '${tenantId}'.`);
        callback(null, null, user);
    });
}

// Main function entry point
module.exports = function (context, req) {
    try {
        var client = auth(req);

        // Return Unauthorised response
        if (typeof client === "undefined" || !client) {
            context.res = createUnauthorizedErrorResponse();
            context.done();
            return;
        }

        // Return Parameters Missing response
        if (typeof req.body === "undefined" || !req.body) {
            context.res = createBadRequestErrorResponse("InvalidRequest", "Parameters are missing.");
            context.done();
            return;
        }

        // **********************************
        // Validate the incoming Request data
        // **********************************

        // We must have the User.
        if ((typeof req.body.objectId === "undefined" || typeof req.body.objectId !== "string" || !req.body.objectId) && (typeof req.body.userPrincipalName === "undefined" || typeof req.body.userPrincipalName !== "string" || !req.body.userPrincipalName)) {
            context.res = createBadRequestErrorResponse("InvalidRequest", "User is missing.");
            context.done();
            return;
        }

        context.log.info(`Received request body: '${JSON.stringify(req.body)}'.`);

        // Validate the tenant name
        if (typeof process.env.tenantId === "undefined" || !process.env.tenantId) {
            context.res = createBadRequestErrorResponse("InvalidTenant", "Tenant is invalid.");
            context.done();
            return;
        }

        // Current Date/Time
        const now = Math.round(new Date().getTime() / 1000);

        // Get a token to access the Graph API
        acquireTokenForApplication(context, process.env.tenantId, client.name, client.pass, "https://graph.windows.net", now, (err, error, accessToken) => {
            try {
                if (err) {
                    context.res = createInternalServerErrorErrorResponse();
                    context.done();
                    return;
                }

                if (error) {
                    context.res = createInternalServerErrorErrorResponse();
                    context.done();
                    return;
                }
                // Get the user and return the details to the client
                getUser(context, process.env.tenantId, accessToken, req.body.objectId || req.body.userPrincipalName, (err, error, user) => {
                    try {
                        if (err) {
                            context.res = createInternalServerErrorErrorResponse();
                            context.done();
                            return;
                        }

                        // Error
                        if (error) {
                            if (error.code === "Request_ResourceNotFound") {
                                context.res = createNotFoundErrorResponse("UserNotFound", "User isn't found.");
                            } else {
                                context.res = createInternalServerErrorErrorResponse();
                            }

                            context.done();
                            return;
                        }

                        // Return the user details.
                        context.res = createOKResponse(context, user, process.env.graphApplicationClientId, now);
                        context.done();

                    } catch (err) {
                        context.log.error(`FAILED: An unexpected error has occurred. Error: ${err}.`);

                        context.res = createInternalServerErrorErrorResponse();
                        context.done();
                    }
                });
            } catch (err) {
                context.log.error(`FAILED: An unexpected error has occurred. Error: ${err}.`);

                context.res = createInternalServerErrorErrorResponse();
                context.done();
            }
        });
    } catch (err) {
        context.log.error(`FAILED: An unexpected error has occurred. Error: ${err}.`);

        context.res = createInternalServerErrorErrorResponse();
        context.done();
    }
};
