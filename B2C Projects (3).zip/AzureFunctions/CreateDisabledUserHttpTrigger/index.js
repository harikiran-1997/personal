/*
    Function:       CreateDisabledUser
    Notes:          HTTP Trigger to be called by Replying Party / Service Provider applications
    Purpose:        Creates a disabled user in the local B2C directory. Subsequent activation via the
                    Activation Service is needed before the user will be activated.
    Author:         Warwick Jaensch (Kloud Solutions)
    Date Created:   March 23rd 2018
    Revision History:
    Name:           Date:         Description:
    Adeel Nasir     16/08/2018      Check to see if ContactID already exists in B2C and is in a disabled state.
                                    IF TRUE then overright the information in B2C ELSE return an error
                                    Added the mobile validation and masking fields
                                    Added the Key Vault functionality for secrets to be fetched

*/

// The NPM Modules to include
const appInsights = require("applicationinsights");
appInsights.setup()
    .setSendLiveMetrics(process.env.appInsights_liveMetrics)
    .start();

const auth = require("basic-auth");
const crypto = require("crypto");
const https = require("https");
const request = require("request");

https.globalAgent.keepAlive = true;

// Get a token to access the Graph API
function acquireTokenForApplication(context, tenantId, clientId, clientSecret, resource, now, callback) {
    context.log.info(`Acquiring token for application '${clientId}' for tenant '${tenantId}'...`);

    // Check to see if we have the token cached
    const tokenCache = global.tokenCache || {};
    const tokenCacheKey = new Buffer.from(`${tenantId}::${resource}::${clientId}::${clientSecret}`).toString("base64");
    const tokenCacheValue = tokenCache[tokenCacheKey];

    if (typeof tokenCacheValue !== "undefined" && tokenCacheValue && now + 300 < tokenCacheValue.expires_on) {
        context.log.info(`Acquired token for application '${clientId}' from client for tenant '${tenantId}'.`);

        callback(null, null, tokenCacheValue.access_token);
        return;
    }

    // We have no cached token so we need get a new token.
    request.post({
        url: `https://login.microsoftonline.com/${encodeURIComponent(tenantId)}/oauth2/token`,
        form: {
            "grant_type": "client_credentials",
            "client_id": clientId,
            "client_secret": clientSecret,
            "resource": resource
        }
    }, (err, response, responseBody) => {
        if (err) {
            context.log.error(`FAILED: Acquired token for application '${clientId}' from server for tenant '${tenantId}'. Error: ${err}.`);
            callback(err);
            return;
        }

        // Couldn't get a token
        if (!isSuccessStatusCode(response.statusCode)) {
            const errorResult = JSON.parse(responseBody);

            context.log.warn(`FAILED: Acquired token for application '${clientId}' from server for tenant '${tenantId}'. Error code: ${errorResult.error}. Error message: ${errorResult.error_description}`);

            callback(null, {
                code: errorResult.error,
                message: errorResult.error_description
            });

            return;
        }

        context.log.info(`SUCCEEDED: Acquired token for application '${clientId}' from server for tenant '${tenantId}'.`);

        // We received a token so save it to the cache.
        const result = JSON.parse(responseBody);
        tokenCache[tokenCacheKey] = result;
        global.tokenCache = tokenCache;
        callback(null, null, result.access_token);
    });
}

// Create Bad Request Response
function createBadRequestErrorResponse(errorCode, errorMessage) {
    return createErrorResponse(400, errorCode, errorMessage);
}

// Create Conflict Error Response
function createConflictErrorResponse(errorCode, errorMessage) {
    return createErrorResponse(409, errorCode, errorMessage);
}

// Create Invalid Mobile Number Response
function createInvalidMobileNumberErrorResponse(errorCode, errorMessage) {
    return createErrorResponse(410, errorCode, errorMessage);
}

// Create REST API Response function
function createCreatedResponse(context, user, clientId, ttl, digitalSignature) {
    const res = {
        status: 201,
        body: {
            accountEnabled: user.accountEnabled,
            userPrincipalName: user.userPrincipalName,
            objectId: user.objectId,
            expiryTime: ttl,
            signature: digitalSignature
         }
    };

    // Set the extension properties
    res.body.extension_ContactId = getExtensionProperty(user, clientId, "ContactId");
    res.body.extension_PhoneNumber =  getExtensionProperty(user, clientId, "AuthenticationPhoneNumber");

    context.log.info(`Response to be sent back: '${JSON.stringify(res)}'.`);
    // return Response
    return res;
}

// Create Error Response
function createErrorResponse(statusCode, errorCode, errorMessage) {
    return {
        status: statusCode,
        body: {
            "version": "1.0.0",
            "status": statusCode,
            "userCode": errorCode,
            "userMessage": errorMessage
        }
    };
}

// Create Internal Server Response
function createInternalServerErrorErrorResponse() {
    return createErrorResponse(500, "InternalServerError", "An unexpected error has occurred.");
}

// Create Unauthorised Error Response
function createUnauthorizedErrorResponse() {
    return createErrorResponse(401, "Unauthorized", "Access is denied.");
}

// Create User function - creates a user with the Graph API
function createUser(context, tenantId, accessToken, signInName, userToBeCreated, graphApplicationClientId, extension_AuthenticationPhoneNumber, overwriteUser, callback) {

    if(overwriteUser === "true")
    {
        //Check the user based on contact Id if it exists or not
        const contactId= getExtensionProperty(userToBeCreated, graphApplicationClientId, "ContactId");
    	context.log.info(`Checking user contact Id if it already exist '${contactId}' for tenant '${tenantId}'...`);

        var extensionProperty = "extension_" + graphApplicationClientId.replace(/-/g, "") + "_ContactId";

    	context.log.info(`Extension Property variable created to query the Graph API:'${extensionProperty}'`);

        let url= `https://graph.windows.net/${encodeURIComponent(tenantId)}/users/?api-version=1.6&$filter=${encodeURIComponent(extensionProperty)} eq '${encodeURIComponent(contactId)}' and accountEnabled eq false`;

        context.log.info(`URL created to query the Graph API:'${url}'`);

        // Attempt to get user by contact ID in disabled state
        request.get({
            url: url,
            auth: {
                bearer: accessToken
            }
        }, (err, response, responseBody) => {
            // We couldnt get the user from the directory
            if (err) {
            	context.log.error(`FAILED: While getting user by contact Id '${contactId}' for tenant '${tenantId}'. Error: ${err}.`);

                callback(err);
                return;
            }

            if (!isSuccessStatusCode(response.statusCode)) {
                const errorResult = JSON.parse(responseBody);

                context.log.warn(`FAILED: While getting user by contact Id '${contactId}' for tenant '${tenantId}'. Error code: ${errorResult["odata.error"].code}. Error description: ${errorResult["odata.error"].message.value}.`);

                callback(null, {
                    code: errorResult["odata.error"].code,
                    message: errorResult["odata.error"].message.value
                });

                return;
            }

            // Success
            const existingUsers = JSON.parse(responseBody);
            if(existingUsers !=="undefined")
            {
                context.log.info(`ExistingUsers found, count: '${existingUsers.value.length}'.`);
            }
            else
            {
                context.log.info("No existingUsers found");
            }

            if(existingUsers.value.length > 1)
            {
            	context.log.error(`Multiple users already exists against this Contact Id. Count: '${existingUsers.value.length}'.`);

                callback(null, {
                    code: 'Request_BadRequest_ContactId',
                    message: 'Multiple users already exists against this Contact Id.'
                });
            }
            else if(existingUsers.value.length === 1)
            {
                const existingUser = existingUsers.value[0];
            	context.log.info(`Got disabled user against contact Id [objecId: '${existingUser.objectId}', UPN: '${existingUser.userPrincipalName}'] for tenant '${tenantId}'.`);

                if (existingUser.signInNames[0].type === 'emailAddress' && existingUser.signInNames[0].value === signInName.trim())
                {
                    // Populate the user object
                    const userToBeUpdated = {
                    };
                    // Set the regular and masked Authentication Phone number
                    if (typeof extension_AuthenticationPhoneNumber !== "undefined" && extension_AuthenticationPhoneNumber) {
                        setExtensionProperty(userToBeUpdated, graphApplicationClientId, "AuthenticationPhoneNumber", extension_AuthenticationPhoneNumber.trim());
                        setExtensionProperty(userToBeUpdated, graphApplicationClientId, "MaskedAuthenticationPhoneNumber", MaskMobileNumber(extension_AuthenticationPhoneNumber.trim()));
                    }
                    //context.log.info('userToBeUpdated:'+userToBeUpdated);
                    //call update user
                    context.log.info(`Updating user '${signInName}' phone number '${extension_AuthenticationPhoneNumber}' for tenant '${tenantId}'...`);

                    updateUser(context, tenantId, accessToken, userToBeUpdated, graphApplicationClientId, contactId, existingUser.objectId, (err, error) => {
                        // Internal Error
                        if (err) {
                            context.res = createInternalServerErrorErrorResponse();
                            context.done();
                            return;
                        }
                        // Object already exists
                        if (error) {
                            if (error.code === "Request_BadRequest") {
                                context.res = createConflictErrorResponse("InvalidUser", `User already exists. ${error.message}`);
                            } else {
                                context.res = createInternalServerErrorErrorResponse();
                            }
                            context.done();
                            return;
                        }

                        // Success
                        context.log.info(`SUCCEEDED: Updating user ['${signInName}'] phone number for tenant '${tenantId}'.`);

                        //updating it so that we can return the updated properties in the response.
                        setExtensionProperty(existingUser, graphApplicationClientId, "ContactId", getExtensionProperty(userToBeCreated, graphApplicationClientId, "ContactId"));
                        setExtensionProperty(existingUser, graphApplicationClientId, "AuthenticationPhoneNumber", extension_AuthenticationPhoneNumber.trim());

                        callback(null, null, existingUser);
                        });
                }
                else
                {
                    callback(null, {
                        code: 'Request_BadRequest_SignIn',
                        message: 'The user doesnt exist with the provided sign in name, existing disabled user is: '+existingUser.signInNames[0].value
                    });
                }

            }
            else
            {
                postUserCreation(context, tenantId, accessToken, signInName, userToBeCreated, callback);
            }
        });
    }
    else
    {
        postUserCreation(context, tenantId, accessToken, signInName, userToBeCreated, callback);
    }
}

//post the user to be created to graph API for actual user creation
function postUserCreation(context, tenantId, accessToken, signInName, userToBeCreated, callback)
{
    context.log.info(`Creating user '${signInName}' for tenant '${tenantId}'...`);

    // Attempt to create the user
    request.post({
        url: `https://graph.windows.net/${encodeURIComponent(tenantId)}/users?api-version=1.6`,
        auth: {
            bearer: accessToken
        },
        body: userToBeCreated,
        json: true
    }, (err, response, responseBody) => {
        // Create user failed
        if (err) {
            context.log.error(`FAILED: Creating user '${signInName}' for tenant '${tenantId}'. Error: ${err}.`);

            callback(err);
            return;
        }

        if (!isSuccessStatusCode(response.statusCode)) {
            const errorResult = responseBody;

            context.log.error(`FAILED: Creating user '${signInName}' for tenant '${tenantId}'. Error code: ${errorResult["odata.error"].code}. Error message: ${errorResult["odata.error"].message.value}`);

            callback(null, {
                code: errorResult["odata.error"].code,
                message: errorResult["odata.error"].message.value
            });

            return;
        }

        // Success
        const createdUser = responseBody;
        context.log.info(`SUCCEEDED: Creating user ['${createdUser.objectId}', '${signInName}', '${createdUser.userPrincipalName}'] for tenant '${tenantId}'.`);

        callback(null, null, createdUser);
    });
}

// Get ExtensionProperty function
function getExtensionProperty(user, clientId, extensionPropertyName) {
    return user[`extension_${clientId.replace(/-/g, "")}_${extensionPropertyName}`];
}

// Check to see if we have a Status Code
function isSuccessStatusCode(statusCode) {
    return statusCode >= 200 && statusCode < 300;
}

// Set ExtensionProperty function
function setExtensionProperty(user, clientId, extensionPropertyName, extensionPropertyValue) {
    user[`extension_${clientId.replace(/-/g, "")}_${extensionPropertyName}`] = extensionPropertyValue;
}

// Mask Mobile Number
function MaskMobileNumber(mobileNumber) {
    let result="";

    if (typeof mobileNumber !== "undefined" && mobileNumber.length >= 10)
    {
        let maskedCharLength = mobileNumber.length - 7; //4 chars from start and 3 chars from the end
        let maskChar = 'X';

        result += mobileNumber.substring(0, 4);
        result += maskChar.repeat(maskedCharLength);
        result += mobileNumber.substring(mobileNumber.length - 3);
    }
    return result;
}

// Update User in B2C
function updateUser(context, tenantId, accessToken, user, graphApplicationClientId, contactId, objectId, callback) {
    context.log.info(`Updating user contact Id '${contactId}' for tenant '${tenantId}'...`);

    var phoneNumber = getExtensionProperty(user, graphApplicationClientId, "AuthenticationPhoneNumber")
    // Attempt to update
    request.patch({
        url: `https://graph.windows.net/${encodeURIComponent(tenantId)}/users/${encodeURIComponent(objectId)}?api-version=1.6`,
        auth: {
            bearer: accessToken
        },
        body: user,
        json: true
    }, (err, response, responseBody) => {
        // We couldnt update the user
        if (err) {

            context.log.error(`FAILED: Updating user contact Id '${contactId}' with phone number '${phoneNumber}' for tenant '${tenantId}'. Error: ${err}.`);

            callback(err);
            return;
        }

        if (!isSuccessStatusCode(response.statusCode)) {
            const errorResult = JSON.parse(responseBody);

            context.log.error(`FAILED: Updating user contact Id '${contactId}' with phone number '${phoneNumber}' for tenant '${tenantId}'. Error code: ${errorResult["odata.error"].code}. Error message: ${errorResult["odata.error"].message.value}`);

            callback(null, {
                code: errorResult["odata.error"].code,
                message: errorResult["odata.error"].message.value
            });

            return;
        }

        // Success
        context.log.info(`SUCCEEDED: Updating user contact Id '${contactId}' with phone number '${phoneNumber}' for tenant '${tenantId}'.`);

        callback(null, null);
    });
}

// Main function entry point
module.exports = function (context, req) {
    try {

        // Validate the tenant name
        if (typeof process.env.tenantId === "undefined" || !process.env.tenantId) {
            context.res = createBadRequestErrorResponse("InvalidTenant", "Tenant is invalid.");
            context.done();
            return;
        }

        var client = auth(req);

        // Return Unauthorised response
        if (typeof client === "undefined" || !client) {
            context.res = createUnauthorizedErrorResponse();
            context.done();
            return;
        }

        // Return Parameters Missing response
        if (typeof req.body === "undefined" || !req.body) {
            context.res = createBadRequestErrorResponse("InvalidRequest", "Parameters are missing.");
            context.done();
            return;
        }

        // **********************************
        // Validate the incoming Request data
        // **********************************

        // We must have the sign-in name.
        if (typeof req.body.signInName === "undefined" || typeof req.body.signInName !== "string" || !req.body.signInName) {
            context.res = createBadRequestErrorResponse("InvalidRequest", "Sign-in name is missing.");
            context.done();
            return;
        }

        // We must have the ContactID
        if (typeof req.body.extension_ContactId === "undefined" || typeof req.body.extension_ContactId !== "string" || !req.body.extension_ContactId) {
            context.res = createBadReqestErrorResponse("InvalidRequest", "Contact ID is missing.");
            context.done();
            return;
        }

        let overwriteUser = "true";
        // Create multiple user against same ContactID ?
        if (typeof req.body.overwriteIfSPIDExists === "undefined" || typeof req.body.overwriteIfSPIDExists !== "string" || !req.body.overwriteIfSPIDExists) {
            context.log.info("overwriteIfSPIDExists is being default to:" + overwriteUser);//Create multiple users
        }
        else
        {
            overwriteUser = req.body.overwriteIfSPIDExists;//Dont create multiple users if false else do
            context.log.info("overwriteIfSPIDExists is being set to:" + req.body.overwriteIfSPIDExists);
        }

        context.log.info(`Received request body: '${JSON.stringify(req.body)}'.`);

        // Current Date/Time
        const now = Math.round(new Date().getTime() / 1000);

        // Add 5 minutes to the current time
        const expiryActivation = new Date().getTime() + (5 * 60 * 1000);
        const the_TTL = Math.round(expiryActivation / 1000);

        // Get a token to access the Graph API
        acquireTokenForApplication(context, process.env.tenantId, client.name, client.pass, "https://graph.windows.net", now, (err, error, accessToken) => {
            try {
                if (err) {
                    context.res = createInternalServerErrorErrorResponse();
                    context.done();
                    return;
                }

                if (error) {
                    context.res = createInternalServerErrorErrorResponse();
                    context.done();
                    return;
                }

                // The resulting string is twice as long as the random bytes (each byte is encoded to hex which is 2 characters).
                // 20 bytes will be 40 characters of hex => f26d60305dae929ef8640a75e70dd78ab809cfe9
                const thePwdRnd = crypto.randomBytes(20).toString('hex');

                // Populate the user object
                const userToBeCreated = {
                    accountEnabled: false,
                    creationType: "LocalAccount",
                    displayName: req.body.signInName.trim(),
                    passwordPolicies: "DisablePasswordExpiration, DisableStrongPassword",
                    passwordProfile: {
                        forceChangePasswordNextLogin: false,
                        password: thePwdRnd
                    },
                    signInNames: [
                        {
                            type: "emailAddress",
                            value: req.body.signInName.trim()
                        }
                    ]
                };

                // Retrieve the ContactId Extension from the Request Body
                if (typeof req.body.extension_ContactId !== "undefined" && req.body.extension_ContactId) {
                    setExtensionProperty(userToBeCreated, process.env.graphApplicationClientId, "ContactId", req.body.extension_ContactId.trim());
                }

                let mobileNumber="";
                // Set the regular and masked Authentication Phone number
                if (typeof req.body.extension_AuthenticationPhoneNumber !== "undefined" && req.body.extension_AuthenticationPhoneNumber) {

                    mobileNumber = req.body.extension_AuthenticationPhoneNumber.trim().replace(/ /g, "");

                    if(mobileNumber.length > 0)
                    {
                        if ((mobileNumber.length < 9 || mobileNumber.length > 13) || (!mobileNumber.startsWith("+614") && !mobileNumber.startsWith("+64") && !mobileNumber.startsWith("614") && !mobileNumber.startsWith("64") && !mobileNumber.startsWith("04") && !mobileNumber.startsWith("4"))) {
                            context.res = createInvalidMobileNumberErrorResponse("InvalidMobile", "Invalid mobile number");
                            context.done();
                            return;
                        }
                        else {
                            if (mobileNumber.startsWith("614") || mobileNumber.startsWith("64")) {
                                mobileNumber = "+" + mobileNumber;
                            }
                            else if (mobileNumber.startsWith("04")) {
                                mobileNumber = "+61" + mobileNumber.substr(1);
                            }
                            else if (mobileNumber.startsWith("4")) {
                                mobileNumber = "+61" + mobileNumber;
                            }
                        }
                    }
                }
                setExtensionProperty(userToBeCreated, process.env.graphApplicationClientId, "AuthenticationPhoneNumber", mobileNumber);
                setExtensionProperty(userToBeCreated, process.env.graphApplicationClientId, "MaskedAuthenticationPhoneNumber", MaskMobileNumber(mobileNumber));

                // Set the masked email address
                setExtensionProperty(userToBeCreated, process.env.graphApplicationClientId, "MaskedAuthenticationEmail", req.body.signInName.trim().replace(/^(.)(.*)(.@.*)$/, (_, a, b, c) => a + b.replace(/./g, '*') + c));

                // Set the ForceChangePasswordNextSignIn flag
                setExtensionProperty(userToBeCreated, process.env.graphApplicationClientId, "ForceChangePasswordNextSignIn", "False");

                // Set the UserSource to API so we differentiate if the user was migrated from OSC via the UserMigrationTool or created in 'real-time' by the API.
                setExtensionProperty(userToBeCreated, process.env.graphApplicationClientId, "UserSource", "API");

                // Create the user
                createUser(context, process.env.tenantId, accessToken, req.body.signInName, userToBeCreated, process.env.graphApplicationClientId, mobileNumber, overwriteUser, (err, error, createdUser) => {
                    try {
                        // Internal Error
                        if (err) {
                            context.res = createInternalServerErrorErrorResponse();
                            context.done();
                            return;
                        }

                        // Object already exists
                        if (error) {
                            if (error.code === "Request_BadRequest") {
                                context.res = createConflictErrorResponse("InvalidUser", `User already exists. ${error.message}`);
                            }
                            else if (error.code === "Request_BadRequest_ContactId" || error.code === "Request_BadRequest_SignIn") {
                                context.res = createConflictErrorResponse("InvalidUser", error.message);
                            }
                            else {
                                context.res = createInternalServerErrorErrorResponse();
                            }

                            context.done();
                            return;
                        }

                        // Create the Digital Signature
                        try {
                            // Use hash-based message authentication code (HMAC) using sha512
                            const hmac = crypto.createHmac('sha512', process.env.signatureSecretKey);

                            // String to digitally sign
                            hmac.update(`'${createdUser.objectId}'\n'${the_TTL}'`);

                            // Get the signature
                            const the_signature = hmac.digest('hex');
                            context.log.info(`SUCCEEDED: Using signature '${the_signature}'...`);

                            // Create the response
                            try {
                                context.res = createCreatedResponse(context, createdUser, process.env.graphApplicationClientId, the_TTL, the_signature);
                                context.done();
                            } catch (err) {
                                context.log.error(`FAILED: An unexpected error has occurred. Error: ${err}.`);

                                context.res = createInternalServerErrorErrorResponse();
                                context.done();
                            }
                        } catch (err) {
                            context.log.error(`FAILED: An unexpected error has occurred. Error: ${err}.`);

                            context.res = createInternalServerErrorErrorResponse();
                            context.done();
                        }
                    } catch (err) {
                        context.log.error(`FAILED: An unexpected error has occurred. Error: ${err}.`);

                        context.res = createInternalServerErrorErrorResponse();
                        context.done();
                    }
                });
            } catch (err) {
                context.log.error(`FAILED: An unexpected error has occurred. Error: ${err}.`);

                context.res = createInternalServerErrorErrorResponse();
                context.done();
            }
        });

    } catch (err) {
        context.log.error(`FAILED: An unexpected error has occurred. Error: ${err}.`);

        context.res = createInternalServerErrorErrorResponse();
        context.done();
    }
};
