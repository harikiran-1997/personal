/*
    Function:       UpdateUserProfile
    Notes:          HTTP Trigger to be called by Replying Party / Service Provider applications
    Purpose:        Update a user's profile data.
    Author:         Warwick Jaensch (Kloud Solutions)
    Date Created:   March 26th 2018
    Revision History:
    Name:           Date:         Description:

*/

// The NPM Modeules to include
const appInsights = require("applicationinsights");
appInsights.setup()
    .setSendLiveMetrics(process.env.appInsights_liveMetrics)
    .start();

const auth = require("basic-auth");
const https = require("https");
const request = require("request");

https.globalAgent.keepAlive = true;

// Get a token to access the Graph API
function acquireTokenForApplication(context, tenantId, clientId, clientSecret, resource, now, callback) {
    context.log.info(`Acquiring token for application '${clientId}' for tenant '${tenantId}'...`);

    const tokenCache = global.tokenCache || {};
    const tokenCacheKey = new Buffer.from(`${tenantId}::${resource}::${clientId}::${clientSecret}`).toString("base64");
    const tokenCacheValue = tokenCache[tokenCacheKey];

    if (typeof tokenCacheValue !== "undefined" && tokenCacheValue && now + 300 < tokenCacheValue.expires_on) {
        context.log.info(`Acquired token for application '${clientId}' from client for tenant '${tenantId}'.`);

        callback(null, null, tokenCacheValue.access_token);
        return;
    }

    request.post({
        url: `https://login.microsoftonline.com/${encodeURIComponent(tenantId)}/oauth2/token`,
        form: {
            "grant_type": "client_credentials",
            "client_id": clientId,
            "client_secret": clientSecret,
            "resource": resource
        }
    }, (err, response, responseBody) => {
        if (err) {
            context.log.error(`FAILED: Acquired token for application '${clientId}' from server for tenant '${tenantId}'. Error: ${err}.`);
            callback(err);
            return;
        }

        if (!isSuccessStatusCode(response.statusCode)) {
            const errorResult = JSON.parse(responseBody);

            context.log.warn(`FAILED: Acquired token for application '${clientId}' from server for tenant '${tenantId}'. Error code: ${errorResult.error}. Error message: ${errorResult.error_description}`);

            callback(null, {
                code: errorResult.error,
                message: errorResult.error_description
            });

            return;
        }

        context.log.info(`SUCCEEDED: Acquired token for application '${clientId}' from server for tenant '${tenantId}'.`);

        const result = JSON.parse(responseBody);
        tokenCache[tokenCacheKey] = result;
        global.tokenCache = tokenCache;
        callback(null, null, result.access_token);
    });
}

function createBadRequestErrorResponse(errorCode, errorMessage) {
    return createErrorResponse(400, errorCode, errorMessage);
}

function createNotFoundErrorResponse(errorCode, errorMessage) {
    return createErrorResponse(404, errorCode, errorMessage);
}

function createConflictErrorResponse(errorCode, errorMessage) {
    return createErrorResponse(409, errorCode, errorMessage);
}

// Create Invalid Mobile Number Response
function createInvalidMobileNumberErrorResponse(errorCode, errorMessage) {
    return createErrorResponse(410, errorCode, errorMessage);
}

function createOKResponse(context, user, clientId, userToBeUpdated) {
    var email = '';
    if(user.signInNames.length > 0)
    {
        email = user.signInNames[0].value;
    }
    else
    {
        email = user.userPrincipalName;
    }
    const res = {
        body: {
            objectId: user.objectId,
            accountEnabled: user.accountEnabled,
            email: email,
            userPrincipalName: user.userPrincipalName
        }
    };

    // Set the extension properties
    //because userToBeUpdated has the latest contact Id and phone number which is updated, to avoid another call to graph API we just return what got updated
    res.body.extension_ContactId = getExtensionProperty(userToBeUpdated, clientId, "ContactId");
    res.body.extension_PhoneNumber =  getExtensionProperty(userToBeUpdated, clientId, "AuthenticationPhoneNumber");

    context.log.info(`Response to be sent back: '${JSON.stringify(res)}'.`);

    return res;
}

function createErrorResponse(statusCode, errorCode, errorMessage) {
    return {
        status: statusCode,
        body: {
            "version": "1.0.0",
            "status": statusCode,
            "userCode": errorCode,
            "userMessage": errorMessage
        }
    };
}

function createInternalServerErrorErrorResponse() {
    return createErrorResponse(500, "InternalServerError", "An unexpected error has occurred.");
}

function createUnauthorizedErrorResponse() {
    return createErrorResponse(401, "Unauthorized", "Access is denied.");
}

// Get ExtensionProperty function
function getExtensionProperty(user, clientId, extensionPropertyName) {
    return user[`extension_${clientId.replace(/-/g, "")}_${extensionPropertyName}`];
}

function isSuccessStatusCode(statusCode) {
    return statusCode >= 200 && statusCode < 300;
}

// Get ExtensionProperty function
function getExtensionProperty(user, clientId, extensionPropertyName) {
    return user[`extension_${clientId.replace(/-/g, "")}_${extensionPropertyName}`];
}

function isSuccessStatusCode(statusCode) {
    return statusCode >= 200 && statusCode < 300;
}

// Set ExtensionProperty function
function setExtensionProperty(user, clientId, extensionPropertyName, extensionPropertyValue) {
    user[`extension_${clientId.replace(/-/g, "")}_${extensionPropertyName}`] = extensionPropertyValue;
}

// Mask Mobile Number
function MaskMobileNumber(mobileNumber) {
    let result="";

    if (typeof mobileNumber !== "undefined" && mobileNumber.length >= 10)
    {
        let maskedCharLength = mobileNumber.length - 7; //4 chars from start and 3 chars from the end
        let maskChar = 'X';

        result += mobileNumber.substring(0, 4);
        result += maskChar.repeat(maskedCharLength);
        result += mobileNumber.substring(mobileNumber.length - 3);
    }
    return result;
}

function getUser(context, tenantId, accessToken, userId, callback) {
    context.log.info(`Getting user '${userId}' for tenant '${tenantId}'...`);

    request.get({
        url: `https://graph.windows.net/${encodeURIComponent(tenantId)}/users/${encodeURIComponent(userId)}?api-version=1.6`,
        auth: {
            bearer: accessToken
        }
    }, (err, response, responseBody) => {
        if (err) {
            context.log.error(`FAILED: Got user '${userId}' for tenant '${tenantId}'. Error: ${err}.`);

            callback(err);
            return;
        }

        if (!isSuccessStatusCode(response.statusCode)) {
            const errorResult = JSON.parse(responseBody);

            context.log.warn(`FAILED: Got user '${userId}' for tenant '${tenantId}'. Error code: ${errorResult["odata.error"].code}. Error description: ${errorResult["odata.error"].message.value}.`);

            callback(null, {
                code: errorResult["odata.error"].code,
                message: errorResult["odata.error"].message.value
            });

            return;
        }

        const user = JSON.parse(responseBody);

        context.log.info(`SUCCEEDED: Got user ['${user.objectId}', '${user.userPrincipalName}'] for tenant '${tenantId}'.`);

        callback(null, null, user);
    });
}

// Update User function
function updateUser(context, tenantId, accessToken, user, callback) {
    context.log.info(`Updating user '${user.objectId}' for tenant '${tenantId}'...`);

    request.patch({
        url: `https://graph.windows.net/${encodeURIComponent(tenantId)}/users/${encodeURIComponent(user.objectId)}?api-version=1.6`,
        auth: {
            bearer: accessToken
        },
        body: user,
        json: true
    }, (err, response, responseBody) => {
        if (err) {
            context.log.error(`FAILED: Updated user '${user.objectId}' for tenant '${tenantId}'. Error: ${err}.`);

            callback(err);
            return;
        }

        if (!isSuccessStatusCode(response.statusCode)) {
            const errorResult = JSON.parse(responseBody);

            context.log.warn(`FAILED: Updated user '${user.objectId}' for tenant '${tenantId}'. Error code: ${errorResult["odata.error"].code}. Error message: ${errorResult["odata.error"].message.value}`);

            callback(null, {
                code: errorResult["odata.error"].code,
                message: errorResult["odata.error"].message.value
            });

            return;
        }

        context.log.info(`SUCCEEDED: Updated user '${user.objectId}' for tenant '${tenantId}'.`);

        callback(null, null);
    });
}

module.exports = function (context, req) {
    try {
        var client = auth(req);

        // Return Unauthorised response
        if (typeof client === "undefined" || !client) {
            context.res = createUnauthorizedErrorResponse();
            context.done();
            return;
        }

        // Return Parameters Missing response
        if (typeof req.body === "undefined" || !req.body) {
            context.res = createBadRequestErrorResponse("InvalidRequest", "Parameters are missing.");
            context.done();
            return;
        }

        // **********************************
        // Validate the incoming Request data
        // **********************************

        // We must have the User.
        if ((typeof req.body.objectId === "undefined" || typeof req.body.objectId !== "string" || !req.body.objectId) && (typeof req.body.userPrincipalName === "undefined" || typeof req.body.userPrincipalName !== "string" || !req.body.userPrincipalName)) {
            context.res = createBadRequestErrorResponse("InvalidRequest", "User is missing.");
            context.done();
            return;
        }

        // We must have the sign-in name.
        //if (typeof req.body.signInName === "undefined" || typeof req.body.signInName !== "string" || !req.body.signInName) {
        //    context.res = createBadRequestErrorResponse("InvalidRequest", "Sign-in name is missing.");
        //    context.done();
        //    return;
        //}

        // We must have the ContactID
        if (typeof req.body.extension_ContactId === "undefined" || typeof req.body.extension_ContactId !== "string" || !req.body.extension_ContactId) {
            context.res = createBadRequestErrorResponse("InvalidRequest", "Contact ID is missing.");
            context.done();
            return;
        }

        context.log.info(`Received request body: '${JSON.stringify(req.body)}'.`);

        // Validate the tenant name
        if (typeof process.env.tenantId === "undefined" || !process.env.tenantId) {
            context.res = createBadRequestErrorResponse("InvalidTenant", "Tenant is invalid.");
            context.done();
            return;
        }

        // Current Date/Time
        const now = Math.round(new Date().getTime() / 1000);

        acquireTokenForApplication(context, process.env.tenantId, client.name, client.pass, "https://graph.windows.net", now, (err, error, accessToken) => {
            try {
                if (err) {
                    context.res = createInternalServerErrorErrorResponse();
                    context.done();
                    return;
                }

                if (error) {
                    context.res = createInternalServerErrorErrorResponse();
                    context.done();
                    return;
                }

                getUser(context, process.env.tenantId, accessToken, req.body.objectId || req.body.userPrincipalName, (err, error, user) => {
                    try {
                        if (err) {
                            context.res = createInternalServerErrorErrorResponse();
                            context.done();
                            return;
                        }

                        if (error) {
                            if (error.code === "Request_ResourceNotFound") {
                                context.res = createNotFoundErrorResponse("UserNotFound", "User isn't found.");
                            } else {
                                context.res = createInternalServerErrorErrorResponse();
                            }

                            context.done();
                            return;
                        }
                        // Populate the user object to be patched, dont patch the whole user object, it gave error because get user returned "<thumbnailPhoto@odata.mediaEditLink >" which cant be patched.
                        const userToBeUpdated = {
                            objectId: user.objectId
                        };

                        // Retrieve the ContactId Extension from the Request Body
                        if (typeof req.body.extension_ContactId !== "undefined" && req.body.extension_ContactId) {
                            setExtensionProperty(userToBeUpdated, process.env.graphApplicationClientId, "ContactId", req.body.extension_ContactId.trim());
                        }

                        let mobileNumber="";
                        // Set the Authentication Phone number
                        if (typeof req.body.extension_AuthenticationPhoneNumber !== "undefined" && req.body.extension_AuthenticationPhoneNumber) {

                            mobileNumber = req.body.extension_AuthenticationPhoneNumber.trim().replace(/ /g, "");

                            if(mobileNumber.length > 0)
                            {
                                if ((mobileNumber.length < 9 || mobileNumber.length > 13) || (!mobileNumber.startsWith("+614") && !mobileNumber.startsWith("+64") && !mobileNumber.startsWith("614") && !mobileNumber.startsWith("64") && !mobileNumber.startsWith("04") && !mobileNumber.startsWith("4"))) {
                                    context.res = createInvalidMobileNumberErrorResponse("InvalidMobile", "Invalid mobile number");
                                    context.done();
                                    return;
                                }
                                else {
                                    if (mobileNumber.startsWith("614") || mobileNumber.startsWith("64")) {
                                        mobileNumber = "+" + mobileNumber;
                                    }
                                    else if (mobileNumber.startsWith("04")) {
                                        mobileNumber = "+61" + mobileNumber.substr(1);
                                    }
                                    else if (mobileNumber.startsWith("4")) {
                                        mobileNumber = "+61" + mobileNumber;
                                    }
                                }
                            }
                        }
                        setExtensionProperty(userToBeUpdated, process.env.graphApplicationClientId, "AuthenticationPhoneNumber", mobileNumber);
                        setExtensionProperty(userToBeUpdated, process.env.graphApplicationClientId, "MaskedAuthenticationPhoneNumber", MaskMobileNumber(mobileNumber));

                        // Now update the user
                        updateUser(context, process.env.tenantId, accessToken, userToBeUpdated, (err, error) => {
                            try {
                                if (err) {
                                    context.res = createInternalServerErrorErrorResponse();
                                    context.done();
                                    return;
                                }

                                if (error) {
                                    context.res = createInternalServerErrorErrorResponse();
                                    context.done();
                                    return;
                                }

                                context.res = createOKResponse(context, user, process.env.graphApplicationClientId, userToBeUpdated);
                                context.done();
                            } catch (err) {
                                context.log.error(`FAILED: An unexpected error has occurred. Error: ${err}.`);

                                context.res = createInternalServerErrorErrorResponse();
                                context.done();
                            }
                        });
                    } catch (err) {
                        context.log.error(`FAILED: An unexpected error has occurred. Error: ${err}.`);

                        context.res = createInternalServerErrorErrorResponse();
                        context.done();
                    }
                });
            } catch (err) {
                context.log.error(`FAILED: An unexpected error has occurred. Error: ${err}.`);

                context.res = createInternalServerErrorErrorResponse();
                context.done();
            }
        });
    } catch (err) {
        context.log.error(`FAILED: An unexpected error has occurred. Error: ${err}.`);

        context.res = createInternalServerErrorErrorResponse();
        context.done();
    }
};
