/*
    Function:       Find Users With ContactId httptrigger
    Notes:          HTTP Trigger to be called by Replying Party / Service Provider applications
    Purpose:        Return users given a specified ContactID.
    Author:         Warwick Jaensch (Kloud Solutions)
    Date Created:   March 26th 2018
    Revision History:
    Name:           Date:         Description:

*/

// The NPM Modeules to include
const appInsights = require("applicationinsights");
appInsights.setup()
    .setSendLiveMetrics(process.env.appInsights_liveMetrics)
    .start();

const auth = require("basic-auth");
const https = require("https");
const request = require("request");

https.globalAgent.keepAlive = true;

// Get a token to access the Graph API
function acquireTokenForApplication(context, tenantId, clientId, clientSecret, resource, now, callback) {
    context.log.info(`Acquiring token for application '${clientId}' for tenant '${tenantId}'...`);

    const tokenCache = global.tokenCache || {};
    const tokenCacheKey = new Buffer.from(`${tenantId}::${resource}::${clientId}::${clientSecret}`).toString("base64");
    const tokenCacheValue = tokenCache[tokenCacheKey];

    if (typeof tokenCacheValue !== "undefined" && tokenCacheValue && now + 300 < tokenCacheValue.expires_on) {
        context.log.info(`Acquired token for application '${clientId}' from client for tenant '${tenantId}'.`);

        callback(null, null, tokenCacheValue.access_token);
        return;
    }

    request.post({
        url: `https://login.microsoftonline.com/${encodeURIComponent(tenantId)}/oauth2/token`,
        form: {
            "grant_type": "client_credentials",
            "client_id": clientId,
            "client_secret": clientSecret,
            "resource": resource
        }
    }, (err, response, responseBody) => {
        if (err) {
            context.log.error(`FAILED: Acquired token for application '${clientId}' from server for tenant '${tenantId}'. Error: ${err}.`);
            callback(err);
            return;
        }

        if (!isSuccessStatusCode(response.statusCode)) {
            const errorResult = JSON.parse(responseBody);

            context.log.warn(`FAILED: Acquired token for application '${clientId}' from server for tenant '${tenantId}'. Error code: ${errorResult.error}. Error message: ${errorResult.error_description}`);

            callback(null, {
                code: errorResult.error,
                message: errorResult.error_description
            });

            return;
        }

        context.log.info(`SUCCEEDED: Acquired token for application '${clientId}' from server for tenant '${tenantId}'.`);

        const result = JSON.parse(responseBody);
        tokenCache[tokenCacheKey] = result;
        global.tokenCache = tokenCache;
        callback(null, null, result.access_token);
    });
}

function createBadRequestErrorResponse(errorCode, errorMessage) {
    return createErrorResponse(400, errorCode, errorMessage);
}

function createNotFoundErrorResponse(errorCode, errorMessage) {
    return createErrorResponse(404, errorCode, errorMessage);
}

function createOKResponse(context, users, clientId, now) {
    const res = {
        body: {
            found: users.value.length,
            objectIDs: [],
        }
    };

    // Loop through each result and return the ObjectID's using lodash map function
    res.body.objectIDs = users.value.map(user => user.objectId);

    context.log.info(`Response to be sent back: '${JSON.stringify(res)}'.`);

    return res;
}

function createErrorResponse(statusCode, errorCode, errorMessage) {
    return {
        status: statusCode,
        body: {
            "version": "1.0.0",
            "status": statusCode,
            "userCode": errorCode,
            "userMessage": errorMessage
        }
    };
}

function createInternalServerErrorErrorResponse() {
    return createErrorResponse(500, "InternalServerError", "An unexpected error has occurred.");
}

function createUnauthorizedErrorResponse() {
    return createErrorResponse(401, "Unauthorized", "Access is denied.");
}

// Get ExtensionProperty function
function getExtensionProperty(user, clientId, extensionPropertyName) {
    return user[`extension_${clientId.replace(/-/g, "")}_${extensionPropertyName}`];
}

// Set ExtensionProperty function
function setExtensionPropertyForFilter(clientId, extensionPropertyName) {
    //return user[`extension_${clientId.replace(/-/g, "")}_${extensionPropertyName}`];
    return `extension_${clientId.replace(/-/g, "")}_${extensionPropertyName}`;
}

function isSuccessStatusCode(statusCode) {
    return statusCode >= 200 && statusCode < 300;
}

function getUsers(context, tenantId, accessToken, contactId, extensionProperty, callback) {
    context.log.info(`Getting users with ContactId '${contactId}' for tenant '${tenantId}'...`);

    request.get({
        url: `https://graph.windows.net/${encodeURIComponent(tenantId)}/users?api-version=1.6&$filter=${encodeURIComponent(extensionProperty)} eq '${encodeURIComponent(contactId)}'`,
        auth: {
            bearer: accessToken
        }
    }, (err, response, responseBody) => {
        if (err) {
            context.log.error(`FAILED: Got contact '${contactId}' for tenant '${tenantId}'. Error: ${err}.`);

            callback(err);
            return;
        }

        if (!isSuccessStatusCode(response.statusCode)) {
            const errorResult = JSON.parse(responseBody);

            context.log.warn(`FAILED: Got contact '${contactId}' for tenant '${tenantId}'. Error code: ${errorResult["odata.error"].code}. Error description: ${errorResult["odata.error"].message.value}.`);

            callback(null, {
                code: errorResult["odata.error"].code,
                message: errorResult["odata.error"].message.value
            });

            return;
        }

        const users = JSON.parse(responseBody);

        context.log.info(`SUCCEEDED: Got contact '${contactId}' for tenant '${tenantId}'.`);

        callback(null, null, users);
    });
}

module.exports = function (context, req) {
    try {
        var client = auth(req);

        // Return Unauthorised response
        if (typeof client === "undefined" || !client) {
            context.res = createUnauthorizedErrorResponse();
            context.done();
            return;
        }

        // Return Parameters Missing response
        if (typeof req.body === "undefined" || !req.body) {
            context.res = createBadRequestErrorResponse("InvalidRequest", "Parameters are missing.");
            context.done();
            return;
        }

        // **********************************
        // Validate the incoming Request data
        // **********************************

        // We must have the ContactID
        if (typeof req.body.extension_ContactId === "undefined" || typeof req.body.extension_ContactId !== "string" || !req.body.extension_ContactId) {
            context.res = createBadRequestErrorResponse("InvalidRequest", "Contact ID is missing.");
            context.done();
            return;
        }

        context.log.info(`Received request body: '${JSON.stringify(req.body)}'.`);

        // Validate the tenant name
        if (typeof process.env.tenantId === "undefined" || !process.env.tenantId) {
            context.res = createBadRequestErrorResponse("InvalidTenant", "Tenant is invalid.");
            context.done();
            return;
        }

        // Retrieve the ContactId Extension from the Request Body
        const theExtension = setExtensionPropertyForFilter(process.env.graphApplicationClientId, "ContactId");

        // Current Date/Time
        const now = Math.round(new Date().getTime() / 1000);

        acquireTokenForApplication(context, process.env.tenantId, client.name, client.pass, "https://graph.windows.net", now, (err, error, accessToken) => {
            try {
                if (err) {
                    context.res = createInternalServerErrorErrorResponse();
                    context.done();
                    return;
                }

                if (error) {
                    context.res = createInternalServerErrorErrorResponse();
                    context.done();
                    return;
                }
                // Get the users matching Contact ID
                getUsers(context, process.env.tenantId, accessToken, req.body.extension_ContactId, theExtension, (err, error, users) => {
                try {
                       if (err) {
                            context.res = createInternalServerErrorErrorResponse();
                            context.done();
                            return;
                       }

                        if (error) {
                            if (error.code === "Request_ResourceNotFound") {
                                context.res = createNotFoundErrorResponse("UserNotFound", "User isn't found.");
                            } else {
                                context.res = createInternalServerErrorErrorResponse();
                            }

                            context.done();
                            return;
                        }

                        // Return the user details.
                        context.res = createOKResponse(context, users, process.env.graphApplicationClientId, now);
                        context.done();

                    } catch (err) {
                        context.log.error(`FAILED: An unexpected error has occurred. Error: ${err}.`);

                        context.res = createInternalServerErrorErrorResponse();
                        context.done();
                    }
                });
            } catch (err) {
                context.log.error(`FAILED: An unexpected error has occurred. Error: ${err}.`);

                context.res = createInternalServerErrorErrorResponse();
                context.done();
            }
        });
    } catch (err) {
        context.log.error(`FAILED: An unexpected error has occurred. Error: ${err}.`);

        context.res = createInternalServerErrorErrorResponse();
        context.done();
    }
};
