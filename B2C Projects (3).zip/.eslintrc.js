module.exports = {
    'root': true,
    'env': {
        'commonjs': true,
        'es2021': true,
        'node': true
    },
    'extends': 'eslint:recommended',
    'parserOptions': {
        'ecmaVersion': 'latest'
    },
    'reportUnusedDisableDirectives': true,
    'rules': {
        'capitalized-comments': [
            'error',
            'always',
            {
                'line': {
                    'ignorePattern': '\\w{1,3}:\\s+'
                },
                'block': {
                    'ignoreConsecutiveComments': true
                }
            }
        ],
        'curly': [
            'error'
        ],
        'dot-notation': [
            'error'
        ],
        'eqeqeq': [
            'error',
            'always'
        ],
        'indent': [
            'error',
            4,
            {
                'SwitchCase': 1
            }
        ],
        'linebreak-style': [
            'error',
            'unix'
        ],
        'multiline-comment-style': [
            'error',
            'starred-block'
        ],
        'no-use-before-define': [
            'error',
            {
                'classes': true,
                'functions': true,
                'variables': true
            }
        ],
        'no-useless-rename': [
            'error'
        ],
        'no-var': [
            'error'
        ],
        'quotes': [
            'error',
            'single'
        ],
        'semi': [
            'error',
            'always'
        ]
    }
};
