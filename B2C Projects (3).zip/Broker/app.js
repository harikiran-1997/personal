/*
    File:           app.js
    Notes:          Main code file of the broker
    Purpose:        Handles the incoming requests from OSC (Oracle Service Cloud), authenticates the requests and handles the callback by converting the response to SAML response
                    and sends it back to OSC.

    Author:         Chris Padgett (Kloud Solutions)
    Date Created:   July 19 2018 (Received from Chris)
    Revision History:
    Name:           Date:         Description:
    Adeel Nasir     To Date         Added the below functionality:
                                    Separate the request for login, pwd change, pwd reset, user activation and logout based on the querystring param.
                                    Assign respective B2C policy for the OIDC strategy
                                    It also creates and encrypts cookie contents.
                                    Creates and signs JWT token
                                    Converts a response from B2C to a SAML response to be sent to OSC
                                    Gets the secrets from the Azure Key Vault
                                    Does the application logging via console and bunyan and stores them to app insight
                                    Added the Key Vault functionality for secrets to be fetched
    Adeel Nasir     26/09/2020      Moved the configs to app config settings on the Azure portal
*/

// Always
'use strict';

// The NPM Modules to include
const fs = require('fs');
const path = require('path');

//Environment specific configs
const config = require('./misc/config');
const tenantConfig = config.creds;
const errPage = process.env.errorPage;

const appInsights = require("applicationinsights");
appInsights.setup()
    .setSendLiveMetrics(process.env.appInsights_liveMetrics)
    .start();

const express = require('express');
const addRequestId = require('express-request-id')();
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
//const cookie = require('cookie');
const passport = require('passport');
const OIDCStrategy = require('passport-azure-ad').OIDCStrategy;
const samlp = require('samlp');
const crypto = require("crypto");
const jwt = require('jsonwebtoken');
const querystring = require("querystring");

const bunyan = require('bunyan');
const log = bunyan.createLogger({ name: 'broker' });

const claimsMapper = require('./misc/claimsMapper');
const templates = require('./templates');
//const ValidateSignature = require('./misc/ValidateSignature');

function generateUniqueID() {
    let uniqueID = '';
    const chars = 'abcdef0123456789';

    for (let i = 0; i < 20; i++) {
        uniqueID += chars.substr(Math.floor((Math.random() * 15)), 1);
    }

    return uniqueID;
};

const app = express();
app.use(cookieParser());
app.use(addRequestId);

app.use(bodyParser.urlencoded({
    extended: true
}));

let startTime = Date.now();
passport.use(
    new OIDCStrategy(
        {
            identityMetadata: process.env.identityMetadata,
            clientID: process.env.clientID,
            responseType: tenantConfig.responseType,
            responseMode: tenantConfig.responseMode,
            redirectUrl: process.env.redirectUrl, //'http://localhost:3000/auth/oidc/callback'
            isB2C: tenantConfig.isB2C,
            passReqToCallback: tenantConfig.passReqToCallback,
            allowHttpForRedirectUrl: tenantConfig.allowHttpForRedirectUrl, // Required to set to true if you want to use http url for redirectUrl like http://localhost:3000.
            useCookieInsteadOfSession: tenantConfig.useCookieInsteadOfSession,
            cookieEncryptionKeys: JSON.parse(process.env.OIDCcookieEncryptionKeys),
            cookieSameSite: tenantConfig.cookieSameSite,
            loggingLevel: tenantConfig.loggingLevel,
            nonceLifetime: tenantConfig.nonceLifetime,
            nonceMaxAmount: tenantConfig.nonceMaxAmount,
            clockSkew: tenantConfig.clockSkew
        },
        (req, iss, sub, profile, jwtClaims, accessToken, refreshToken, params, done) => {
            let msg = 'iss returned from B2C: ' + iss;
            logMessage(req.id, msg);
            msg = 'sub returned from B2C: ' + sub;
            logMessage(req.id, msg);
            msg = 'profile returned from B2C: ' + JSON.stringify(profile);
            logMessage(req.id, msg);
            msg = 'params returned from B2C: ' + params;
            logMessage(req.id, msg);
            done(null, jwtClaims, sub, profile);
        })
);
app.use(passport.initialize());
let duration = Date.now() - startTime;

appInsights.defaultClient.trackDependency({ target: process.env.tenantIdOrName, name: "passport.initialise", data: process.env.identityMetadata, duration: duration, resultCode: 0, success: true, dependencyTypeName: "OIDCStrategy" });

app.get('/', (req, res) => {
    if (process.env.env_code !== 'prd') {
        res.send('Auth Broker v20210303-1');
    }
    else {
        let msg = `Redirecting to error page under execute / action.`;
        logMessage(req.id, msg);
        return res.redirect(errPage);
    }
});

/*
  _    _                 _ _        _____                            _          __                        ____   _____  _____
 | |  | |               | | |      |  __ \                          | |        / _|                      / __ \ / ____|/ ____|
 | |__| | __ _ _ __   __| | | ___  | |__) |___  __ _ _   _  ___  ___| |_ ___  | |_ _ __ ___  _ __ ___   | |  | | (___ | |
 |  __  |/ _` | '_ \ / _` | |/ _ \ |  _  // _ \/ _` | | | |/ _ \/ __| __/ __| |  _| '__/ _ \| '_ ` _ \  | |  | |\___ \| |
 | |  | | (_| | | | | (_| | |  __/ | | \ \  __/ (_| | |_| |  __/\__ \ |_\__ \ | | | | | (_) | | | | | | | |__| |____) | |____
 |_|  |_|\__,_|_| |_|\__,_|_|\___| |_|  \_\___|\__, |\__,_|\___||___/\__|___/ |_| |_|  \___/|_| |_| |_|  \____/|_____/ \_____|
                                                  | |
                                                  |_|
*/
app.get(
    '/auth/execute',
    (req, res, next) => {
        let msg = '';
        let isError = false;

        logMessage(req.id, `START: Request received, starting the processesing on ${process.env.env_code} environment.`);
        //Check if key vault is accessible and we can get the secrets.

        // get the secret's value .
        try {

            let action = req.query.action;
            let relayState = req.query.RelayState;
            let policy_name = '';
            let expiryTime = '';
            let signature = '';
            let objectId = '00000000-0000-0000-0000-000000000000';

            //Clear cookie contact Id for logout, pwd reset and sign in
            if (action !== 'passwordchange') {
                //We are clearing the contact Id from the cookie to make sure we always have the right contact Id
                const objIdContactIdCookie = req.cookies['ARCBS_Broker_Cookie'];

                if (typeof objIdContactIdCookie === "undefined" || typeof objIdContactIdCookie !== "string" || !objIdContactIdCookie) {
                    msg = `No ARCBS_Broker_Cookie found under execute action.`;
                    logMessage(req.id, msg);
                }
                else {
                    //create decipher based on cookie
                    const decrypted = createDecipherAndDecrypt(req.id, process.env.cookieSecretKey, objIdContactIdCookie);
                    if (typeof decrypted !== "undefined") {
                        const Ids = decrypted.split(',');

                        if (typeof Ids[0] === "undefined" || typeof Ids[0] !== "string" || !Ids[0]) {
                            msg = `Object Id retrieved from cookie is not valid.`;
                            logMessage(req.id, msg);
                        }
                        else {
                            msg = `ObjectId extracted from decrypted cookie:${Ids[0]}`;
                            logMessage(req.id, msg);

                            //cookie options
                            let options = {
                                maxAge: 1000 * 60 * 518400, // would expire after 12 months
                                httpOnly: true, // The cookie only accessible by the web server
                                signed: false, // Indicates if the cookie should be signed
                                overwrite: true,
                                sameSite: 'None',
                                secure: true
                            }

                            //encrypt the object and contact Id to be written to cookie
                            try {
                                // Get the signature
                                const valueToEncrypt = Ids[0] + ',';
                                msg = `Cookie value to be encrypted is:${valueToEncrypt}`;
                                logMessage(req.id, msg);
                                const encrypted = createCipherAndEncrypt(req.id, process.env.cookieSecretKey, valueToEncrypt);

                                //write the cookie
                                res.cookie('ARCBS_Broker_Cookie', encrypted, options);
                                msg = `ARCBS_Broker_Cookie cookie written without contact Id.`;
                                logMessage(req.id, msg);

                            } catch (err) {
                                msg = `FAILED: While encrypting and writing ARCBS_Broker_Cookie cookie. Error: ${err}.`;
                                logMessage(req.id, msg);
                            }
                        }
                    }
                    else {
                        msg = `Unable to decipher and decrypt objIdContactIdCookie.`;
                    }
                    logMessage(req.id, msg);
                }
            }

            //Assign policy values based on querystring
            if (action === 'login') {
                policy_name = config.creds.policyNames.login;
            }
            else if (action === 'passwordreset') {
                policy_name = config.creds.policyNames.passwordReset;
            }
            else if (action === 'passwordchange') {
                policy_name = config.creds.policyNames.passwordChange;
            }
            else if (action === 'activate') {
                policy_name = config.creds.policyNames.activate;
                //get querystring values
                objectId = req.query.objectId;
                expiryTime = req.query.expiryTime;
                signature = req.query.signature;

                // We must have the objectId.
                if (typeof objectId === "undefined" || typeof objectId !== "string" || !objectId) {
                    msg = `objectId is missing.`;
                    logMessage(req.id, msg);
                    isError = true;
                }

                // We must have the expiryTime
                if (typeof expiryTime === "undefined" || typeof expiryTime !== "string" || !expiryTime) {
                    msg = `expiryTime is missing.`;
                    logMessage(req.id, msg);
                    isError = true;
                }

                // We must have the Digital Signature
                if (typeof signature === "undefined" || typeof signature !== "string" || !signature) {
                    msg = `signature is missing.`;
                    logMessage(req.id, msg);
                    isError = true;
                }

                // Validate the TTL
                // Current Date/Time
                const now = Math.round(new Date().getTime() / 1000);

                try {
                    const the_TTL = Math.round(expiryTime);

                    // Check TTL here...
                    if (now > the_TTL && process.env.env_code !== 'bld') {//
                        msg = `Time (TTL) has expired.`;
                        logMessage(req.id, msg);
                        isError = true;
                    }
                } catch (err) {
                    msg = `FAILED: An unexpected error has occurred. Error: ${err}.`;
                    logMessage(req.id, msg);
                    isError = true;
                }

                //Validate the signature
                // Re-create the Digital Signature
                try {
                    // Get the signature
                    //logMessage(req.id, 'tenantConfig.keyVault.secretKeys.signatureSecretKey:'+tenantConfig.keyVault.secretKeys.signatureSecretKey);
                    const the_signature = createDigitalSignature(process.env.signatureSecretKey, objectId, expiryTime);
                    msg = `URL Signature re-created using object Id and expiry time.`;
                    logMessage(req.id, msg);

                    logMessage(req.id, `objectId in URL:${objectId}`);
                    logMessage(req.id, `expiryTime in URL:${expiryTime}`);
                    logMessage(req.id, `signature in URL:${signature}`);
                    logMessage(req.id, `signature to compare:${the_signature}`);

                    if (signature !== the_signature) {
                        msg = `URL Signature is invalid.`;
                        logMessage(req.id, msg);
                        isError = true;
                    }
                    else {
                        msg = `URL Signature validated.`;
                        logMessage(req.id, msg);
                    }
                } catch (err) {
                    msg = `FAILED: An unexpected error has occurred while validating URL signature. Error: ${err}.`;
                    logMessage(req.id, msg);
                    isError = true;
                }
            }
            else if (action === 'logout') {
                msg = `Under logout, redirecting to destroySessionUrl: ${process.env.destroySessionUrl}.`;
                logMessage(req.id, msg);
                req.logOut();
                delete req.session;
                return res.redirect(process.env.destroySessionUrl);
            }
            else {
                msg = `Invalid action in the URL.`;
                logMessage(req.id, msg);
                isError = true;
            }
            if (isError) {
                logMessage(req.id, `Error before redirection was:${msg}`);
                msg = `Redirecting to error page under execute action.`;
                logMessage(req.id, msg);
                return res.redirect(errPage);
            }
            else {
                msg = `Setting the policy name parameter. policy_name: ${policy_name}.`;
                logMessage(req.id, msg);
                req.query.p = policy_name;

                //write the relay state cookie so that we can retrieve it once we get the response back from B2C
                let options = {
                    maxAge: 1000 * 60 * 518400, // would expire after 1 year
                    httpOnly: true, // The cookie only accessible by the web server
                    signed: false, // Indicates if the cookie should be signed
                    overwrite: true,
                    sameSite: 'None',
                    secure: true
                }

                res.cookie('ARCBS_Broker_RelayState_Cookie', action + ',' + relayState, options);
                msg = `ARCBS_Broker_RelayState_Cookie cookie written.`;
                logMessage(req.id, msg);

                next();
            }

        } catch (err) {
            msg = `FAILED: An unexpected error has occurred while executing the request. err:${err}`;
            logMessage(req.id, msg);
            isError = true;
        }
    },
    (req, res, next) => {
        //extra query string params to be passed in case of activation flow, including the client assertion type and client assertion as JWT token
        let msg = '';
        let extraAuthReqQueryParams = null;
        let isError = false;

        let policy_name = req.query.p;
        let objectId = '00000000-0000-0000-0000-000000000000';
        msg = `Policy name in querystring found as:${policy_name}`;
        logMessage(req.id, msg);

        if (policy_name === config.creds.policyNames.login || policy_name === config.creds.policyNames.activate) {
            if (policy_name === config.creds.policyNames.login) {
                // extract the object Id from cookie
                try {
                    const objIdContactIdCookie = req.cookies['ARCBS_Broker_Cookie'];

                    if (typeof objIdContactIdCookie === "undefined") {// || typeof objIdContactIdCookie !== "string" || !objIdContactIdCookie
                        msg = `No ARCBS_Broker_Cookie found. Object Id is set to:${objectId}`;
                        logMessage(req.id, msg);
                    }
                    else {
                        //create decipher based on cookie
                        const decrypted = createDecipherAndDecrypt(req.id, process.env.cookieSecretKey, objIdContactIdCookie);

                        if (typeof decrypted !== "undefined") {
                            const Ids = decrypted.split(',');
                            objectId = Ids[0];

                            msg = `ObjectId extracted from decrypted cookie under login policy check as: ${objectId}`;
                        }
                        else {
                            msg = `Unable to decipher and decrypt objIdContactIdCookie.`;
                        }

                        logMessage(req.id, msg);
                    }
                } catch (err) {
                    msg = `FAILED: An unexpected error has occurred while extracting Object Id from cookie. Error: ${err}.`;
                    logMessage(req.id, msg);
                    isError = true;
                }
            }
            else if (policy_name === config.creds.policyNames.activate) {
                objectId = req.query.objectId;
                msg = `Retrieved objectId from query string under activate policy check as: ${objectId}`;
                logMessage(req.id, msg);
            }

            if (isError) {
                msg = `Redirecting to error page because isError: ${isError}`;
                logMessage(req.id, msg);
                return res.redirect(errPage);
            }
            else {
                if (typeof objectId === "undefined" || typeof objectId !== "string" || !objectId) {
                    msg = `No object Id will be added into the JWT.`;
                    logMessage(req.id, msg);
                }
                else {
                    //create and sign the JWT and add it to the strategy

                    //Current Date/Time
                    const now = Math.round(new Date().getTime() / 1000);

                    // Add 20 minutes to the current time
                    const expiryActivation = new Date().getTime() + (20 * 60 * 1000);//change it to 20
                    const the_TTL = Math.round(expiryActivation / 1000);

                    const token = jwt.sign(
                        {
                            broker_oid: objectId,
                            nbf: now - tenantConfig.clockSkew, // Allow for up to xxx seconds time sync error between Authbroker and AAD/B2C
                            iat: now,
                            exp: the_TTL
                        },
                        process.env.jwtSecretKey,
                        {
                            issuer: process.env.issuer,
                            audience: process.env.redirectUrl
                        }
                    );
                    msg = `JWT token signed. Setting extra query string params.`;
                    logMessage(req.id, msg);

                    extraAuthReqQueryParams = {
                        'client_assertion_type': 'urn:ietf:params:oauth:client-assertion-type:jwt-bearer',
                        'client_assertion': token
                    }
                }
            }
        }

        let startTime = Date.now();
        passport.authenticate('azuread-openidconnect', {
            tenantIdOrName: process.env.tenantIdOrName,
            extraAuthReqQueryParams: extraAuthReqQueryParams,
            failureRedirect: '/failure',
            session: false,
            response: res
        })(req, res, next);
        let duration = Date.now() - startTime;

        appInsights.defaultClient.trackDependency({ target: process.env.tenantIdOrName, name: "passport.authenticate", data: process.env.identityMetadata, duration: duration, resultCode: 0, success: true, dependencyTypeName: "OIDCStrategy" });
    },
    (req, res) => {
        res.redirect('/');
    }
);

/*
  _    _                 _ _         __      _ _                        __                       ____ ___   _____
 | |  | |               | | |       / _|    (_) |                      / _|                     |  _ \__ \ / ____|
 | |__| | __ _ _ __   __| | | ___  | |_ __ _ _| |_   _ _ __ ___  ___  | |_ _ __ ___  _ __ ___   | |_) | ) | |
 |  __  |/ _` | '_ \ / _` | |/ _ \ |  _/ _` | | | | | | '__/ _ \/ __| |  _| '__/ _ \| '_ ` _ \  |  _ < / /| |
 | |  | | (_| | | | | (_| | |  __/ | || (_| | | | |_| | | |  __/\__ \ | | | | | (_) | | | | | | | |_) / /_| |____
 |_|  |_|\__,_|_| |_|\__,_|_|\___| |_| \__,_|_|_|\__,_|_|  \___||___/ |_| |_|  \___/|_| |_| |_| |____/____|\_____|

*/
app.get('/failure', (req, res) => {
    let msg = `Inside failure: handling it.`;
    logMessage(req.id, msg);

    let relayStateCookie = req.cookies['ARCBS_Broker_RelayState_Cookie'];
    if (typeof relayStateCookie === "undefined") {// || typeof relayStateCookie !== "string" || !relayStateCookie
        msg = `No relay state cookie found. Redirecting to error page.`;
        logMessage(req.id, msg);
        return res.redirect(errPage);
    }

    let cookieValues = relayStateCookie.split(',');
    let failureMessage = tenantConfig.samlResponse.failureMessage;
    let redirectURL = process.env.samlResponse_destination_or_recipient_or_callback + tenantConfig.samlResponse.redirectPath + tenantConfig.samlResponse.defaultPath + tenantConfig.samlResponse.messagePath + querystring.escape(failureMessage);

    if (cookieValues[0] === 'undefined') {
        msg = `No action found in the cookie. Redirecting to error page.`;
        logMessage(req.id, msg);
        return res.redirect(errPage);
    }
    else if (cookieValues[0] === 'passwordchange') {
        failureMessage = tenantConfig.samlResponse.passwordChangeFailureMsg;
        msg = `failureMessage for passwordchange set as:${failureMessage}`;
    }
    else if (cookieValues[0] === 'passwordreset') {
        failureMessage = tenantConfig.samlResponse.passwordResetFailureMsg;
        msg = `failureMessage for passwordreset set as:${failureMessage}`;
    }
    else if (cookieValues[0] === 'activate') {
        failureMessage = tenantConfig.samlResponse.activateFailureMsg;
        msg = `failureMessage for activation set as:${failureMessage}`;
    }
    else {
        failureMessage = tenantConfig.samlResponse.failureMsg;
        msg = `failureMessage set as:${failureMessage}`;
    }
    logMessage(req.id, msg);

    if (cookieValues[0] !== 'passwordchange') {
        redirectURL = GetSignInPageURL();

        msg = `Redirecting to sign in page under failure sign in action:${redirectURL}`;
        logMessage(req.id, msg);

        return res.redirect(redirectURL);
    }
    else {
        //Changed below code to fix for defect 1889 - SCIP1: Portal - Error 500 - The page did not respond when clicking Cancel button from Change Password screen
        //previously we were handling pwd change differently to other journey because relay state was being handled separately for non pwd change journey
        if (cookieValues[1] !== 'undefined') {
            logMessage(req.id, `Relay state retrieved from cookie: ${cookieValues[1]}`);
            redirectURL = process.env.samlResponse_destination_or_recipient_or_callback + tenantConfig.samlResponse.redirectPath + cookieValues[1] + tenantConfig.samlResponse.messagePath + querystring.escape(failureMessage);
            logMessage(req.id, `Setting the redirect URL with relay state as: ${redirectURL}`);
        }
        else if (cookieValues[1] === 'undefined' && cookieValues[0] === 'passwordchange') {
            redirectURL = process.env.samlResponse_destination_or_recipient_or_callback + tenantConfig.samlResponse.redirectPath + tenantConfig.samlResponse.defaultPath + tenantConfig.samlResponse.messagePath + querystring.escape(failureMessage);

            logMessage(req.id, `Setting the redirect URL without relay state as: ${redirectURL}`);
        }

        // extract the contact Id from cookie
        try {
            const objIdContactIdCookie = req.cookies['ARCBS_Broker_Cookie'];
            const user = { contact_id: '0000000' };//6693661

            msg = `Pass the contact Id back to OSC because its not password reset.`;
            logMessage(req.id, msg);

            if (typeof objIdContactIdCookie === "undefined" || typeof objIdContactIdCookie !== "string" || !objIdContactIdCookie) {
                msg = `No ARCBS_Broker_Cookie found under failure handling.`;
                logMessage(req.id, msg);
            }
            else {
                //create decipher based on cookie
                const decrypted = createDecipherAndDecrypt(req.id, process.env.cookieSecretKey, objIdContactIdCookie);
                if (typeof decrypted !== "undefined") {
                    const Ids = decrypted.split(',');

                    if (typeof Ids[1] === "undefined" || typeof Ids[1] !== "string" || !Ids[1]) {
                        msg = `Contact Id retrieved from cookie is not valid.`;
                        logMessage(req.id, msg);

                        msg = `Redirecting to error page under failure handling while decrypting cookie.`;
                        logMessage(req.id, msg);
                        return res.redirect(errPage);
                    }
                    else {
                        user.contact_id = Ids[1];

                        msg = `ContactId extracted from decrypted cookie:${Ids[1]}`;
                        logMessage(req.id, msg);
                    }
                }
                else {
                    msg = "Unable to decipher and decrypt objIdContactIdCookie.";
                }
                logMessage(req.id, msg);
            }

            msg = "Generating SAML Response.";
            logMessage(req.id, msg);

            samlp.getSamlResponse(
                {
                    signatureAlgorithm: 'rsa-sha256',
                    digestAlgorithm: 'sha256',
                    cert: fs.readFileSync(path.join(__dirname, 'authbroker-saml.pem')),
                    key: fs.readFileSync(path.join(__dirname, 'authbroker-saml.key')),
                    signResponse: true,
                    destination: redirectURL,
                    inResponseTo: '_' + generateUniqueID(),
                    issuer: process.env.samlResponse_issuer,
                    recipient: redirectURL,
                    audience: process.env.samlResponse_audience,
                    profileMapper: claimsMapper
                },
                user,
                (err, samlResponse) => {
                    if (err) {
                        msg = "Error occurred during SAML response generation. Redirecting to error page. err:" + err;
                        logMessage(req.id, msg);
                        logMessage(req.id, 'samlResponse: ' + samlResponse);
                        return res.redirect(errPage);
                    }

                    const response = new Buffer.from(samlResponse);
                    //logMessage(req.id, 'SAML response being sent:'+samlResponse);
                    res.set('Content-Type', 'text/html');

                    logMessage(req.id, 'END Failure: Request processed, sending the SAML response back to OSC.');

                    res.send(templates.form({
                        callback: redirectURL,//tenantConfig.samlResponse.destination_or_recipient_or_callback
                        type: 'SAMLResponse',
                        token: response.toString('base64')
                    }));
                }
            );
        } catch (err) {
            msg = `FAILED: An unexpected error has occurred while extracting ContactId from cookie and generating SAML response. err: ${err}.`;
            logMessage(req.id, msg);
        }
    }
});

/*
  _    _                 _ _         _____      _ _ _                _       __                       ____ ___   _____
 | |  | |               | | |       / ____|    | | | |              | |     / _|                     |  _ \__ \ / ____|
 | |__| | __ _ _ __   __| | | ___  | |     __ _| | | |__   __ _  ___| | __ | |_ _ __ ___  _ __ ___   | |_) | ) | |
 |  __  |/ _` | '_ \ / _` | |/ _ \ | |    / _` | | | '_ \ / _` |/ __| |/ / |  _| '__/ _ \| '_ ` _ \  |  _ < / /| |
 | |  | | (_| | | | | (_| | |  __/ | |___| (_| | | | |_) | (_| | (__|   <  | | | | | (_) | | | | | | | |_) / /_| |____
 |_|  |_|\__,_|_| |_|\__,_|_|\___|  \_____\__,_|_|_|_.__/ \__,_|\___|_|\_\ |_| |_|  \___/|_| |_| |_| |____/____|\_____|

*/
app.post('/auth/oidc/callback',
    (req, res, next) => {
        let startTime = Date.now();
        passport.authenticate('azuread-openidconnect', {
            failureRedirect: '/failure',
            session: false,
            response: res
        })(req, res, next);
        let duration = Date.now() - startTime;

        appInsights.defaultClient.trackDependency({ target: process.env.tenantIdOrName, name: "passport.callback", data: process.env.identityMetadata, duration: duration, resultCode: 0, success: true, dependencyTypeName: "OIDCStrategy" });
    },
    (req, res, next) => {
        let msg = "Received response back from B2C.";
        logMessage(req.id, msg);

        // get the decoded payload ignoring signature, no secretOrPrivateKey needed

        //TODO: we need to verify the token via b2c end point for verification

        const decoded = jwt.decode(req.body.id_token);
        //logMessage(req.id, 'error_Response'+req.query);
        if (decoded !== 'undefined') {
            let tfp = decoded.tfp;
            msg = 'tfp retrieved by decoding the JWT token in the callback function:' + tfp;
            logMessage(req.id, msg);

            if (tfp === config.creds.policyNames.activate && decoded.activation_timeout) {
                redirectURL = GetSignInPageURL();

                msg = "Redirecting to sign in page under callback function for activation timeout:" + redirectURL;
                logMessage(req.id, msg);

                return res.redirect(redirectURL);
            }

            msg = 'Object Id retrieved by decoding the JWT token:' + decoded.sub;
            logMessage(req.id, msg);

            msg = 'Contact Id retrieved by decoding the JWT token:' + decoded.contact_id;
            logMessage(req.id, msg);
        }

        //cookie options
        let options = {
            maxAge: 1000 * 60 * 518400, // would expire after 12 months
            httpOnly: true, // The cookie only accessible by the web server
            signed: false, // Indicates if the cookie should be signed
            overwrite: true,
            sameSite: 'None',
            secure: true
        }

        //encrypt the object and contact Id to be written to cookie
        try {
            // Get the signature
            const valueToEncrypt = decoded.sub + ',' + decoded.contact_id;
            msg = "Cookie value to be encrypted is:" + valueToEncrypt;
            logMessage(req.id, msg);
            const encrypted = createCipherAndEncrypt(req.id, process.env.cookieSecretKey, valueToEncrypt);

            //write the cookie
            res.cookie('ARCBS_Broker_Cookie', encrypted, options);
            msg = "ARCBS_Broker_Cookie cookie written.";
            logMessage(req.id, msg);

        } catch (err) {
            msg = `FAILED: While encrypting and writing cookie. err: ${err}.`;
            logMessage(req.id, msg);
        }

        next();
    },

    (req, res) => {
        let msg = '';
        let tfp = '';
        let message = '';
        let redirectURL = process.env.samlResponse_destination_or_recipient_or_callback + tenantConfig.samlResponse.redirectPath + tenantConfig.samlResponse.defaultPath;// + tenantConfig.samlResponse.messagePath + querystring.escape(message)

        //TODO: we need to verify the token via b2c end point for verification
        const decoded = jwt.decode(req.body.id_token);
        if (decoded !== 'undefined') {
            tfp = decoded.tfp;
            msg = 'tfp retrieved by decoding the JWT token:' + tfp;
            logMessage(req.id, msg);

            if (tfp === config.creds.policyNames.passwordChange) {
                message = tenantConfig.samlResponse.passwordChangeSuccessMsg;
            }
            else if (tfp === config.creds.policyNames.passwordReset) {
                message = tenantConfig.samlResponse.passwordResetSuccessMsg;
            }
            else if (tfp === config.creds.policyNames.activate) {
                message = tenantConfig.samlResponse.activateSuccessMsg;
            }
            msg = `message set for tfp: ${tfp} as: ${message}`;
            logMessage(req.id, msg);
        }
        else {
            message = tenantConfig.samlResponse.failureMsg;
            msg = "message set when decoded token is undefined as:" + message;
            logMessage(req.id, msg);
        }

        const relayStateCookie = req.cookies['ARCBS_Broker_RelayState_Cookie'];
        const cookieValues = relayStateCookie.split(',');

        if (typeof relayStateCookie === "undefined") {// || typeof relayStateCookie !== "string" || !relayStateCookie
            msg = "No relay state cookie found.";
            logMessage(req.id, msg);

        }
        else if (cookieValues[1] === 'undefined') {
            msg = "Setting the default redirect URL as:" + redirectURL;
            logMessage(req.id, msg);
        }
        // else if(cookieValues[1] === 'undefined' && tfp === config.creds.policyNames.passwordchange)
        // {
        //     Commented to fix for defect 1889 - SCIP1: Portal - Error 500 - The page did not respond when clicking Cancel button from Change Password screen
        //     previously we were handling pwd change differently to other journey because relay state was being handled separately for non pwd change journey
        //     redirectURL = tenantConfig.samlResponse.destination_or_recipient_or_callback_with_message + querystring.escape(message);;
        //     msg = "Updating redirect page for password change as:" + redirectURL;
        //     logMessage(req.id, msg);
        // }
        else {
            redirectURL = process.env.samlResponse_destination_or_recipient_or_callback + tenantConfig.samlResponse.redirectPath + cookieValues[1];
            logMessage(req.id, `Relay state retrieved from cookie: ${cookieValues[1]} and redirect URL set as: ${redirectURL}`);
        }

        //append the message to the URL but not in case of pwd change coz it already has that part attached in above code
        if (message.length > 0)// && tfp !== config.creds.policyNames.passwordchange
        {
            redirectURL += tenantConfig.samlResponse.messagePath + querystring.escape(message);
            logMessage(req.id, `Setting the redirect URL with message as: ${redirectURL}`);
        }
        else {
            logMessage(req.id, 'Updating the redirect URL for SAML response as: ' + redirectURL);
        }

        logMessage(req.id, 'Contact Id in req.user.contact_id is: ' + req.user.contact_id);

        samlp.getSamlResponse(
            {
                signatureAlgorithm: 'rsa-sha256',
                digestAlgorithm: 'sha256',
                cert: fs.readFileSync(path.join(__dirname, 'authbroker-saml.pem')),
                key: fs.readFileSync(path.join(__dirname, 'authbroker-saml.key')),
                signResponse: true,
                destination: redirectURL,
                inResponseTo: '_' + generateUniqueID(),
                issuer: process.env.samlResponse_issuer,
                recipient: redirectURL,
                audience: process.env.samlResponse_audience,
                profileMapper: claimsMapper
            },
            req.user,
            (err, samlResponse) => {
                if (err) {
                    msg = "Error occurred during SAML response generation. Redirecting to error page. err:" + err;
                    logMessage(req.id, msg);
                    logMessage(req.id, 'samlResponse: ' + samlResponse);
                    return res.redirect(errPage);
                }

                const response = new Buffer.from(samlResponse);
                //logMessage(req.id, 'SAML response being sent:'+samlResponse);
                res.set('Content-Type', 'text/html');

                logMessage(req.id, 'END: Request processed, sending the SAML response back to OSC.');

                res.send(templates.form({
                    callback: redirectURL,
                    type: 'SAMLResponse',
                    token: response.toString('base64')
                }));
            }
        );
    }
);

function GetSignInPageURL() {
    let redirectPageUrl = "https://authbroker-ENV.donateblood.com.au/auth/execute?action=login&RelayState=app/home";

    if (process.env.env_code === 'prd') {
        redirectPageUrl = redirectPageUrl.replace('-ENV', '');
    }
    else {
        redirectPageUrl = redirectPageUrl.replace('ENV', process.env.env_code);
    }

    return redirectPageUrl;
}

//Create the digital signature
function createDigitalSignature(the_secret_key, objectId, expiryTime) {
    // Create the Digital Signature
    // Use hash-based message authentication code (HMAC) using sha512
    const hmac = crypto.createHmac('sha512', the_secret_key);

    // String to digitally sign
    hmac.update(`'${objectId}'\n'${expiryTime}'`);

    // Get the signature
    const the_signature = hmac.digest('hex');
    return the_signature;
}

//Create the cipher and encrypt
function createCipherAndEncrypt(reqId, the_secret_key, valueToEncrypt) {
    // Create the cipher
    const cipher = crypto.createCipher('aes256', the_secret_key);

    // Get the encrypted
    let encrypted = cipher.update(valueToEncrypt, 'utf8', 'hex');
    encrypted += cipher.final('hex');

    let msg = `Object Id and contact Id encrypted for cookie. valueToEncrypt: ${valueToEncrypt}`;
    logMessage(reqId, msg);

    return encrypted;
}

//Create the cipher and encrypt
function createDecipherAndDecrypt(reqId, the_secret_key, valueToDecrypt) {
    let msg = '';

    //create decipher based on cookie secret
    try {
        const decipher = crypto.createDecipher('aes256', the_secret_key);

        let decrypted = decipher.update(valueToDecrypt, 'hex', 'utf8');
        decrypted += decipher.final('utf8');

        msg = `Success: ObjectId and ContactId retrieved from cookie. decrypted: ${decrypted}`;
        logMessage(reqId, msg);

        return decrypted;
    } catch (err) {
        msg = `FAILED: Something weird inside createDecipherAndDecrypt. err: ${err}.`;
        logMessage(reqId, msg);
    }
}

function logMessage(reqId, msg) {
    //console.log(msg);
    log.info(`Request Id:${reqId}. ${msg}`);
}

module.exports = app;
