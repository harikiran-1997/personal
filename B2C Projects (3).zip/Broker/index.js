/*
    File:           index.js
    Notes:          Main entry point of the broker
    Purpose:        Creates an http server to listen to the incoming requests.
    Author:         Chris Padgett (Kloud Solutions)
    Date Created:   July 19 2018 (Received from Chris)
    Revision History:
    Name:           Date:         Description:

*/

// Always
'use strict';

// The NPM Modules to include
const http = require('http');
const app = require('./app');

const server = http.createServer(app);
const port = process.env.PORT || '3000';

server.on('listening', () => {
    const address = server.address();
    const binding = typeof address === 'string' ? `pipe ${address}` : `port ${address.port}`;
    console.log(`Listening on ${binding}`);
});

server.on('error', err => {
    if (err.syscall !== 'listen') {
        throw err;
    }

    const binding = typeof port === 'string' ? `Pipe ${address}` : `Port ${address.port}`;

    switch (err.code) {
        case 'EACCES':
            console.error(binding + ' requires elevated privileges');
            process.exit(1);
            break;
        case 'EADDRINUSE':
            console.error(binding + ' is already in use');
            process.exit(1);
            break;
        default:
            throw err;
    }
});

server.listen(port);
