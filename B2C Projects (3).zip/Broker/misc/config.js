/*
    File:           config.js
    Notes:          Tenant/Environment based config file
    Purpose:        Stores all the Tenant/Environment related config settings.

    Author:         Adeel Nasir (Kloud Solutions)
    Date Created:   July 25 2018
    Revision History:
    Name:           Date:         Description:
    Adeel Nasir     04/09/2018      Added the gulp file and modified accordingly
    Adeel Nasir     26/09/2020      Moved the configs to app config settings on the Azure portal
*/

// Always
'use strict';

exports.creds = {
    policyNames: {
        'login': 'B2C_1A_donorconnect_sign_in',
        'passwordReset': 'B2C_1A_donorconnect_password_reset',
        'passwordChange': 'B2C_1A_donorconnect_password_change',
        'activate': 'B2C_1A_donorconnect_activation',
    },

    // Required, must be 'code', 'code id_token', 'id_token code' or 'id_token'
    // If you want to get access_token, you must be 'code', 'code id_token' or 'id_token code'
    'responseType': 'id_token',

    // Required
    'responseMode': 'form_post',

    // Required, must be true for B2C
    'isB2C': true,

    // Required if we use http for redirectUrl
    'allowHttpForRedirectUrl': true,

    // Required to set to true if the `verify` function has 'req' as the first parameter
    'passReqToCallback': true,

    // Recommended to set to true. By default we save state in express session, if this option is set to true, then
    // we encrypt state and save it in cookie instead. This option together with { session: false } allows your app
    // to be completely express session free.
    'useCookieInsteadOfSession': true,

    // Required if `useCookieInsteadOfSession` is set to true. You can provide multiple set of key/iv pairs for key
    // rollover purpose. We always use the first set of key/iv pair to encrypt cookie, but we will try every set of
    // key/iv pair to decrypt cookie. Key can be any string of length 32, and iv can be any string of length 12.
    // OIDC cookie encryption keys moved to KeyVault
    // 'cookieEncryptionKeys':
    //    [
    //        { 'key': 'Tvpq4Jz*cu^p56QTFf$^^$@6vsw^2cst', 'iv': '2W*u8X9^uxkB' },
    //        { 'key': '12345678901234567890123456789012', 'iv': '123456789012' },
    //        { 'key': 'abcdefghijklmnopqrstuvwxyzabcdef', 'iv': 'abcdefghijkl' }
    //    ],

    // cookieSameSite (Conditional) If set to true, Passport will add the Same-Site: None header to cookies set by the lib, specifically to validate state and nonce.
    'cookieSameSite': true,

    // This value is the clock skew (in seconds) allowed in token validation. It must be a positive integer. The default value is 300 seconds.
    'clockSkew': 300,

    // Optional, 'error', 'warn' or 'info'
    'loggingLevel': 'info',

    // Optional. The lifetime of nonce in session or cookie, the default value is 3600 (seconds).
    'nonceLifetime': 3600,

    // Optional. The max amount of nonce saved in session or cookie, the default value is 10.
    'nonceMaxAmount': 5,

    //SAML response related values
    'samlResponse': {
        'passwordChangeSuccessMsg': 'Password changed successfully',
        'passwordChangeFailureMsg': 'An error occured during your password change',
        'activateSuccessMsg': 'Account activated successfully',
        'activateFailureMsg': 'An error occured during your account activation',
        'passwordResetSuccessMsg': 'Password was reset successfully',
        'passwordResetFailureMsg': 'An error occured during your password reset',
        'failureMsg': 'An error occured during your request processing',
        'loginFailureMsg': 'An error occured while logging you in',
        'redirectPath': '/redirect/',
        'defaultPath': 'app/home',
        'messagePath': '/msg/'
    }
};
