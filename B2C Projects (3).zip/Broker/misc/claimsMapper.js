/*
    File:           claimsMapper.js
    Notes:          Claims mapper for the SAML converter
    Purpose:        Maps the user's contact id to the required claim.

    Author:         Chris Padgett (Kloud)
    Date Created:   July 19 2018 (Received from Chris)
    Revision History:
    Name:           Date:         Description:

*/

// Always
'use strict';

function ClaimsMapper(user) {
    if (!(this instanceof ClaimsMapper)) {
        return new ClaimsMapper(user);
    }

    this._user = user;
}

ClaimsMapper.prototype.getClaims = function () {
    return {
        'http://schemas.redcrossblood.org.au/identity/claims/contactid': this._user.contact_id
    };
}

ClaimsMapper.prototype.getNameIdentifier = function () {
    return {
        nameIdentifier: this._user.contact_id//,
        //nameIdentifierFormat: 'urn:oasis:names:tc:SAML:1.1:nameid-format:unspecified'
    };
}

module.exports = ClaimsMapper;
