#Requires -Version 5
#Requires -Module @{ModuleName = 'Az.Accounts'; ModuleVersion = '1.7.2'}
#Requires -Module @{ModuleName = 'Az.Monitor'; ModuleVersion = '1.6.0'}
#Requires -Module @{ModuleName = 'Az.Websites'; ModuleVersion = '1.6.0'}
#Requires -Module Microsoft.PowerShell.Archive

[CmdletBinding(
    ConfirmImpact = "High",
    PositionalBinding = $false,
    SupportsShouldProcess = $true,
    DefaultParameterSetName = "Default"
)]

Param (
    [Parameter(Mandatory = $true)]
    [ValidateSet("bld", "dev", "dv2", "tst", "uat", "stg", "prd")]
    [string]
    $Environment,

    [Parameter(ParameterSetName = "AutoSwap")]
    [switch]
    $AutoSwap,

    [Parameter(ParameterSetName = "AutoSwap")]
    [switch]
    $Cleanup,

    [Parameter(ParameterSetName = "ProductionSlot")]
    [switch]
    $ProductionSlot,

    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [pscredential]
    $Credentials,

    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string]
    $DistPath = ".\dist\"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = [System.Management.Automation.ActionPreference]::Stop

$StartTime = Get-Date

if ($PSBoundParameters.ContainsKey("Credentials")) {
    Connect-AzAccount -Credential $Credentials
} elseif (-not (Get-AzContext)) {
    Connect-AzAccount
}

switch ($Environment) {
    "prd" {
        $Authbroker = "authbroker.donateblood.com.au"
        $ClientID = "9b8a23b6-043b-4a37-9037-fb3e19e597bb"
        $DonorPortal = "my.donateblood.com.au"
        $NodeEnv = "production"
        $TenantGUID = "0101cdc2-5552-4b12-af79-28baf12931c8"
        $TenantName = "account.donateblood.com.au"
    }
    "stg" {
        $Authbroker = "authbroker-stg.donateblood.com.au"
        $ClientID = "df81b701-8f5b-4723-9e3c-90526f679d2c"
        $DonorPortal = "my-tst4.donateblood.com.au"
        $NodeEnv = "production"
        $TenantGUID = "30ebcd45-f381-420d-a7a7-5a6440293afe"
        $TenantName = "account-stg.donateblood.com.au"
    }
    "uat" {
        $Authbroker = "authbroker-uat.donateblood.com.au"
        $ClientID = "07a6e657-111f-4c5f-9940-404bd08ee3ff"
        $DonorPortal = "my-tst5.donateblood.com.au"
        $NodeEnv = "development"
        $TenantGUID = "7990b8d4-b5bb-40a4-af66-1af5a29d206b"
        $TenantName = "arcbsciamb2cuatus.b2clogin.com"
    }
    "tst" {
        $Authbroker = "authbroker-tst.donateblood.com.au"
        $ClientID = "c7aeb8dc-76aa-4374-88e6-f864615d5e4b"
        $DonorPortal = "my-tst3.donateblood.com.au"
        $NodeEnv = "development"
        $TenantGUID = "0a73d561-0010-403f-a710-8dbc37608b23"
        $TenantName = "arcbsciamb2ctstus.b2clogin.com"
    }
    "dv2" {
        $Authbroker = "authbroker-dv2.donateblood.com.au"
        $ClientID = "9e960d78-ea43-4bc7-a6c0-573a88456c4d"
        $DonorPortal = "my-tst1.donateblood.com.au"
        $NodeEnv = "development"
        $TenantGUID = "be54db53-4e95-479d-be24-f4377ab6b7aa"
        $TenantName = "arcbsciamb2cdv2us.b2clogin.com"
    }
    "dev" {
        $Authbroker = "authbroker-dev.donateblood.com.au"
        $ClientID = "21b807ba-a8f4-4a50-8915-187c7b0ea8a3"
        $DonorPortal = "my-tst.donateblood.com.au"
        $NodeEnv = "development"
        $TenantGUID = "ff1ebae6-e15a-407f-8869-03c9b0e1f5cb"
        $TenantName = "arcbsciamb2cdevus.b2clogin.com"
    }
    "bld" {
        $Authbroker = "authbroker-bld.donateblood.com.au"
        $ClientID = "c978b005-3cb6-4144-b2f1-3d7da3510717"
        $DonorPortal = "my-tst2.donateblood.com.au"
        $NodeEnv = "development"
        $TenantGUID = "ebfd88ff-cb6f-481b-a6a7-252038fa1eed"
        $TenantName = "arcbsciamb2cbldus.b2clogin.com"
    }
}

$AppSettingsOverrides = @{
    appInsights_liveMetrics                                        = "true"
    APPINSIGHTS_PROFILERFEATURE_VERSION                            = "disabled"
    APPINSIGHTS_SNAPSHOTFEATURE_VERSION                            = "disabled"
    ApplicationInsightsAgent_EXTENSION_VERSION                     = "~2"
    clientID                                                       = $ClientID
    cookieSecretKey                                                = "@Microsoft.KeyVault(SecretUri=https://kv-rcb-$($Environment)-ciam.vault.azure.net/secrets/cookieSecretKey/)"
    destroySessionUrl                                              = "https://$($TenantName)/$($TenantGuid)/oauth2/v2.0/logout?p=b2c_1a_donorconnect_sign_in&post_logout_redirect_uri=https://$($DonorPortal)"
    DIAGNOSTICS_AZUREBLOBRETENTIONINDAYS                           = "30"
    DiagnosticServices_EXTENSION_VERSION                           = "disabled"
    env_code                                                       = $Environment
    errorPage                                                      = "https://rcbsa$($Environment)meluitempl01.blob.core.windows.net/customui/web/error.html"
    identityMetadata                                               = "https://$($TenantName)/$($TenantGuid)/v2.0/.well-known/openid-configuration"
    InstrumentationEngine_EXTENSION_VERSION                        = "disabled"
    issuer                                                         = "https://$($TenantName)/$($TenantGuid)/v2.0/"
    jwtSecretKey                                                   = "@Microsoft.KeyVault(SecretUri=https://kv-rcb-$($Environment)-ciam.vault.azure.net/secrets/jwtSecretKey/)"
    NODE_ENV                                                       = $NodeEnv
    OIDCcookieEncryptionKeys                                       = "@Microsoft.KeyVault(SecretUri=https://kv-rcb-$($Environment)-ciam.vault.azure.net/secrets/OIDCcookieEncryptionKeys/)"
    redirectUrl                                                    = "https://$($Authbroker)/auth/oidc/callback"
    samlResponse_audience                                          = "https://$($TenantName)/$($TenantGuid)/B2C_1A_rp_sign_in_saml"
    samlResponse_destination_or_recipient_or_callback              = "https://$($DonorPortal)/ci/openlogin/saml/subject/contact.id"
    samlResponse_destination_or_recipient_or_callback_with_message = "https://$($DonorPortal)/ci/openlogin/saml/subject/contact.id/redirect/app/account/profile/msg/"
    samlResponse_issuer                                            = "https://$($TenantName)/$($TenantGuid)/samlp"
    signatureSecretKey                                             = "@Microsoft.KeyVault(SecretUri=https://kv-rcb-$($Environment)-ciam.vault.azure.net/secrets/signatureSecretKey/)"
    SnapshotDebugger_EXTENSION_VERSION                             = "disabled"
    tenantIdOrName                                                 = $TenantGUID
    WEBSITE_ADD_SITENAME_BINDINGS_IN_APPHOST_CONFIG                = "1"
    WEBSITE_ENABLE_SYNC_UPDATE_SITE                                = "1"
    WEBSITE_HTTPLOGGING_RETENTION_DAYS                             = "30"
    WEBSITE_NODE_DEFAULT_VERSION                                   = "~12"
    WEBSITE_RUN_FROM_PACKAGE                                       = "0"
    WEBSITE_SWAP_WARMUP_PING_PATH                                  = "/"
    WEBSITE_SWAP_WARMUP_PING_STATUSES                              = "200,302"
    WEBSITE_TIME_ZONE                                              = "AUS Eastern Standard Time"
    XDT_MicrosoftApplicationInsights_BaseExtensions                = "disabled"
    XDT_MicrosoftApplicationInsights_Mode                          = "recommended"
    XDT_MicrosoftApplicationInsights_PreemptSdk                    = "disabled"
}

$AppSettingsToRemove = @(
    "WEBSITE_RUN_FROM_ZIP"
)

$RGName = "rg-$($Environment)-ciam"
$WebAppName = ($Authbroker -split "\.")[0]

$ZipPath = Join-Path -Path $DistPath -ChildPath "$($Environment).zip"
$ZipExcludePaths = @(
    ".env*"
    "dist"
    "Deploy-*"
)

if (-not (Test-Path -Path $DistPath -PathType Container)) {
    New-Item -ItemType Directory -Path $DistPath -Force | Out-Null
}

if (Test-Path -Path $ZipPath -PathType Leaf) {
    Remove-Item -Path $ZipPath -Force
}

if (-not (Test-Path -Path "node_modules" -PathType Container)) {
    npm install | Out-Null
    # Work around a weird defender/AV "EPERM" issue when installing modules
    Start-Sleep -Seconds 1
    npm install | Out-Null
}

npm prune --production | Out-Null

Get-ChildItem -Exclude $ZipExcludePaths | Compress-Archive -DestinationPath $ZipPath -CompressionLevel Optimal

Write-Verbose -Message "Getting active web application slot"
$EnvApp = Get-AzWebApp -ResourceGroupName $RGName -Name $WebAppName

Write-Verbose -Message "Getting deployment slot"

if (-not $ProductionSlot -and -not ($DeploymentSlot = Get-AzWebAppSlot -WebApp $EnvApp -Slot "deploymentswap" -ErrorAction Ignore)) {
    Write-Verbose -Message "Creating new deployment slot"
    $DeploymentSlot = New-AzWebAppSlot -ResourceGroupName $RGName -Name $WebAppName -Slot "deploymentswap" -AppSettingsOverrides $AppSettingsOverrides
}

$AppSettingsHashTable = @{}
foreach ($Entry in $EnvApp.SiteConfig.AppSettings.GetEnumerator()) {
    $AppSettingsHashTable[$Entry.Name] = $Entry.Value
}
foreach ($Entry in $AppSettingsOverrides.GetEnumerator()) {
    $AppSettingsHashTable[$Entry.Name] = $Entry.Value
}
foreach ($Entry in $AppSettingsToRemove.GetEnumerator()) {
    $AppSettingsHashTable.Remove($Entry)
}

if ($ProductionSlot) {
    Write-Verbose -Message "Updating active slot application configuration (Production Slot)"
    $DeploymentSlot = Set-AzWebApp -ResourceGroupName $RGName -Name $WebAppName -AppSettings $AppSettingsHashTable -Use32BitWorkerProcess $false -AlwaysOn $true -FtpsState Disabled
} elseif ($AutoSwap) {
    Write-Verbose -Message "Updating deployment slot application configuration (AutoSwap)"
    $DeploymentSlot = Set-AzWebAppSlot -ResourceGroupName $RGName -Name $WebAppName -Slot "deploymentswap" -AutoSwapSlotName "production" -AppSettings $AppSettingsHashTable -Use32BitWorkerProcess $false -AlwaysOn $true -FtpsState Disabled
} else {
    Write-Verbose -Message "Updating deployment slot application configuration (Manual Swap)"
    $DeploymentSlot = Set-AzWebAppSlot -ResourceGroupName $RGName -Name $WebAppName -Slot "deploymentswap" -AutoSwapSlotName $null -AppSettings $AppSettingsHashTable -Use32BitWorkerProcess $false -AlwaysOn $true -FtpsState Disabled
}

if ($PSCmdlet.ShouldProcess("$($Environment.ToUpper()) Environment", "Deploy $($Environment).zip")) {
    Write-Verbose -Message "Publishing to $($DeploymentSlot.Name)"
    $DeploymentSlot = Publish-AzWebApp -WebApp $DeploymentSlot -ArchivePath (Resolve-Path -Path $ZipPath) -Force

    if ($AutoSwap) {
        Write-Verbose -Message "Deployment <=> production swap in progress"

        $LogQueryTime = $StartTime
        do {
            $Success = $false
            if ($Logs = Get-AzLog -ResourceId $EnvApp.Id -StartTime $LogQueryTime -Caller SlotSwapJobProcessor -WarningAction Ignore) {
                foreach ($LogEntry in ($Logs | Sort-Object -Property EventTimestamp)) {
                    Write-Verbose -Message $LogEntry.Description
                    if ($LogEntry -and $LogEntry.OperationName.Value -eq "Microsoft.Web/sites/slots/SlotSwap/action" -and $LogEntry.Status.Value -match "Succeeded") {
                        $Success = $true
                        break
                    } else {
                        $LogQueryTime = $LogEntry.EventTimestamp.AddMilliseconds(1)
                    }
                }
            }
            Start-Sleep -Seconds 1
        } while ($Success -ne $true)

        if ($Cleanup) {
            Write-Verbose -Message "Sleeping 60 seconds before Deployment slot cleanup"
            Start-Sleep -Seconds 60

            Write-Verbose -Message "Deployment slot cleanup in progress"
            Remove-AzWebAppSlot -WebApp $DeploymentSlot -Force
        }
    }
}
