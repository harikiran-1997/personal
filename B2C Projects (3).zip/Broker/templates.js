// Always
'use strict';

const fs = require('fs');
const path = require('path');

const ejs = require('ejs');

const templates = fs.readdirSync(path.join(__dirname, './templates'));

templates.forEach(fileName => {
    const fileContent = fs.readFileSync(path.join(__dirname, './templates', fileName));
    const template = ejs.compile(fileContent.toString());
    exports[fileName.slice(0, -4)] = template;
});
