﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B2CGraph.Library.Common
{
    public static class RegularExpressions
    {
        public const string MobilePhoneNumber = @"^[+]\d{11,13}$";
        public const string EmailAddress = "^\\w+([-+.\']\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*$";
    }
}
