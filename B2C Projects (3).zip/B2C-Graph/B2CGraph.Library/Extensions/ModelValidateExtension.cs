﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace B2CGraph.Library
{
    public static class ModelValidateExtension
    {
        public static IList<ValidationResult> ValidateModel(this object model)
        {
            var results = new List<ValidationResult>();
            var validationContext = new ValidationContext(model, null, null);
            Validator.TryValidateObject(model, validationContext, results, true);
            if (model is IValidatableObject) (model as IValidatableObject).Validate(validationContext);
            return results;
        }
    }
}
