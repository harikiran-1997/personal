﻿using System;
using System.Linq;
using System.Text;
using System.Globalization;
using System.IO;
using System.Text.RegularExpressions;

namespace B2CGraph.Library
{
    public static class StringExtensions
    {
        // replace all the non English accents characters with standard ACSII
        public static string ReplaceDiacritics(this string str)
        {
            var decomposed = str.Normalize(NormalizationForm.FormD);
            var filtered = decomposed.Where(c => char.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark);
            return new String(filtered.ToArray());
        }

        // remove non Alpha characters
        public static string RemoveNonAlpha(this string str)
        {
            Regex rgx = new Regex("[^a-zA-Z]");
            return rgx.Replace(str, "");
        }

        public static Stream ToStream(this string str, Encoding encoding)
        {
            return new MemoryStream(encoding.GetBytes(str ?? ""));
        }

        public static string MaskMobileNumber(this string mobileNumber)
        {
            StringBuilder result= new StringBuilder("");

            if (!string.IsNullOrWhiteSpace(mobileNumber) && mobileNumber.Length >= 10)
            {
                int maskedCharLength = mobileNumber.Length - 7; //4 chars from start and 3 chars from the end
                result.Append(mobileNumber.Substring(0, 4));
                result.Append('X', maskedCharLength);
                result.Append(mobileNumber.Substring(mobileNumber.Length - 3));
            }

            return result.ToString();
        }
        public static string ValidateMobileNumber(this string mobNumber)
        {
            var mobileNumber = mobNumber.Trim().Replace(" ", "");

            if ((mobileNumber.Length < 9 || mobileNumber.Length > 13) || (!mobileNumber.StartsWith("+614") && !mobileNumber.StartsWith("+64") && !mobileNumber.StartsWith("614") && !mobileNumber.StartsWith("64") && !mobileNumber.StartsWith("04") && !mobileNumber.StartsWith("4")))
            {
                throw new ApplicationException("Invalid mobile number.");
            }
            else
            {
                if (mobileNumber.StartsWith("614") || mobileNumber.StartsWith("64"))
                {
                    mobileNumber = "+" + mobileNumber;
                }
                else if (mobileNumber.StartsWith("04"))
                {
                    mobileNumber = "+61" + mobileNumber.Substring(1);
                }
                else if (mobileNumber.StartsWith("4"))
                {
                    mobileNumber = "+61" + mobileNumber;
                }
            }
            
            return mobileNumber;
        }

    }
}
