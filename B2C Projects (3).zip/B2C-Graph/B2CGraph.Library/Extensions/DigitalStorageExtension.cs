﻿using System;
using B2CGraph.Library.Common;
using B2CGraph.Library.Shared;

namespace B2CGraph.Library
{
    public static class DigitalStorageExtension
    {
        public static double ToSize(this long value, SizeUnit unit)
        {
            return (value / (double)Math.Pow(1024, (long)unit));
        }
    }
}
