﻿using System.IO;

namespace B2CGraph.Library.Shared
{
    public class EmailAttachment
    {
        public string Name { get; set; }
        public bool InLine { get; set; }
        public Stream ContentStream { get; set; }
    }
}
