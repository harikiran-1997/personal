﻿namespace B2CGraph.Library.Shared
{
    public enum SizeUnit
    {
        Byte, KB, MB, GB, TB, PB, EB, ZB, YB
    }
}
