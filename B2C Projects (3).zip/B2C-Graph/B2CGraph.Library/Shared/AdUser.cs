﻿using System.Collections.Generic;

namespace B2CGraph.Library.Shared
{
    public class AdUser
    {
        public string GivenName { get; set; }
        public string Surname { get; set; }
        public string DisplayName { get; set; }
        public string UserPrincipalName { get; set; }
        public bool? AccountEnabled { get; set; }
        public string Password { get; set; }
        public string MailNickname { get; set; }
        public string UserType { get; set; }
        public string UsageLocation { get; set; }
        public string Mobile { get; set; }
        public IList<string> OtherMails { get; set; }
        public string JobTitle { get; set; }
        public string Department { get; set; }
        public string PhysicalDeliveryOfficeName { get; set; }
    }
}
