﻿
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.IO;
using System.Linq;
using System.Text;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using Microsoft.Azure;
using Microsoft.WindowsAzure.Storage.Auth;
using CodeBits;
using System.Text.RegularExpressions;
using B2CGraph.Library;
using Microsoft.Azure.KeyVault;
using B2CGraph.Service;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace B2CGraphShell
{
    public class Program
    {
        private static string environment = "";

        private static string tenant = "";
        private static string clientId = "";
        private static string clientSecret = "";
        private static string iefGraphAppId = "";
        private static string customAttribute1 = CloudConfigurationManager.GetSetting("b2c:common:CustomAttribute1");
        private static string customAttribute2 = CloudConfigurationManager.GetSetting("b2c:common:CustomAttribute2");
        private static string customAttribute3 = CloudConfigurationManager.GetSetting("b2c:common:CustomAttribute3");
        private static string customAttribute4 = CloudConfigurationManager.GetSetting("b2c:common:CustomAttribute4");
        private static string customAttribute5 = CloudConfigurationManager.GetSetting("b2c:common:CustomAttribute5");
        private static string customAttribute6 = CloudConfigurationManager.GetSetting("b2c:common:CustomAttribute6");
        private static readonly string customAttribute3MigratedValue = CloudConfigurationManager.GetSetting("b2c:common:CustomAttribute3MigratedValue");
        private static readonly string customAttribute3APIValue = CloudConfigurationManager.GetSetting("b2c:common:CustomAttribute3APIValue");
        private static readonly string customAttribute3MobileValue = CloudConfigurationManager.GetSetting("b2c:common:CustomAttribute3MobileValue");

        private static string storageAccountName = "";
        private static string storageAccessKey = "";
        private static string inputFileName = "";
        private static string logFileName = "";
        private static string outputFileName = "";
        private static string passwordFileName = "";
        private static string exportPasswords = "";

        private static string KeyVaultClientId = "";
        private static string KeyVaultClientSecret = "";
        private static string KeyVaultUri = "";
        private static readonly string KeyVaultSecretsPath = CloudConfigurationManager.GetSetting("azure:common:KeyVaultSecretsPath");

        private static readonly string containerName = CloudConfigurationManager.GetSetting("azure:common:ContainerName");

        
        private static B2CGraphClient client = null;
        private static ConsoleColor init = ConsoleColor.White;
        private static KeyVaultClient keyVaultClient;

        static void Main(string[] args)
        {   
            init = Console.ForegroundColor;

            if (args.Length <= 0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Please enter a command as the first argument.  Try 'B2C Help' for a list of commands.");
                Console.ForegroundColor = init;
                return;
            }
            else
            {
                //retrieve the 1st argument as environment name
                environment = CloudConfigurationManager.GetSetting("b2c:Environment");
                
                //retrieve the environment specific settings
                tenant = CloudConfigurationManager.GetSetting("b2c:Tenant");
                clientId = CloudConfigurationManager.GetSetting("b2c:ClientId");
                iefGraphAppId = CloudConfigurationManager.GetSetting("b2c:IEFGraphAppId");
                storageAccountName = CloudConfigurationManager.GetSetting("azure:StorageAccountName");
                inputFileName = CloudConfigurationManager.GetSetting("azure:InputFileName");
                logFileName = CloudConfigurationManager.GetSetting("azure:LogFileName").Replace("env",environment);
                outputFileName = CloudConfigurationManager.GetSetting("azure:OutputFileName").Replace("env", environment);
                passwordFileName = CloudConfigurationManager.GetSetting("azure:PasswordFileName").Replace("env", environment);
                exportPasswords = CloudConfigurationManager.GetSetting("azure:ExportPasswords");

                Constants.KeyVaultClientId = KeyVaultClientId = CloudConfigurationManager.GetSetting("azure:KeyVaultClientId");
                Constants.KeyVaultClientSecret = KeyVaultClientSecret = CloudConfigurationManager.GetSetting("azure:KeyVaultClientSecret");
                Constants.KeyVaultUri = KeyVaultUri = CloudConfigurationManager.GetSetting("azure:KeyVaultUri");

                try
                {
                    keyVaultClient = new KeyVaultClient(new KeyVaultClient.AuthenticationCallback(KeyVaultClientService.GetToken));
                    var secretId = KeyVaultUri + KeyVaultSecretsPath + clientId;

                    Console.WriteLine("Getting secret value for:"+ secretId);
                    clientSecret = KeyVaultClientService.GetSecret(keyVaultClient, secretId);
                    Console.WriteLine("Got secret value for:" + secretId);

                    secretId = KeyVaultUri + KeyVaultSecretsPath + storageAccountName;

                    Console.WriteLine("Getting secret value for:" + secretId);
                    storageAccessKey = KeyVaultClientService.GetSecret(keyVaultClient, secretId);
                    Console.WriteLine("Got secret value for:" + secretId);

                    if (!string.IsNullOrEmpty(clientSecret) && !string.IsNullOrEmpty(storageAccessKey))
                    {
                        client = new B2CGraphClient(clientId, clientSecret, tenant);

                        if (client != null)
                        {
                            try
                            {
                                switch (args[0].ToUpper())
                                {
                                    case "IMPORT-USERS":
                                        ImportUsers(environment);
                                        break;
                                    case "GET-OBJECTIDS":
                                        GetObjectIds(environment);
                                        break;
                                    case "PURGE-MIGRATED-USERS":
                                        var filterMigrated = Constants.Filter = $"$filter=extension_" + iefGraphAppId + "_" + customAttribute3 + " eq '" + customAttribute3MigratedValue + "'";
                                        PurgeUsers(filterMigrated, tenant).Wait();
                                        break;
                                    case "PURGE-API-USERS":
                                        var filterAPI = Constants.Filter = $"$filter=extension_" + iefGraphAppId + "_" + customAttribute3 + " eq '" + customAttribute3APIValue + "'";
                                        PurgeUsers(filterAPI, tenant).Wait();
                                        break;
                                    case "PURGE-MOBILE-USERS":
                                        var filterMobile = Constants.Filter = $"$filter=extension_" + iefGraphAppId + "_" + customAttribute3 + " eq '" + customAttribute3MobileValue + "'";
                                        PurgeUsers(filterMobile, tenant).Wait();
                                        break;
                                    case "PURGE-ALL-USERS":
                                        var filterAll = Constants.Filter = $"$filter=extension_" + iefGraphAppId + "_" + customAttribute3 + " eq '" + customAttribute3APIValue + "' or extension_" + iefGraphAppId + "_" + customAttribute3 + " eq '" + customAttribute3MigratedValue + "' or extension_" + iefGraphAppId + "_" + customAttribute3 + " eq '" + customAttribute3MobileValue + "'";
                                        PurgeUsers(filterAll, tenant).Wait();
                                        break;
                                    default:
                                        Console.ForegroundColor = ConsoleColor.Green;
                                        Console.WriteLine("Available Commands:");
                                        Console.WriteLine("    Import-Users");
                                        Console.WriteLine("    Get-ObjectIDs");
                                        Console.WriteLine("    Purge-ALL-Users");
                                        Console.WriteLine("    --------------------");
                                        Console.WriteLine("    Purge-API-Users");
                                        Console.WriteLine("    Purge-Migrated-Users");
                                        Console.WriteLine("    Purge-Mobile-Users");
                                        break;
                                }
                            }
                            catch (Exception ex)
                            {
                                Console.ForegroundColor = ConsoleColor.Red;

                                var innerException = ex.InnerException;
                                if (innerException != null)
                                {
                                    while (innerException != null)
                                    {
                                        Console.WriteLine(innerException.Message);
                                        innerException = innerException.InnerException;
                                    }
                                }
                                else
                                {
                                    Console.WriteLine(ex.Message);
                                }
                            }
                            finally
                            {
                                Console.ForegroundColor = init;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.ForegroundColor = ConsoleColor.Red;

                    var innerException = ex.InnerException;
                    if (innerException != null)
                    {
                        while (innerException != null)
                        {
                            Console.WriteLine(innerException.Message);
                            innerException = innerException.InnerException;
                        }
                    }
                    else
                    {
                        Console.WriteLine(ex.Message);
                    }
                }
            }
        }
        private static dynamic GetExistingUsers(string filter)
        {
            string result;

            result = client.GetAllUsers(filter).Result;

            dynamic dynJson = JsonConvert.DeserializeObject(result);

            return dynJson;
        }

        private static async Task<dynamic> GetExistingUsers(string filter, List<string> objectIds)
        {
            string result;

            result = await client.GetAllUsers(filter);

            dynamic dynJson = JsonConvert.DeserializeObject(result);

            JObject originalObject = JObject.Parse(result);
            objectIds.AddRange(originalObject.Descendants()
                                                      .OfType<JProperty>()
                                                      .Where(p => p.Name == "objectId")
                                                      .Select(x => x.Value.ToString())
                                                      .ToList());
            return dynJson;
        }

        private static void ImportUsers(string environment)
        {
            Console.WriteLine("Starting to import users");
            //FileStream fileStream = null;
            StringBuilder logString = new StringBuilder();
            StringBuilder outputString = new StringBuilder();
            StringBuilder passwordString = new StringBuilder();
            // Create storage account creds object.
            StorageCredentials storageCredentials = new StorageCredentials(storageAccountName, storageAccessKey);
            // Create storage account object.
            CloudStorageAccount storageAccount = new CloudStorageAccount(storageCredentials, true);

            // Create the blob client.
            CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();
            
            // Retrieve reference to the bulkload container.
            CloudBlobContainer container = blobClient.GetContainerReference(containerName);
            
            // Retrieve reference to the input blob
            CloudBlockBlob inputBlockBlob = container.GetBlockBlobReference(inputFileName);
            
            // Save blob contents to a file.
            //using (fileStream = File.OpenWrite(inputFileName))
            //{
            //    inputBlockBlob.DownloadToStream(fileStream);
            //}
            //var users = File.ReadAllLines(inputFileName);

            //To be uncommented in case we want to handle the imported users in memory stream instead of writing a file to working directory (being done above)
            string[] users;
            var timeStamp = DateTime.Now.ToString("ddMMyyyyhhmmss");
            using (var memoryStream = new MemoryStream())
            {
                Console.WriteLine("Downloading the users to memory");
                inputBlockBlob.DownloadToStream(memoryStream);
                users = Encoding.UTF8.GetString(memoryStream.ToArray()).Split(new[] { "\r\n", "\r", "\n" },
                                                                                        StringSplitOptions.None
                                                                             );
                Console.WriteLine("Downloaded the users to memory");
            }
            Console.WriteLine(@"Read input file with " + users.Length + " users");
            Parallel.ForEach(users,
                new ParallelOptions { MaxDegreeOfParallelism = 10 },
                (user) =>
            {
                if (user.Length > 0)

                {
                    string contactId = "";
                    try
                    {

                        var userAttributes = user.Split(',');
                        contactId = userAttributes.Length > 0 ? userAttributes[0].Trim() : "";
                        string email = userAttributes.Length > 1 ? userAttributes[1].Trim() : "";
                        string phone = userAttributes.Length > 2 ? userAttributes[2].Trim().Replace(" ", "") : "";

                        if (phone.Length > 0)
                            phone = phone.ValidateMobileNumber();

                        var contactIdExtensionProperty = "extension_" + iefGraphAppId + "_" + customAttribute1;
                        var filter = $"$filter=" + contactIdExtensionProperty + " eq '" + contactId + "'  and accountEnabled eq false";
                        dynamic dynJson = GetExistingUsers(filter);

                        bool userExists = false;
                        foreach (var existingUser in dynJson.value)
                        {
                            userExists = true;
                            break;
                        }

                        if (!userExists)
                        {   
                            Console.WriteLine(@"Generating password...");
                            //https://docs.microsoft.com/en-us/azure/active-directory/active-directory-passwords-policy 

                            const int requiredLength = 10;
                            var allowedCharacters = PasswordCharacters.UppercaseLetters | PasswordCharacters.LowercaseLetters | PasswordCharacters.Numbers;
                            PasswordCharacters[] requiredCharacters = { PasswordCharacters.UppercaseLetters, PasswordCharacters.LowercaseLetters, PasswordCharacters.Numbers, PasswordCharacters.Punctuations, PasswordCharacters.Punctuations };

                            //generate a new password
                            var newPassword = PasswordGenerator.Generate(requiredLength, allowedCharacters, ".".ToArray());

                            var country = phone.StartsWith("+") ? null : "AU";
                            var jsonObject = new JObject
                            {
                                {"accountEnabled", true},
                                {"creationType", "LocalAccount"},
                                {"extension_" + iefGraphAppId + "_" + customAttribute1, contactId},
                                {"displayName", email},
                                {"extension_" + iefGraphAppId + "_"+customAttribute5, Regex.Replace(email, "(?<=.{1}).(?=[^@]*?.@)", "*")},
                                {"extension_" + iefGraphAppId + "_"+customAttribute2, phone},
                                {"extension_" + iefGraphAppId + "_"+customAttribute4, phone.MaskMobileNumber()},
                                {"extension_" + iefGraphAppId + "_"+customAttribute3, customAttribute3MigratedValue},
                                {"extension_" + iefGraphAppId + "_"+customAttribute6, "True"},
                                {"passwordPolicies", "DisablePasswordExpiration"},
                                {"country", country},
                                {"passwordProfile", new JObject
                                    {
                                        {"password", newPassword},
                                        {"forceChangePasswordNextLogin", false}
                                    }
                                },
                                {"signInNames", new JArray
                                    {
                                        new JObject
                                        {
                                            {"value", email},
                                            {"type", "emailAddress"}
                                        }
                                    }
                                }
                            };

                            string json = JsonConvert.SerializeObject(jsonObject);

                            object formatted = JsonConvert.DeserializeObject(client.CreateUser(json).Result);
                            var jsonString = JsonConvert.SerializeObject(formatted, Formatting.Indented);
                            var objectId = JObject.Parse(jsonString)["objectId"].ToString();

                            Console.ForegroundColor = ConsoleColor.White;
                            //Console.WriteLine(jsonString);

                            //append a line to the log string for log file
                            logString.AppendLine(timeStamp + ": User with Contact ID: " + contactId + " imported successfully.");

                            //create a line of contactId,objectId for the output file
                            var jsonOutputObject = new JObject
                            {
                                {"accountEnabled", true},
                                {"objectId", objectId},
                                {"extension_ContactId", contactId},
                                {"extension_PhoneNumber", phone}
                            };

                            string outputFileJson = JsonConvert.SerializeObject(jsonOutputObject);
                            outputString.AppendLine(contactId + "," + objectId + "," + outputFileJson);

                            //if password needs to be exported then create a line of email,password for the password file
                            if (exportPasswords == "yes")
                            {
                                passwordString.AppendLine(email + "," + newPassword);
                            }
                            Console.WriteLine(@"User created successfully...");
                        }
                        else
                        {
                            logString.AppendLine(timeStamp + ": User with Contact ID: " + contactId + " already exists");
                            Console.WriteLine(@"User already exists...");
                        }
                    }
                    catch (Exception ex)
                    {
                        var logMsg = "";
                        var consoleMsg = "";

                        var innerException = ex.InnerException;
                        if (innerException != null)
                        {
                            while (innerException != null)
                            {
                                logMsg = timeStamp + ": Contact ID: " + contactId + " isnt imported due to the error:" + innerException.Message;
                                consoleMsg = "Error while creating user..." + innerException.Message;
                                innerException = innerException.InnerException;
                            }
                        }
                        else
                        {
                            logMsg = timeStamp + ": Contact ID: " + contactId + " isnt imported due to the error:" + ex.Message;
                            consoleMsg = "Error while creating user..." + ex.Message;
                        }
                        logString.AppendLine(logMsg);
                        Console.WriteLine(consoleMsg);
                    }
                }
                
            });
            //foreach (var user in users) //TODO: might need to change it to parallel for each
            //{
                
            //}

            //upload the log file
            UploadFile(container, logFileName, logString.ToString(), "log");

            //upload the output file
            UploadFile(container, outputFileName, outputString.ToString(), "output");

            //if password needs to be exported then upload the password file
            if (exportPasswords == "yes")
            {
                UploadFile(container, passwordFileName, passwordString.ToString(), "password");
            }

            // Delete the input file from input blob storage container as well as working directory.
            inputBlockBlob.Delete();
            //File.Delete(inputFileName);
            Console.WriteLine(@"Deleted the input file after processing successfully");

        }

        private static void GetObjectIds(string environment)
        {
            Console.WriteLine("Starting to get object Ids");
            //FileStream fileStream = null;
            StringBuilder logString = new StringBuilder();
            StringBuilder outputString = new StringBuilder();
            StringBuilder passwordString = new StringBuilder();
            // Create storage account creds object.
            StorageCredentials storageCredentials = new StorageCredentials(storageAccountName, storageAccessKey);
            // Create storage account object.
            CloudStorageAccount storageAccount = new CloudStorageAccount(storageCredentials, true);

            // Create the blob client.
            CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();

            // Retrieve reference to the bulkload container.
            CloudBlobContainer container = blobClient.GetContainerReference(containerName);

            // Retrieve reference to the input blob
            CloudBlockBlob inputBlockBlob = container.GetBlockBlobReference(inputFileName);

            // Save blob contents to a file.
            //using (fileStream = File.OpenWrite(inputFileName))
            //{
            //    inputBlockBlob.DownloadToStream(fileStream);
            //}
            //var users = File.ReadAllLines(inputFileName);

            //To be uncommented in case we want to handle the imported users in memory stream instead of writing a file to working directory (being done above)
            string[] users;
            var timeStamp = DateTime.Now.ToString("ddMMyyyyhhmmss");
            using (var memoryStream = new MemoryStream())
            {
                Console.WriteLine("Downloading the users to memory");
                inputBlockBlob.DownloadToStream(memoryStream);
                users = Encoding.UTF8.GetString(memoryStream.ToArray()).Split(new[] { "\r\n", "\r", "\n" },
                                                                                        StringSplitOptions.None
                                                                             );
                Console.WriteLine("Downloaded the users to memory");
            }
            Console.WriteLine(@"Read input file with " + users.Length + " users");
            Parallel.ForEach(users,
                new ParallelOptions { MaxDegreeOfParallelism = 10 },
                (user) =>
                {
                    if (user.Length > 0)

                    {
                        string contactId = "";
                        try
                        {

                            var userAttributes = user.Split(',');
                            contactId = userAttributes.Length > 0 ? userAttributes[0].Trim() : "";

                            var contactIdExtensionProperty = "extension_" + iefGraphAppId + "_" + customAttribute1;
                            var filter = $"$filter=" + contactIdExtensionProperty + " eq '" + contactId + "'";
                            dynamic dynJson = GetExistingUsers(filter);

                            foreach (var existingUser in dynJson.value)
                            {
                                var jsonString = JsonConvert.SerializeObject(existingUser, Formatting.Indented);
                                var userJsonObj = JObject.Parse(jsonString);
                                var objectId = userJsonObj["objectId"] != null ? userJsonObj["objectId"].ToString() : "";
                                var email = userJsonObj["displayName"] != null ? userJsonObj["displayName"].ToString() : "";
                                var phone = userJsonObj["extension_" + iefGraphAppId + "_" + customAttribute2] != null ? userJsonObj["extension_" + iefGraphAppId + "_" + customAttribute2].ToString() : "";

                                outputString.AppendLine(contactId + "," + objectId + "," + email + "," + phone);
                                break;
                            }
                        }
                        catch (Exception ex)
                        {
                            var logMsg = "";
                            var consoleMsg = "";

                            var innerException = ex.InnerException;
                            if (innerException != null)
                            {
                                while (innerException != null)
                                {
                                    logMsg = timeStamp + ": Contact ID: " + contactId + " isnt picked due to the error:" + innerException.Message;
                                    consoleMsg = "Error while getting user..." + innerException.Message;
                                    innerException = innerException.InnerException;
                                }
                            }
                            else
                            {
                                logMsg = timeStamp + ": Contact ID: " + contactId + " isnt picked due to the error:" + ex.Message;
                                consoleMsg = "Error while getting user..." + ex.Message;
                            }
                            logString.AppendLine(logMsg);
                            Console.WriteLine(consoleMsg);
                        }
                    }

                });

            //upload the log file
            UploadFile(container, logFileName, logString.ToString(), "log");

            //upload the output file
            UploadFile(container, outputFileName, outputString.ToString(), "output");

            // Delete the input file from input blob storage container as well as working directory.
            inputBlockBlob.Delete();
            //File.Delete(inputFileName);
            Console.WriteLine(@"Deleted the input file after processing successfully");

        }

        private static void UploadFile(CloudBlobContainer container, string fileName, string strToWrite, string type)
        {
            // Retrieve reference to the blob
            CloudBlockBlob blockBlob = container.GetBlockBlobReference(fileName.Replace("timestamp", DateTime.Now.ToString("ddMMyyyyhhmmss")));
            //get bytes from the string
            MemoryStream ms = new MemoryStream(Encoding.UTF8.GetBytes(strToWrite));
            //write to the log folder
            blockBlob.UploadFromStream(ms);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(@"Uploaded the " + type + " file successfully");
        }

        private static async Task PurgeUsers(string filter, string tenant)
        {
            if (tenant.ToUpper().Contains("PRD"))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Purging only allowed in non-prod environments.");
                Console.ForegroundColor = init;
                return;
            }
            var objectIds = new List<string>();
            
            dynamic dynJson = await GetExistingUsers(filter, objectIds);

            Console.WriteLine(objectIds.Count + " users found.");

            Parallel.ForEach(objectIds,
                new ParallelOptions { MaxDegreeOfParallelism = 10 },
                (objectId) =>
                {
                    object formatted = JsonConvert.DeserializeObject(client.DeleteUser(objectId.ToString()).Result);
                });

            Console.WriteLine(objectIds.Count + " users deleted successfully.");

            if (dynJson["odata.nextLink"] != null)
            {
                var nextLink = dynJson["odata.nextLink"].ToString();
                var skipToken = nextLink.Substring(nextLink.IndexOf("$skiptoken"));
                
                await PurgeUsers(Constants.Filter + "&" + skipToken, tenant);
            }

            Console.WriteLine("All specified users deleted successfully.");
        }
    }
}
