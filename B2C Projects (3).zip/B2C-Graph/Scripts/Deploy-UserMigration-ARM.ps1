# -------------------------------
# Parameters
# -------------------------------
param(
#Resource group name - Storage Account
[Parameter(Mandatory=$True)]
[string] $resourceGroupName_storageAccount,

#Resource group name - App Service Plan
[Parameter(Mandatory=$True)]
[string] $resourceGroupName_appServicePlan,

#Azure App Service Plan - Hosting Plan
[Parameter(Mandatory=$True)]
[string] $appServicePlanName,

# Azure web-site prefix
[Parameter(Mandatory=$True)]
[string] $siteName,

#Name of the storage account to be used for deploying the source zip file starting with rcbsa{env} and ending with appdata01 
[Parameter(Mandatory=$True)]
[string] $storageAccountName, 
# Path to local Package file to be Uploaded to azure Storage account to be deployed by ARM Template
[Parameter(Mandatory=$True)]
[string] $pathOfThePackage,
# deployed Package Name on Azure Storage Account as Blob Storage
[Parameter(Mandatory=$True)]
[string] $deployedPackageBlobName,

# Azure ARM Template File Path
[Parameter(Mandatory=$True)]
[string] $siteTemplateFilePath

# -------------------------------
# End of parameters 
# -------------------------------
)

<#
.SYNOPSIS
    Registers RPs
#>
Function RegisterRP {
    Param(
        [string]$ResourceProviderNamespace
    )

    Write-Host "Registering resource provider '$ResourceProviderNamespace'";
    Register-AzureRmResourceProvider -ProviderNamespace $ResourceProviderNamespace;
}

#******************************************************************************
# Script body
# Execution begins here
#******************************************************************************
$ErrorActionPreference = "Stop"

# sign in
Write-Host "Logging in...";
Login-AzureRmAccount;

# get all your azure subscriptions
Write-Host ""
Write-Host "Getting all your subscriptions..." -ForegroundColor Yellow
Get-AzureRmSubscription

#prompt user to provide subscription Id
$subscriptionId = Read-Host -Prompt 'Please write your SubscriptionId from above list'

Write-Host ""
Write-Host "Your entered SubscriptionId is: $subscriptionId" -ForegroundColor Yellow

Write-Host ""
Write-Host "Selecting $subscriptionId ..." -ForegroundColor Yellow
Select-AzureRmSubscription -SubscriptionId $subscriptionId

# Register RPs
$resourceProviders = @();
if($resourceProviders.length) {
    Write-Host "Registering resource providers"
    foreach($resourceProvider in $resourceProviders) {
        RegisterRP($resourceProvider);
    }
}

#Check for existing resource group  - Storage Account
$resourceGroup_storageAccount = Get-AzureRmResourceGroup -Name $resourceGroupName_storageAccount -ErrorAction SilentlyContinue
if(!$resourceGroup_storageAccount)
{
    Write-Host "Storage account resource group '$resourceGroupName_storageAccount' does not exist. Please create resource group before moving forward."
	Exit -1
}
else{
    Write-Host "Using existing storage account resource group '$resourceGroupName_storageAccount'" -ForegroundColor Yellow
}

#Check for existing resource group  - App Service Plan
$resourceGroup_appServicePlan = Get-AzureRmResourceGroup -Name $resourceGroupName_appServicePlan -ErrorAction SilentlyContinue
if(!$resourceGroup_appServicePlan)
{
    Write-Host "App service plan resource group '$resourceGroupName_appServicePlan' does not exist. Please create resource group before moving forward."
	Exit -1
}
else{
    Write-Host "Using existing app service plan resource group '$resourceGroupName_appServicePlan'" -ForegroundColor Yellow
}

#Get Azure Storage account
$storageAccount = Get-AzureRmStorageAccount -ResourceGroupName $resourceGroupName_storageAccount -Name $storageAccountName -ErrorAction SilentlyContinue
If ($storageAccount -ne $null)
{
    Write-Host ""
    Write-Host "Using existing storage account '$storageAccountName'" -ForegroundColor Yellow
}
Else
{
    Write-Host "Storage account '$storageAccountName' does not exist. Please create storage account before moving forward.";
	Exit -1
}
Write-Host ""
Write-Host "Getting storage account key for storage account $storageAccountName ..." -ForegroundColor Yellow
	
$storageAccountKey = (Get-AzureRmStorageAccountKey -ResourceGroupName $resourceGroupName_storageAccount -Name $storageAccountName).Value[0]

# Upload packages to Azure Storage Account

Write-Host ""
Write-Host "Getting storage context for storage account $storageAccountName" -ForegroundColor Yellow

$storageCtx = New-AzureStorageContext -StorageAccountName $storageAccountName -StorageAccountKey $storageAccountKey
if (-Not (Get-AzureStorageContainer -Context $storageCtx | Where-Object { $_.Name -eq "packages" }) ) {
    New-AzureStorageContainer -Name "packages" -Context $storageCtx -Permission Off
}

Write-Host ""
Write-Host "Copying package $pathOfThePackage to storage account $storageAccountName ..." -ForegroundColor Yellow

Set-AzureStorageBlobContent -File $pathOfThePackage -Container "packages" -Blob $deployedPackageBlobName -Context $storageCtx -Force
$uploadedPackage = "https://$storageAccountName.blob.core.windows.net/packages/$deployedPackageBlobName"
$sasToken = New-AzureStorageContainerSASToken -Container "packages" -Context $storageCtx -Permission r
$sasToken = ConvertTo-SecureString $sasToken -AsPlainText -Force

Write-Host ""
Write-Host "Deploying package $pathOfThePackage to $siteName ..." -ForegroundColor Yellow

$siteParameters = @{}
$siteParameters.Add("appServicePlanName", $appServicePlanName)
$siteParameters.Add("siteName", $siteName)
$siteParameters.Add("packageUrl", $uploadedPackage)
$siteParameters.Add("sasToken", $sasToken)

New-AzureRmResourceGroupDeployment -ResourceGroupName $resourceGroupName_appServicePlan `
                                -Name User-Migration-Util-Deployment `
                                -TemplateFile $siteTemplateFilePath `
                                -TemplateParameterObject $siteParameters -Force

Write-Host "Packaged Application deployed on Azure App Service successfuly." -ForegroundColor Green

# creating container for input and log, we dont need to create this because the deployment storage account is different, we only use this for uploading source zip file.
# if we need to do bulk load then we need to use rcbsaprdmelimport01 in Azure portal to create bulkload container and upload the users.csv in the input folder under there
# details can be found in the as built document.

#Write-Host "Creating container for input and log" -ForegroundColor Yellow

#if (-Not (Get-AzureStorageContainer -Context $storageCtx | Where-Object { $_.Name -eq "input" }) ) {
#    New-AzureStorageContainer -Name "input" -Context $storageCtx -Permission Container
#}

#if (-Not (Get-AzureStorageContainer -Context $storageCtx | Where-Object { $_.Name -eq "log" }) ) {
#    New-AzureStorageContainer -Name "log" -Context $storageCtx -Permission Container
#}

#Write-Host "Container for input and log created successfuly." -ForegroundColor Green

Write-Host ""
Write-Host "Finished Deployment." -ForegroundColor White


#Assign the IEF Graph App Id the permissions to delete users, this should be done seperately after the above deployment script - not required for prod deployment
#because we wont be purging users in prod

#Install-Module MSOnline

#Connect-MsolService

#$sp = Get-MsolServicePrincipal -AppPrincipalId $clientId 
#Add-MsolRoleMember -RoleObjectId fe930be7-5e62-47db-91af-98c3a49a38b1 -RoleMemberObjectId $sp.ObjectId -RoleMemberType servicePrincipal