﻿var app = angular.module('App', [
    'ui.router',
    'ui.bootstrap',
    'AdalAngular',
    'ngSanitize',
    'checklist-model',
    'ui.tree',
    'ngRoute',
    'angularSpinner'
]);



app.config(['$httpProvider', '$stateProvider', '$urlRouterProvider', 
  function ($httpProvider, $stateProvider, $urlRouterProvider) {

        

        //$resourceProvider.defaults.stripTrailingSlashes = false;
        // For any unmatched url, redirect to /state1        
      $urlRouterProvider.otherwise("/");

        // Now set up the states
        $stateProvider
            .state('/',
            {
                url: "/",
                templateUrl: "/App/admin/manage-users.html",
                controller: 'manageUsersController',
                requireADLogin: true //it needs to be un-secure until user click search button
            })
            .state('unauthorised',
            {
                url: "/unauthorised",
                templateUrl: "/App/home/unauthorised.html",
                controller: 'unauthorisedController',
                requireADLogin: false //it needs to be un-secure.
            })
            .state('keyvault',
            {
                url: "/keyvault",
                templateUrl: "/App/admin/keyvault.html",
                controller: 'keyvaultController',
                requireADLogin: true
            })
            .state('signout',
            {
                url: '/signout',
                templateUrl: "/App/common/signout.html",
                controller: 'signOutController',
                requireADLogin: true
            })
            //.state('manage-users',
            //{
            //    url: '/manage-users',
            //    templateUrl: "/App/admin/manage-users.html",
            //    controller: 'manageUsersController',
            //    requireADLogin: true
            //});        
      
    }
]);

app.filter('cut', function () {
    return function (value, wordwise, max, tail) {
        if (!value) return '';

        max = parseInt(max, 10);
        if (!max) return value;
        if (value.length <= max) return value;

        value = value.substr(0, max);
        if (wordwise) {
            var lastspace = value.lastIndexOf(' ');
            if (lastspace !== -1) {
                //Also remove . and , so its gives a cleaner result.
                if (value.charAt(lastspace - 1) === '.' || value.charAt(lastspace - 1) === ',') {
                    lastspace = lastspace - 1;
                }
                value = value.substr(0, lastspace);
            }
        }

        return value + (tail || ' …');
    };
});