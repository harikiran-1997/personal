﻿
'use strict';

app.factory('authService', ['adalAuthenticationService', '$http', '$state', function (adalService, $http, $state) {

    var serviceFactory = {};

    var login = function () {
        adalService.login();
    };

    var logOut = function () {
        adalService.logOut();
    };

    var renewToken = function () {
        var adal = new AuthenticationContext();
        adal.config.displayCall = function adminFlowDisplayCall(urlNavigate) {
            urlNavigate += '&prompt=none';
            adal.promptUser(urlNavigate);
        };
        adal.login();
        adal.config.displayCall = null;
    };

    var claims = [];
    var claimsPopulated = false;

    var getUserClaims = function () {

        if (claimsPopulated === false) {

            for (var property in adalService.userInfo.profile) {
                if (adalService.userInfo.profile.hasOwnProperty(property)) {
                    claims.push({
                        key: property,
                        value: adalService.userInfo.profile[property]
                    });
                }
            }

            claimsPopulated = true;
        }

        //otherwise claims already populated
        return claims;
    };

    var userInfo = function () {
        return adalService.userInfo;
    };

    var getTokenExpiryTimeInMinutes = function () {
        var expClaim = null;
        
        for (var property in adalService.userInfo.profile) {
            if (adalService.userInfo.profile.hasOwnProperty(property) && property === 'exp') {
                expClaim = {
                    key: property,
                    value: adalService.userInfo.profile[property]
                };
                break;
            }
        }

        if (expClaim === null)
            return 0;

        //var expInMilliSeconds =  * 1000;
        var diff = expClaim.value - ((new Date()).getTime() / 1000);

        return Math.round(diff / 60);
    };

    var getUserRole = function () {
        return $http.get('api/auth/getrole')
                .success(function (data) {
                    return data;
                });
    };

    var getKeyVaultStatus = function () {
        return $http.get('api/auth/get-keyvault-status')
            .success(function (data) {
                return data;
            });
    };

    serviceFactory.isAdmin = false;
    //serviceFactory.showMenuItem = $state.current.data.showMenuItem;

    var setRoleInfo = function (roleInfo) {
        this.isAdmin = false;
        adalService.userInfo.isAdmin = false;
        if (roleInfo.Role === 'Admin') {
            this.isAdmin = true;
            adalService.userInfo.isAdmin = true;
        }
    };

    serviceFactory.isAuthenticated = adalService.userInfo.isAuthenticated;
    serviceFactory.getUserRole = getUserRole;
    serviceFactory.setRoleInfo = setRoleInfo;
    serviceFactory.login = login;
    serviceFactory.logOut = logOut;
    serviceFactory.renewToken = renewToken;
    serviceFactory.getUserClaims = getUserClaims;
    serviceFactory.userInfo = userInfo;
    serviceFactory.getTokenExpiryTimeInMinutes = getTokenExpiryTimeInMinutes;
    serviceFactory.getKeyVaultStatus = getKeyVaultStatus;

    return serviceFactory;
}]);