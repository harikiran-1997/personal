﻿'use strict';

app.factory('userService',
[
    '$http', function($http) {
        
        var serviceFactory = {};

        var getUsers = function (SearchUser) {
            return $http.post('/api/users/get-users', SearchUser)
                .success(function (data) {
                    return data;
                });
        };
        
        var updateUser = function (UserData) {
            return $http.post('/api/users/update-user', UserData)
                .success(function (data) {
                    return data;
                });
        };

        var sendLink = function (emailAddress) {
            return $http.get('/api/users/send-pwd-reset-link/' + emailAddress + "/")
                .success(function (data) {
                    return data;
                });
        };
        
        //public interface
        serviceFactory.updateUser = updateUser;
        serviceFactory.getUsers = getUsers;
        serviceFactory.sendLink = sendLink;
        
        return serviceFactory;
    }
]);