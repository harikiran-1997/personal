﻿'use strict';

app.controller('unauthorisedController',
[
    '$scope', '$state',
    function ($scope, $state) {

        //console.log('unauthorisedController');
        $scope.pageTitle = "Unauthorised Access";
        $scope.message = "You are not authorised to access this page.";
        

    }]);