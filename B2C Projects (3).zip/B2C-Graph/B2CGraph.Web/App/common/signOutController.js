﻿'use strict';

app.controller('signOutController',
[
    '$scope', 'authService',
    function($scope, authService) {

        if (authService.isAuthenticated) {
            authService.logOut();
            console.log('signed out.');
        }
    }
]);