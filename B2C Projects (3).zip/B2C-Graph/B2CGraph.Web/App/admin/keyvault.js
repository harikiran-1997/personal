﻿'use strict';

app.controller('keyvaultController',
[
    '$scope', '$state',
    function ($scope, $state) {

        //console.log('unauthorisedController');
        $scope.pageTitle = "Key Vault Error";
        $scope.message = "An error occurred while communicating with Key Vault. Please contact with your IT Helpdesk.";

    }]);