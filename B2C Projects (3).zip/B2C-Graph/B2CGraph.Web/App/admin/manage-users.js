﻿'use strict';

app.controller('manageUsersController',
[
    '$scope', 'userService', '$state', 'authService', 'constants', 'modalService', 'adalAuthenticationService',
    function ($scope, userService, $state, authService, constants, modalService, adalService) {

        $scope.message = "";
        $scope.processingMassage = "";
        $scope.pageTitle = "Manage Users";
        $scope.Users = [];
        $scope.environmentName = constants.environmentName;

        $scope.SearchUser = {
            searchByEmail: "",
            searchByPhone: "",
            searchByContactId: ""
        }
        $scope.nothingSelected = false;
        $scope.hasError = false;
        $scope.showSpinner = false;
        
        $scope.User = {
            objectId: "",
            displayName: "",
            emailAddress: "",
            phoneNumber: "",
            contactId: "",
            status: false
        };

        //$scope.UpdatedUser = {
        //    objectId: "",
        //    displayName: "",
        //    emailAddress: "",
        //    phoneNumber: "",
        //    contactId: "",
        //    status: false
        //};

        $scope.getUsers = function () {
            $scope.selectedAll = false;
            $scope.showSpinner = true;
            $scope.message = "";

            userService.getUsers($scope.SearchUser).then(function (data) {
                $scope.hasError = false;
                console.log('successs: ');
                //console.log(data);
                //$scope.Users = data.value;  

                $scope.Users = [];
                var parsedData = JSON.parse(data.data);

                for (var i = 0; i < parsedData.value.length; i++) {
                    $scope.User = {};
                    $scope.User.objectId = parsedData.value[i].objectId;
                    $scope.User.displayName = parsedData.value[i].displayName;

                    var emailObj = parsedData.value[i].signInNames[0];
                    $scope.User.emailAddress = emailObj !== undefined ? emailObj.value : "";

                    var phoneObj = parsedData.value[i]["extension_" + constants.iEFGraphId + "_" + constants.PhoneNumberAttribute];
                    var contactObj = parsedData.value[i]["extension_" + constants.iEFGraphId + "_" + constants.ContactIdAttribute];

                    $scope.User.phoneNumber = phoneObj !== undefined ? phoneObj : "";
                    $scope.User.contactId = contactObj !== undefined ? contactObj : "";

                    $scope.User.status = parsedData.value[i].accountEnabled;


                    $scope.Users.push($scope.User);
                }
                //console.log($scope.Users);
                $scope.showSpinner = false;
            }, function (error) {
                $scope.hasError = true;
                $scope.message = error.data.ExceptionMessage;
                $scope.showSpinner = false;
                console.log('error in getting Users: ');
                console.log(error);
            });
        };

        $scope.updateUser = function (user) {
            $scope.showSpinner = true;
            $scope.message = "";
            var isMobileValid = false;

            var mobileNumber = user.phoneNumber.trim().replace(/ /g, "");

            if (mobileNumber.length > 0) {
                if ((mobileNumber.length < 9 || mobileNumber.length > 13) || (!mobileNumber.startsWith("+614") && !mobileNumber.startsWith("+64") && !mobileNumber.startsWith("614") && !mobileNumber.startsWith("64") && !mobileNumber.startsWith("04") && !mobileNumber.startsWith("4"))) {
                    $scope.message = constants.invalidMobile;
                    $scope.hasError = true;
                    $scope.showSpinner = false;
                    isMobileValid = false;
                }
                else {
                    if (mobileNumber.startsWith("614") || mobileNumber.startsWith("64")) {
                        mobileNumber = "+" + mobileNumber;
                    }
                    else if (mobileNumber.startsWith("04")) {
                        mobileNumber = "+61" + mobileNumber.substr(1);
                    }
                    else if (mobileNumber.startsWith("4")) {
                        mobileNumber = "+61" + mobileNumber;
                    }
                    user.phoneNumber = mobileNumber;
                    isMobileValid = true;
                }
            }
            else {
                isMobileValid = true;
            }

            if (isMobileValid) {
                //get the user from the list of users based on the parameter and only passon the properties that are changed.

                //var filteredUser = $scope.Users.filter(function (x) { return x.objectId === user.objectId; });
                //user.status==
                userService.updateUser(user)
                    .then(function (data) {
                        $scope.showSpinner = false;
                        $scope.getUsers();
                        $scope.message = constants.updateUserSuccess;
                        $scope.hasError = false;
                        console.log(data.data);
                    },
                        function (error) {
                            $scope.showSpinner = false;
                            $scope.message = constants.updateUserFailure;
                            $scope.hasError = true;
                            console.log(error);
                        });
            }
        };

        $scope.sendLink = function (currentUser) {
            $scope.showSpinner = true;
            $scope.message = "";

            userService.sendLink(currentUser.emailAddress)
                .then(function (data) {
                    $scope.showSpinner = false;
                    $scope.message = data.data;
                    $scope.hasError = false;
                },
                    function (error) {
                        $scope.showSpinner = false;
                        $scope.message = constants.sendLinkFailure;
                        $scope.hasError = true;
                    });
        };
        $scope.login = function () {
            adalService.login();
        };
        $scope.logout = function () {
            adalService.logOut();
        };
           
        //init
        //get role info
        authService.getUserRole()
            .then(function (data) {
                authService.setRoleInfo(data.data);
                console.log('authService.isAdmin:' + authService.isAdmin);

                if (!authService.isAdmin)
                    $state.go('unauthorised');

                
            },
                function (error) {
                    console.log('error : ' + error);
            });

        //get key vault status
        authService.getKeyVaultStatus()
            .then(function (data) {
                if (typeof data !== 'undefined' && data.data.length > 0)
                    $state.go('keyvault');
            },
            function (error) {
                console.log('error : ' + error.data);
                $state.go('keyvault');
            });
    }
]);

