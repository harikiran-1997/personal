﻿using System.Web.Mvc;

namespace B2CGraph.Web.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}