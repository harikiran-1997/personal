﻿using B2CGraph.Service;
using System;
using System.Net;
using System.Security.Claims;
using System.Web.Http;

namespace B2CGraph.Web.Controllers
{
    //[Authorize]
    public class AuthController : ApiController
    {
        [HttpGet]
        [Route("api/auth/getrole")]
        public IHttpActionResult GetSignedInUserRole()
        {
            var claimsPrincipal = (ClaimsPrincipal)System.Web.HttpContext.Current.User;
            var roleClaim = claimsPrincipal.FindFirst(x => x.Type == ClaimTypes.Role);

            if (roleClaim == null)
                return Ok(new { Role = "User" });

            if (roleClaim.Value.Equals("Admin", StringComparison.InvariantCultureIgnoreCase))
                return Ok(new { Role = "Admin" });
            else if (roleClaim.Value.Equals("Manager", StringComparison.InvariantCultureIgnoreCase))
                return Ok(new { Role = "Manager" });

            return Ok(new { Role = "User" });
        }
        //[Authorize(Roles = "Admin")]
        [HttpGet]
        [Route("api/auth/get-keyvault-status")]
        public IHttpActionResult GetKeyVaultStatus()
        {
            if (!string.IsNullOrEmpty(Constants.B2CGraphAppClientSecret))
            {
                return Content(HttpStatusCode.OK, "");
            }
            else
            {
                return Content(HttpStatusCode.NotFound, Constants.ErrorMessage);
            }
        }
    }
}
