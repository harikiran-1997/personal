﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using B2CGraph.Service;
using B2CGraph.Library.Common;
using B2CGraph.Library.Shared;
using B2CGraph.Service.ConfigurationService;
using B2CGraph.Service.Models;
using B2CGraph.Web.Models;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Text.RegularExpressions;
using B2CGraph.Library;

namespace B2CGraph.Web.Controllers
{
    [Authorize(Roles = "Admin")]
    public class UserController : ApiController
    {
        private readonly IApplicationConfiguration _applicationConfiguration;
        private readonly B2CGraphClient client;

        public UserController()
        {
            _applicationConfiguration = new ApplicationConfiguration();
            client = new B2CGraphClient(_applicationConfiguration.B2CApplicationConfiguration);
        }

        
        [Route("api/users/get-users")]
        [HttpPost]
        public async Task<IHttpActionResult> GetUsers([FromBody] SearchUser searchUser)
        {
            string result;
            if (!searchUser.isValidSearch)
            {
                throw new Exception("Please provide valid search criteria.");
            }
            else
            {
                searchUser.searchByPhone = HttpUtility.UrlEncode(searchUser.searchByPhone.Trim());
                StringBuilder filter = new StringBuilder();
                filter.Append($"$filter=");
                var contactId = _applicationConfiguration.B2CApplicationConfiguration.IEFGraphAppId + "_" + _applicationConfiguration.B2CApplicationConfiguration.CustomAttribute1;
                var phoneNumber = _applicationConfiguration.B2CApplicationConfiguration.IEFGraphAppId + "_" + _applicationConfiguration.B2CApplicationConfiguration.CustomAttribute2;

                if (searchUser.searchByEmail.Trim().Length > 0)
                {
                    filter.Append($"signInNames/any(x:x/value eq '" + searchUser.searchByEmail.Trim().Replace("'", "''") + "')");
                }
                if (searchUser.searchByPhone.Trim().Length > 0 && searchUser.searchByEmail.Trim().Length <= 0)
                {
                    filter.Append($"extension_" + phoneNumber + " eq '" + searchUser.searchByPhone.Trim() + "'");
                }
                else if (searchUser.searchByPhone.Trim().Length > 0 && searchUser.searchByEmail.Trim().Length > 0)
                {
                    filter.Append($" and extension_" + phoneNumber + " eq '" + searchUser.searchByPhone.Trim() + "'");
                }
                if (searchUser.searchByContactId.Trim().Length > 0 && searchUser.searchByEmail.Trim().Length <= 0  && searchUser.searchByPhone.Trim().Length <= 0)
                {
                    filter.Append($"extension_" + contactId + " eq '" + searchUser.searchByContactId.Trim() + "'");
                }
                else if (searchUser.searchByContactId.Trim().Length > 0 && (searchUser.searchByEmail.Trim().Length > 0 || searchUser.searchByPhone.Trim().Length > 0))
                {
                    filter.Append($" and extension_" + contactId + " eq '" + searchUser.searchByContactId.Trim() + "'");
                }
                result = await client.GetAllUsers(filter.ToString());
            }

            return Ok(result);
        }
        
        [Route("api/users/update-user")]
        [HttpPost]
        public async Task<IHttpActionResult> UpdateUser([FromBody] User user)
        {
            //TODO: check if the property to be updated is null or blank then dont put in the json object.
            var contactId = _applicationConfiguration.B2CApplicationConfiguration.IEFGraphAppId + "_" + _applicationConfiguration.B2CApplicationConfiguration.CustomAttribute1;
            var phoneNumber = _applicationConfiguration.B2CApplicationConfiguration.IEFGraphAppId + "_" + _applicationConfiguration.B2CApplicationConfiguration.CustomAttribute2;
            var maskedPhoneNumber = _applicationConfiguration.B2CApplicationConfiguration.IEFGraphAppId + "_" + _applicationConfiguration.B2CApplicationConfiguration.CustomAttribute4;
            var maskedEmail = _applicationConfiguration.B2CApplicationConfiguration.IEFGraphAppId + "_" + _applicationConfiguration.B2CApplicationConfiguration.CustomAttribute5;

            var jsonObject = new JObject
                        {
                            {"accountEnabled", user.status},
                            {"extension_" + contactId, user.contactId.Trim()},
                            {"displayName", user.emailAddress.Trim()},
                            {"extension_" + phoneNumber, user.phoneNumber.Trim()},
                            {"extension_" + maskedPhoneNumber, user.phoneNumber.Trim().MaskMobileNumber()},
                            {"extension_" + maskedEmail, Regex.Replace(user.emailAddress.Trim(), "(?<=.{1}).(?=[^@]*?.@)", "*")},
                            {"signInNames", new JArray
                                {
                                    new JObject
                                    {
                                        {"value", user.emailAddress.Trim()},
                                        {"type", "emailAddress"}
                                    }
                                }
                            }
                        };

            string json = JsonConvert.SerializeObject(jsonObject);
            string result = await client.UpdateUser(user.objectId, json);
            object formatted =  JsonConvert.DeserializeObject(result);
            var msg = "User has been updated successfully.";

            //Invalidate all refresh tokens if account is disabled
            if (!user.status)
            {
                result = await client.InvalidateUserToken(user.objectId);
                formatted = JsonConvert.DeserializeObject(result);
                msg = "User has been updated successfully and all refresh tokens invalidated.";
            }
            
            return Content(HttpStatusCode.Created, msg);
        }
    }
}

