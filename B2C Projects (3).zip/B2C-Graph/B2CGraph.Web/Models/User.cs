﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace B2CGraph.Web.Models
{
    public class User
    {

        public string objectId { get; set; }

        public string displayName { get; set; }

        public string emailAddress { get; set; }
        public string phoneNumber { get; set; }
        
        public string contactId { get; set; }
        
        public bool status { get; set; }
        
    }
}