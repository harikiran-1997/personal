﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace B2CGraph.Web.Models
{
    public class SearchUser
    {
        public string searchByEmail { get; set; }
        public string searchByPhone { get; set; }
        public string searchByContactId { get; set; }

        public bool isValidSearch => (searchByEmail.Trim().Length > 0 || searchByPhone.Trim().Length > 0 || searchByContactId.Trim().Length > 0);

    }
}