using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using System.Globalization;
using B2CGraph.Web.Claims;
using System.Net.Http;
using System.Net;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using Microsoft.Azure.KeyVault;
using B2CGraph.Service;
using Microsoft.Azure;

namespace B2CGraph.Web
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            GlobalConfiguration.Configure(WebApiConfig.Register);
            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);

            //get secret value from key vault
            try
            {
                var KeyVaultClientId = "";
                var KeyVaultClientSecret = "";
                var KeyVaultUri = "";
                var KeyVaultSecretsPath = CloudConfigurationManager.GetSetting("azure:common:KeyVaultSecretsPath");

                var clientId = CloudConfigurationManager.GetSetting("b2cClientId");
                Constants.KeyVaultClientId = KeyVaultClientId = CloudConfigurationManager.GetSetting("azureKeyVaultClientId");
                Constants.KeyVaultClientSecret = KeyVaultClientSecret = CloudConfigurationManager.GetSetting("azureKeyVaultClientSecret");
                Constants.KeyVaultUri = KeyVaultUri = CloudConfigurationManager.GetSetting("azureKeyVaultUri");


                var keyVaultClient = new KeyVaultClient(new KeyVaultClient.AuthenticationCallback(KeyVaultClientService.GetToken));
                var secretId = KeyVaultUri + KeyVaultSecretsPath + clientId;

                Constants.B2CGraphAppClientSecret = B2CGraph.Service.KeyVaultClientService.GetSecret(keyVaultClient, secretId);
            }
            catch (Exception ex)
            {
                var msg = "";
                var innerException = ex.InnerException;
                if (innerException != null)
                {
                    while (innerException != null)
                    {
                        msg = innerException.Message;
                        innerException = innerException.InnerException;
                    }
                }
                else
                {
                    msg = ex.Message;
                }

                Constants.ErrorMessage = "An error occurred while communicating with Key Vault. "+ msg;
            }
        }

        protected void Application_BeginRequest()
        {
            //string language = "en";

            //var cookie = Request.Cookies.Get("__APPLICATION_LANGUAGE");
            //if (cookie != null)
            //    language = cookie.Value;

            //Thread.CurrentThread.CurrentCulture = new CultureInfo(language);
            //Thread.CurrentThread.CurrentUICulture = new CultureInfo(language);

            //if (!Context.Request.IsSecureConnection)
            //    Response.Redirect(Context.Request.Url.ToString().Replace("http:", "https:"));
        }

        protected void Application_PostAuthenticateRequest()
        {
            //if (ClaimsPrincipal.Current.Identity.IsAuthenticated)
            //{
            //    var transfomer = new CustomClaimsTransformer();
            //    ClaimsPrincipal principal = transfomer.Authenticate(string.Empty, ClaimsPrincipal.Current);

            //    HttpContext.Current.User = principal;
            //    Thread.CurrentPrincipal = principal;
            //}

            //ClaimsPrincipal currentPrincipal = ClaimsPrincipal.Current;
            //CustomClaimsTransformer customClaimsTransformer = new CustomClaimsTransformer();
            ////ClaimsPrincipal tranformedClaimsPrincipal = customClaimsTransformer.Authenticate(string.Empty, currentPrincipal);

            //Thread.CurrentPrincipal = currentPrincipal;// tranformedClaimsPrincipal;
            //HttpContext.Current.User = currentPrincipal;// tranformedClaimsPrincipal;
            Thread.CurrentPrincipal = ClaimsPrincipal.Current;
            if (HttpContext.Current != null)
            {
                HttpContext.Current.User = ClaimsPrincipal.Current;
            }
        }
    }    
}
