﻿using System.Configuration;
using System.Security.Claims;

namespace B2CGraph.Web.Claims
{
    public class CustomClaimsTransformer : System.Security.Claims.ClaimsAuthenticationManager
    {
        public override ClaimsPrincipal Authenticate(string resourceName, ClaimsPrincipal incomingPrincipal)
        {
            if (incomingPrincipal != null && incomingPrincipal.Identity.IsAuthenticated)
            {
                var claimsIdentity = (ClaimsIdentity)incomingPrincipal.Identity;
                
                //checking whether current user is in Admin email list or not
                var upnClaim = incomingPrincipal.FindFirst(x => x.Type == ClaimTypes.Upn);
                var emailClaim = incomingPrincipal.FindFirst(x => x.Type == ClaimTypes.Email);

                //var token= Json(incomingPrincipal.Claims.ToClaimsDictionary());

                //if (incomingPrincipal.IsInRole("Admin"))
                //{
                //    //&& upnClaim.Value != ConfigurationManager.AppSettings["App.OAuth2.UserName"] 
                //    //emailClaim.Value != ConfigurationManager.AppSettings["App.OAuth2.UserName"] && 
                //    claimsIdentity.AddClaim(new Claim(ClaimTypes.Role, "Admin"));
                //}

                //if (upnClaim != null &&
                //    ConfigurationManager.AppSettings["App.Admin.Emails"].ToLower().Contains(upnClaim.Value.ToLower()))
                //{
                //    claimsIdentity.AddClaim(new Claim(ClaimTypes.Role, "Admin"));
                //}

                //if (emailClaim != null &&
                //    ConfigurationManager.AppSettings["App.Admin.Emails"].ToLower().Contains(emailClaim.Value.ToLower()))
                //{
                //    claimsIdentity.AddClaim(new Claim(ClaimTypes.Role, "Admin"));
                //}

                incomingPrincipal = new ClaimsPrincipal(claimsIdentity);

                //var UserInGroup = false;
                //if (upnClaim != null && Helper.IsUserInAdminGroup(upnClaim.Value))
                //{
                //    UserInGroup = true;
                //}
                //else if (emailClaim != null
                //     && Helper.IsUserInAdminGroup(emailClaim.Value))
                //{
                //    UserInGroup = false;
                //}
                
            }

            return incomingPrincipal;
        }
    }
}