﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using Microsoft.Azure;

namespace B2CGraph.Service
{
    public static class Constants
    {
        public static string KeyVaultClientId = ""; //to be replaced by environment specific value
        public static string KeyVaultClientSecret = ""; //to be replaced by environment specific value
        public static string KeyVaultUri = ""; //to be replaced by environment specific value

        public static string B2CGraphAppClientSecret = ""; //to be replaced by environment specific value
        public static string StorageAccessKey = ""; //to be replaced by environment specific value

        public static string ErrorMessage = ""; //to be replaced by environment specific value

        public static string Filter = ""; //to be replaced by user specific value for filtering
    }
}
