﻿namespace B2CGraph.Service.ConfigurationService
{
    public interface IB2CApplicationConfiguration
    {
        string ClientId { get; }
        string Secret { get; }
        string TenantId { get; }
        string IEFGraphAppId { get; }
        string CustomAttribute1 { get; }
        string CustomAttribute2 { get; }
        string CustomAttribute3 { get; }
        string CustomAttribute4 { get; }
        string CustomAttribute5 { get; }
        string CustomAttribute6 { get; }
        string CustomAttribute3MigratedValue { get; }
        string CustomAttribute3APIValue { get; }
        string SupportContact { get; }
    }
}
