using Microsoft.Azure;

namespace B2CGraph.Service.ConfigurationService
{
    public class B2CApplicationConfiguration : IB2CApplicationConfiguration
    {
        public B2CApplicationConfiguration()
        {
            ClientId = CloudConfigurationManager.GetSetting("b2cClientId");
            TenantId = CloudConfigurationManager.GetSetting("b2cTenant");
            IEFGraphAppId = CloudConfigurationManager.GetSetting("b2cIEFGraphAppId");
            Secret = Constants.B2CGraphAppClientSecret;
            CustomAttribute1 = CloudConfigurationManager.GetSetting("b2c:common:CustomAttribute1");
            CustomAttribute2 = CloudConfigurationManager.GetSetting("b2c:common:CustomAttribute2");
            CustomAttribute3 = CloudConfigurationManager.GetSetting("b2c:common:CustomAttribute3");
            CustomAttribute4 = CloudConfigurationManager.GetSetting("b2c:common:CustomAttribute4");
            CustomAttribute5 = CloudConfigurationManager.GetSetting("b2c:common:CustomAttribute5");
            CustomAttribute6 = CloudConfigurationManager.GetSetting("b2c:common:CustomAttribute6");
            CustomAttribute3MigratedValue = CloudConfigurationManager.GetSetting("b2c:common:CustomAttribute3MigratedValue");
            CustomAttribute3APIValue = CloudConfigurationManager.GetSetting("b2c:common:CustomAttribute3APIValue");
            SupportContact = CloudConfigurationManager.GetSetting("b2c.common.SupportContact");
        }

        public string ClientId { get; }
        public string Secret { get; }
        public string TenantId { get; }
        public string IEFGraphAppId { get; }
        public string CustomAttribute1 { get; }
        public string CustomAttribute2 { get; }
        public string CustomAttribute3 { get; }
        public string CustomAttribute4 { get; }
        public string CustomAttribute5 { get; }
        public string CustomAttribute6 { get; }
        public string CustomAttribute3MigratedValue { get; }
        public string CustomAttribute3APIValue { get; }
        public string SupportContact { get; }
    }
}
