﻿namespace B2CGraph.Service.ConfigurationService
{
    public interface IApplicationConfiguration
    {
        IB2CApplicationConfiguration B2CApplicationConfiguration { get; }

        string TenantId { get; }
        string SolutionName { get; }
        string Environments { get; }
        string Environment { get; }
    }
}
