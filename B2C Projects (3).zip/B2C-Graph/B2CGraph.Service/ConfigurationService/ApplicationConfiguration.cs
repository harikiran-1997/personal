using System.Configuration;
using Microsoft.Azure;

namespace B2CGraph.Service.ConfigurationService
{
    public class ApplicationConfiguration : IApplicationConfiguration
    {
        public ApplicationConfiguration()
        {
            Environment = CloudConfigurationManager.GetSetting("environment");
            Environments = CloudConfigurationManager.GetSetting("environments");

            TenantId = CloudConfigurationManager.GetSetting("idaTenantId");
            
            B2CApplicationConfiguration = new B2CApplicationConfiguration();

            SolutionName = CloudConfigurationManager.GetSetting("Application.Name");
        }
        
        public IB2CApplicationConfiguration B2CApplicationConfiguration { get; }

        public string TenantId { get; }
        public string SupportEmails { get; }
        public string SolutionName { get; }
        public string Environments { get; }
        public string Environment { get; }
    }
}
