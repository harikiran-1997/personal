/*
 *    Filename:       Gulpfile.js
 *    Notes:          Builds the Distribution versions of the policies per environment. Each environment
 *                    (Build, Dev, Test, Stage and Prod) has separate folders.
 *    Purpose:        Builds the Distribution versions of the policies per enironment.
 *                    The extention (ext) file inherits from this base.
 *    Author:         Warwick Jaensch (Kloud Solutions)
 *    Date Created:   January 22nd 2018
 *    Revision History:
 *    Name:           Date:         Description:
 *      WCJ           17/01/18      Initial version.
 */

const gulp = require('gulp');
const rename = require('gulp-rename');
const replace = require('gulp-replace');
const gulpif = require('gulp-if');
const stripCode = require('gulp-strip-code');

const options = {
    'bldus': {
        'iefAuthenticationApplication': {
            'clientId': '90a761b0-7aeb-46a6-a896-44662c8a388f'
        },
        'iefAuthenticationProxyApplication': {
            'clientId': '9f360d46-bf06-4322-a0ae-dae23e2900fe'
        },
        'iefGraphApplication': {
            'id': '0d33f9c9-1d34-4c19-b4cb-6c943175d5cc',
            'clientId': 'ada375c5-0608-411a-8462-9894ec0fbca1'
        },
        'iefTokenConfig': {
            'TokenLifetimeSecs': '3600',
            'IdTokenLifetimeSecs': '3600',
            'RefreshLifetimeSecs': '86400',
            'RollingRefreshLifetimeSecs': '172800'
        },
        'ShowOutage': 'False', // Should be False by default unless you want to turn it on
        'TurnOffSignIn2FA': 'False',
        'AIInstrumentationKey': '858f1e8f-9e32-430c-8dc1-3e74acf128b2',
        'AzureFunctions': {
            'ServiceURL': 'https://oscapi-bld.donateblood.com.au/api/InsertAppInsightsFromB2CHttpTrigger',
            'CreateDisabledUserFromCIAM_ServiceURL': 'https://oscapi-bld.donateblood.com.au/api/CreateDisabledUserFromCIAMHttpTrigger',
            'DataSyncEngine_ServiceURL': 'https://oscapi-bld.donateblood.com.au/api/DataSyncEngineHttpTrigger',
            'x_functions_key': 'oNiMWpTibj5B1lPBxE8X3T5Y7AmzL2K7gEvACFWNCxcatgG8J8eonA=='
        },
        'APIGatewayFxnApp': {
            'CallCreatePendingOscUser_ServiceURL': 'https://account-bld.donateblood.com.au/api/createPending',
            'CallActivatePendingOscUser_ServiceURL': 'https://account-bld.donateblood.com.au/api/activatePending',
            'CallFirebaseAnalyticsGCF_ServiceURL': 'https://account-bld.donateblood.com.au/api/firebaseAnalytics',
        },
        'InAppRegistration': {
            'metadata_url': 'https://account-bld.donateblood.com.au/proxy/idp/v1/oauth/.well-known/openid-configuration',
            'jwt_audience': 'https://account-bld.donateblood.com.au/ebfd88ff-cb6f-481b-a6a7-252038fa1eed/v2.0/',
            'jwt_issuer': 'https://idp-dev.donateblood.com.au/v1/oauth',
        },
        'sendGrid': {
            'serviceUrl': 'https://api.sendgrid.com/v3/mail/send',
            'fromEmail' : 'noreply@redcrossblood.org.au',
            'fromName' : 'Australian Red Cross Lifeblood',
            'verificationEmailTemplateId': 'd-cf9755dba6e14b6dbe15caab4cb49224',
            'verificationEmailSubject' : 'Your online verification code',
            'pwdChangeEmailTemplateId': 'd-4e589294f7614bb799c37b40b5c774e2',
            'pwdChangeEmailSubject' : 'Your password has been changed',
            'pwdResetEmailTemplateId': 'd-b30902d200104c279653394d3ef5e3bd',
            'pwdResetEmailSubject' : 'Your password has been reset'
        },
        'customUILocation': 'bld',
        "inputVerificationDelayTimeInMilliseconds": 750
    },
    'devus': {
        'iefAuthenticationApplication': {
            'clientId': '96c9a0f5-c74d-42d1-8ebd-e0d46a9e80eb'
        },
        'iefAuthenticationProxyApplication': {
            'clientId': '708bdd8f-2489-4670-ba65-f1d9f62790e4'
        },
        'iefGraphApplication': {
            'id': 'cf017a9f-72f4-4185-b2f4-039c0ed65511',
            'clientId': '07745c17-d922-47bb-848c-6c046152f1d3'
        },
        'iefTokenConfig': {
            'TokenLifetimeSecs': '3600',
            'IdTokenLifetimeSecs': '3600',
            'RefreshLifetimeSecs': '86400',
            'RollingRefreshLifetimeSecs': '172800'
        },
        'ShowOutage': 'False',// Should be False by default unless you want to turn it on
        'TurnOffSignIn2FA': 'False',
        'AIInstrumentationKey': 'ef134a3f-fe80-4675-a971-5c08daf139b0',
        'AzureFunctions': {
            'ServiceURL': 'https://oscapi-dev.donateblood.com.au/api/InsertAppInsightsFromB2CHttpTrigger',
            'CreateDisabledUserFromCIAM_ServiceURL': 'https://oscapi-dev.donateblood.com.au/api/CreateDisabledUserFromCIAMHttpTrigger',
            'DataSyncEngine_ServiceURL': 'https://oscapi-dev.donateblood.com.au/api/DataSyncEngineHttpTrigger',
            'x_functions_key': 'uWuml/GFVWoF4v8mZAORaidJHdtzBz/MbYUBDm0rMrFPEZK/aPHSVw=='
        },
        'APIGatewayFxnApp': {
            'CallCreatePendingOscUser_ServiceURL': 'https://account-dev.donateblood.com.au/api/createPending',
            'CallActivatePendingOscUser_ServiceURL': 'https://account-dev.donateblood.com.au/api/activatePending',
            'CallFirebaseAnalyticsGCF_ServiceURL': 'https://account-dev.donateblood.com.au/api/firebaseAnalytics',
        },
        'InAppRegistration': {
            'metadata_url': 'https://account-dev.donateblood.com.au/proxy/idp/v1/oauth/.well-known/openid-configuration',
            'jwt_audience': 'https://account-dev.donateblood.com.au/ff1ebae6-e15a-407f-8869-03c9b0e1f5cb/v2.0/',
            'jwt_issuer': 'https://idp-dev.donateblood.com.au/v1/oauth',
        },
        'sendGrid': {
            'serviceUrl': 'https://api.sendgrid.com/v3/mail/send',
            'fromEmail' : 'noreply@redcrossblood.org.au',
            'fromName' : 'Australian Red Cross Lifeblood',
            'verificationEmailTemplateId': 'd-f5a7946275f64fcd964679f1df375c86',
            'verificationEmailSubject' : 'Your online verification code',
            'pwdChangeEmailTemplateId': 'd-9fb6be701d8d4fa181a05f19e5549b24',
            'pwdChangeEmailSubject' : 'Your password has been changed',
            'pwdResetEmailTemplateId': 'd-39fbbc09ae104b4d82fdb4c83414657a',
            'pwdResetEmailSubject' : 'Your password has been reset'
        },
        'customUILocation': 'dev',
        "inputVerificationDelayTimeInMilliseconds": 750
    },
    'dv2us': {
        'iefAuthenticationApplication': {
            'clientId': '3ead55c5-7a2c-4a61-930b-7b7ddbccd154'
        },
        'iefAuthenticationProxyApplication': {
            'clientId': 'beba6185-abfd-4f07-8634-22096eaaad2c'
        },
        'iefGraphApplication': {
            'id': '8ea75b2a-fb6a-477c-ab51-4fa2890ef8fe',
            'clientId': '9c4ffb40-2e99-4009-bfa6-e3652689f618'
        },
        'iefTokenConfig': {
            'TokenLifetimeSecs': '3600',
            'IdTokenLifetimeSecs': '3600',
            'RefreshLifetimeSecs': '86400',
            'RollingRefreshLifetimeSecs': '172800'
        },
        'ShowOutage': 'False',// Should be false by default unless you want to turn it on
        'TurnOffSignIn2FA': 'False',
        'AIInstrumentationKey': 'd8db8fc7-1739-41fc-bd9d-695e8b592f55',
        'AzureFunctions': {
            'ServiceURL': 'https://oscapi-dv2.donateblood.com.au/api/InsertAppInsightsFromB2CHttpTrigger',
            'CreateDisabledUserFromCIAM_ServiceURL': 'https://oscapi-dv2.donateblood.com.au/api/CreateDisabledUserFromCIAMHttpTrigger',
            'DataSyncEngine_ServiceURL': 'https://oscapi-dv2.donateblood.com.au/api/DataSyncEngineHttpTrigger',
            'x_functions_key': '6mSUOiLkDl5Ngk9Cj1gEjLQlEAgMeZPFHfSs8fSyqJhzK44V4Mfsdw=='

        },
        'APIGatewayFxnApp': {
            'CallCreatePendingOscUser_ServiceURL': 'https://account-dv2.donateblood.com.au/api/createPending',
            'CallActivatePendingOscUser_ServiceURL': 'https://account-dv2.donateblood.com.au/api/activatePending',
            'CallFirebaseAnalyticsGCF_ServiceURL': 'https://account-dv2.donateblood.com.au/api/firebaseAnalytics',
        },
        'InAppRegistration': {
            'metadata_url': 'https://account-dv2.donateblood.com.au/proxy/idp/v1/oauth/.well-known/openid-configuration',
            'jwt_audience': 'https://account-dv2.donateblood.com.au/be54db53-4e95-479d-be24-f4377ab6b7aa/v2.0/',
            'jwt_issuer': 'https://idp-dev2.donateblood.com.au/v1/oauth',
        },
        'sendGrid': {
            'serviceUrl': 'https://api.sendgrid.com/v3/mail/send',
            'fromEmail' : 'noreply@redcrossblood.org.au',
            'fromName' : 'Australian Red Cross Lifeblood',
            'verificationEmailTemplateId': 'd-6eafecb053d948ca843c094c5e5fa184',
            'verificationEmailSubject' : 'Your online verification code',
            'pwdChangeEmailTemplateId': 'd-d941f1a1dbba4325be3eb4f2737ee14a',
            'pwdChangeEmailSubject' : 'Your password has been changed',
            'pwdResetEmailTemplateId': 'd-da42848800da446aa7fabfe9ccb68711',
            'pwdResetEmailSubject' : 'Your password has been reset'
        },
        'customUILocation': 'dv2',
        "inputVerificationDelayTimeInMilliseconds": 2000
    },
    'tstus': {
        'iefAuthenticationApplication': {
            'clientId': '1620edca-caa1-48bc-924f-3541ce1b283f'
        },
        'iefAuthenticationProxyApplication': {
            'clientId': '87384e94-ed4e-4bdb-8e47-6d285e04f9f9'
        },
        'iefGraphApplication': {
            'id': '519a5a20-058a-4fd9-9574-f842d7ff28c6',
            'clientId': 'f42fa1ef-6c86-4f04-806f-403371ffac0f'
        },
        'iefTokenConfig': {
            'TokenLifetimeSecs': '3600',
            'IdTokenLifetimeSecs': '3600',
            'RefreshLifetimeSecs': '7776000',
            'RollingRefreshLifetimeSecs': '31536000'
        },
        'ShowOutage': 'False',// Should be False by default unless you want to turn it on
        'TurnOffSignIn2FA': 'False',
        'AIInstrumentationKey': '4bf88686-a96a-4ffa-a18f-32f2c12491e4',
        'AzureFunctions': {
            'ServiceURL': 'https://oscapi-tst.donateblood.com.au/api/InsertAppInsightsFromB2CHttpTrigger',
            'CreateDisabledUserFromCIAM_ServiceURL': 'https://oscapi-tst.donateblood.com.au/api/CreateDisabledUserFromCIAMHttpTrigger',
            'DataSyncEngine_ServiceURL': 'https://oscapi-tst.donateblood.com.au/api/DataSyncEngineHttpTrigger',
            'x_functions_key': 'uaxl5Oyc49/qx9sG/u3G3F3f8zDTTuN9v4Xn/K0eWvH1aY8w7kqlvQ=='

        },
        'APIGatewayFxnApp': {
            'CallCreatePendingOscUser_ServiceURL': 'https://account-tst.donateblood.com.au/api/createPending',
            'CallActivatePendingOscUser_ServiceURL': 'https://account-tst.donateblood.com.au/api/activatePending',
            'CallFirebaseAnalyticsGCF_ServiceURL': 'https://account-tst.donateblood.com.au/api/firebaseAnalytics',
        },
        'InAppRegistration': {
            'metadata_url': 'https://account-tst.donateblood.com.au/proxy/idp/v1/oauth/.well-known/openid-configuration',
            'jwt_audience': 'https://account-tst.donateblood.com.au/0a73d561-0010-403f-a710-8dbc37608b23/v2.0/',
            'jwt_issuer': 'https://idp-test.donateblood.com.au/v1/oauth',
        },
        'sendGrid': {
            'serviceUrl': 'https://api.sendgrid.com/v3/mail/send',
            'fromEmail' : 'noreply@redcrossblood.org.au',
            'fromName' : 'Australian Red Cross Lifeblood',
            'verificationEmailTemplateId': 'd-22f45747af724581b73c6cdcd7b136c3',
            'verificationEmailSubject' : 'Your online verification code',
            'pwdChangeEmailTemplateId': 'd-ff4f6f29b1914be3ae8ed27dc5493a71',
            'pwdChangeEmailSubject' : 'Your password has been changed',
            'pwdResetEmailTemplateId': 'd-e85d2dbe4f0d408287f3e97a9de09d33',
            'pwdResetEmailSubject' : 'Your password has been reset'
        },
        'customUILocation': 'tst',
        "inputVerificationDelayTimeInMilliseconds": 2000
    },
    'uatus': {
        'iefAuthenticationApplication': {
            'clientId': 'aa8ea31a-d01e-4b30-b681-cf0fcd106fe1'
        },
        'iefAuthenticationProxyApplication': {
            'clientId': '12ebb643-109d-40d0-aa45-ef1a8c42c6e8'
        },
        'iefGraphApplication': {
            'id': 'c1f79a58-611c-40e4-9f39-05a1ab30c602',
            'clientId': 'b9ff2a0d-1be1-448e-9f52-ba3170256c05'
        },
        'iefTokenConfig': {
            'TokenLifetimeSecs': '3600',
            'IdTokenLifetimeSecs': '3600',
            'RefreshLifetimeSecs': '259200',
            'RollingRefreshLifetimeSecs': '518400'
        },
        'ShowOutage': 'False',// Should be false by default unless you want to turn it on
        'TurnOffSignIn2FA': 'False',
        'AIInstrumentationKey': '56b8b806-861a-4d02-a540-ac5a8c8555bd',
        'AzureFunctions': {
            'ServiceURL': 'https://oscapi-uat.donateblood.com.au/api/InsertAppInsightsFromB2CHttpTrigger',
            'CreateDisabledUserFromCIAM_ServiceURL': 'https://oscapi-uat.donateblood.com.au/api/CreateDisabledUserFromCIAMHttpTrigger',
            'DataSyncEngine_ServiceURL': 'https://oscapi-uat.donateblood.com.au/api/DataSyncEngineHttpTrigger',
            'x_functions_key': '6ji2mF50njxewF99HydwjMVyIj8UGKRGXR1wZ2YywtabUzYvL09MKw=='

        },
        'APIGatewayFxnApp': {
            'CallCreatePendingOscUser_ServiceURL': 'https://account-uat.donateblood.com.au/api/createPending',
            'CallActivatePendingOscUser_ServiceURL': 'https://account-uat.donateblood.com.au/api/activatePending',
            'CallFirebaseAnalyticsGCF_ServiceURL': 'https://account-uat.donateblood.com.au/api/firebaseAnalytics',
        },
        'InAppRegistration': {
            'metadata_url': 'https://account-uat.donateblood.com.au/proxy/idp/v1/oauth/.well-known/openid-configuration',
            'jwt_audience': 'https://account-uat.donateblood.com.au/7990b8d4-b5bb-40a4-af66-1af5a29d206b/v2.0/',
            'jwt_issuer': 'https://idp-uat.donateblood.com.au/v1/oauth',
        },
        'sendGrid': {
            'serviceUrl': 'https://api.sendgrid.com/v3/mail/send',
            'fromEmail' : 'noreply@redcrossblood.org.au',
            'fromName' : 'Australian Red Cross Lifeblood',
            'verificationEmailTemplateId': 'd-85cfd23c002543b1a5066b54d9273df0',
            'verificationEmailSubject' : 'Your online verification code',
            'pwdChangeEmailTemplateId': 'd-8cb78c9f0ab94b4db35cfc1d504f097f',
            'pwdChangeEmailSubject' : 'Your password has been changed',
            'pwdResetEmailTemplateId': 'd-9cdd0d8adabb4c61ad9dcb9db4c8b919',
            'pwdResetEmailSubject' : 'Your password has been reset'
        },
        'customUILocation': 'uat',
        "inputVerificationDelayTimeInMilliseconds": 2000
    },
    'stgus': {
        'iefAuthenticationApplication': {
            'clientId': 'b52c52c4-6040-47b1-bdd6-79e6bf30f065'
        },
        'iefAuthenticationProxyApplication': {
            'clientId': 'b108d7d8-e084-485b-b318-00d02e5a9ac8'
        },
        'iefGraphApplication': {
            'id': '83b4116e-7996-4448-8640-a93524f5f1a4',
            'clientId': '2d303538-408f-46db-b218-c4c5825f7ea9'
        },
        'iefTokenConfig': {
            'TokenLifetimeSecs': '3600',
            'IdTokenLifetimeSecs': '3600',
            'RefreshLifetimeSecs': '7776000',
            'RollingRefreshLifetimeSecs': '31536000'
        },
        'ShowOutage': 'False',// Should be False by default unless you want to turn it on
        'TurnOffSignIn2FA': 'False',
        'AIInstrumentationKey': 'a1333696-c3f5-466c-9f33-2f0dc519e152',
        'AzureFunctions': {
            'ServiceURL': 'https://oscapi-stg.donateblood.com.au/api/InsertAppInsightsFromB2CHttpTrigger',
            'CreateDisabledUserFromCIAM_ServiceURL': 'https://oscapi-stg.donateblood.com.au/api/CreateDisabledUserFromCIAMHttpTrigger',
            'DataSyncEngine_ServiceURL': 'https://oscapi-stg.donateblood.com.au/api/DataSyncEngineHttpTrigger',
            'x_functions_key': 'TRU36QWPrHgvnV579ZGJHe7R6Xnr6f6A9DkasqOQe8LU/7CLO6zLyA=='
        },
        'APIGatewayFxnApp': {
            'CallCreatePendingOscUser_ServiceURL': 'https://account-stg.donateblood.com.au/api/createPending',
            'CallActivatePendingOscUser_ServiceURL': 'https://account-stg.donateblood.com.au/api/activatePending',
            'CallFirebaseAnalyticsGCF_ServiceURL': 'https://account-stg.donateblood.com.au/api/firebaseAnalytics',
        },
        'InAppRegistration': {
            'metadata_url': 'https://account-stg.donateblood.com.au/proxy/idp/v1/oauth/.well-known/openid-configuration',
            'jwt_audience': 'https://account-stg.donateblood.com.au/30ebcd45-f381-420d-a7a7-5a6440293afe/v2.0/',
            'jwt_issuer': 'https://idp-preprod.donateblood.com.au/v1/oauth',
        },
        'sendGrid': {
            'serviceUrl': 'https://api.sendgrid.com/v3/mail/send',
            'fromEmail' : 'noreply@redcrossblood.org.au',
            'fromName' : 'Australian Red Cross Lifeblood',
            'verificationEmailTemplateId': 'd-380518320b4f4d7eb9c8dbeeee38b4f4',
            'verificationEmailSubject' : 'Your online verification code',
            'pwdChangeEmailTemplateId': 'd-f668c8cf250e4a25bc36ba45a0e6277b',
            'pwdChangeEmailSubject' : 'Your password has been changed',
            'pwdResetEmailTemplateId': 'd-f6bafede927a4ad7972a2f76328f58b1',
            'pwdResetEmailSubject' : 'Your password has been reset'
        },
        'customUILocation': 'stg',
        "inputVerificationDelayTimeInMilliseconds": 2000
    },
    'prdus': {
        'iefAuthenticationApplication': {
            'clientId': '005eab88-963b-4a23-b7d8-91183b28ffdb'
        },
        'iefAuthenticationProxyApplication': {
            'clientId': '4b5f47a9-74b8-4f4c-9453-1b930a926bf9'
        },
        'iefGraphApplication': {
            'id': '16f33851-d130-4fd2-8d20-96101fef2cb7',
            'clientId': 'd9a757b5-b250-4d6c-944f-1b05cb2c04f1'
        },
        'iefTokenConfig': {
            'TokenLifetimeSecs': '3600',
            'IdTokenLifetimeSecs': '3600',
            'RefreshLifetimeSecs': '7776000',
            'RollingRefreshLifetimeSecs': '31536000'
        },
        'ShowOutage': 'False',// Should be False by default unless you want to turn it on
        'TurnOffSignIn2FA': 'False',
        'AIInstrumentationKey': '0abac339-a4da-4ff3-98cd-8beda2fdf1f2',
        'AzureFunctions': {
            'ServiceURL': 'https://oscapi.donateblood.com.au/api/InsertAppInsightsFromB2CHttpTrigger',
            'CreateDisabledUserFromCIAM_ServiceURL': 'https://oscapi.donateblood.com.au/api/CreateDisabledUserFromCIAMHttpTrigger',
            'DataSyncEngine_ServiceURL': 'https://oscapi.donateblood.com.au/api/DataSyncEngineHttpTrigger',
            'x_functions_key': 'yhVAESaLQdwQiztaP1BiG2dDTZPaxBV/YJnjqoGcE6itaDxFWbp//Q=='
        },
        'APIGatewayFxnApp': {
            'CallCreatePendingOscUser_ServiceURL': 'https://account.donateblood.com.au/api/createPending',
            'CallActivatePendingOscUser_ServiceURL': 'https://account.donateblood.com.au/api/activatePending',
            'CallFirebaseAnalyticsGCF_ServiceURL': 'https://account.donateblood.com.au/api/firebaseAnalytics',
        },
        'InAppRegistration': {
            'metadata_url': 'https://account.donateblood.com.au/proxy/idp/v1/oauth/.well-known/openid-configuration',
            'jwt_audience': 'https://account.donateblood.com.au/0101cdc2-5552-4b12-af79-28baf12931c8/v2.0/',
            'jwt_issuer': 'https://idp.donateblood.com.au/v1/oauth',
        },
        'sendGrid': {
            'serviceUrl': 'https://api.sendgrid.com/v3/mail/send',
            'fromEmail' : 'noreply@redcrossblood.org.au',
            'fromName' : 'Australian Red Cross Lifeblood',
            'verificationEmailTemplateId': 'd-1a1b9f22075b4f9f842c60c3cc77f760',
            'verificationEmailSubject' : 'Your online verification code',
            'pwdChangeEmailTemplateId': 'd-7b745008e8be4b5a910710639b63cd5f',
            'pwdChangeEmailSubject' : 'Your password has been changed',
            'pwdResetEmailTemplateId': 'd-035039d0f65b4d5f8c143eaf8f703710',
            'pwdResetEmailSubject' : 'Your password has been reset'
        },
        'customUILocation': 'prd',
        "inputVerificationDelayTimeInMilliseconds": 2000
    }
};

gulp.task('build', done => {
    for (let env in options) {
        const option = options[env];

        const tenantName = `arcbsciamb2c${env}.onmicrosoft.com`;
        const destPath = `./dist/${env}`;
        const customUIPath = `https://rcbsa${option.customUILocation}meluitempl01.blob.core.windows.net/customui`;
        const customUIPathNATIVE = `https://rcbsa${option.customUILocation}meluitempl01.blob.core.windows.net/customui/native`;

        let inAppRegPage = `${customUIPathNATIVE}/in-app-registration.html`;
        let acctCreate = `${customUIPathNATIVE}/account-creation.html`;
        let errPage = `${customUIPathNATIVE}/error.html`;
        let outagePage = `${customUIPathNATIVE}/outage.html`;
        let pwdChangePage = `${customUIPathNATIVE}/pwd-change.html`;
        let pwdResetPage = `${customUIPathNATIVE}/pwd-reset.html`;
        let pwdSetPage = `${customUIPathNATIVE}/pwd-create.html`;
        let pwdReVerifyPage = `${customUIPathNATIVE}/pwd-re-verify.html`;
        let emailVerifyPage = `${customUIPathNATIVE}/email-verify.html`;
        let signInPage = `${customUIPathNATIVE}/sign-in.html`;
        // let dmaUJSignIn = (option.ShowOutage === 'True') ? 'OUTAGE' : (option.TurnOffSignIn2FA === 'True') ? 'SignInWithFirstUsePasswordSet-NO2FA' : 'SignInWithFirstUsePasswordSet';
        // Conditional access POC - SignInWithFirstUsePasswordSet - Conditional
        let dmaUJSignIn = (option.ShowOutage === 'True') ? 'OUTAGE' : (option.TurnOffSignIn2FA === 'True') ? 'SignInWithFirstUsePasswordSet-NO2FA' : 'SignInWithFirstUsePasswordSet-Conditional';
        // let dmaUJInAppRegistration = (option.ShowOutage === 'True') ? 'OUTAGE' : 'InAppRegistration';
        // Conditional access POC
        let dmaUJInAppRegistration = (option.ShowOutage === 'True') ? 'OUTAGE' : 'InAppRegistration-Conditional';        
        let dmaUJInAppRegistrationTest = (option.ShowOutage === 'True') ? 'OUTAGE' : 'InAppRegistrationTest';
        let dmaUJPasswordChange = (option.ShowOutage === 'True') ? 'OUTAGE' : 'PasswordChange';
        let dmaUJForgotPassword = (option.ShowOutage === 'True') ? 'OUTAGE' : 'ForgotPassword';
        let dmaUJPasswordReVerification = (option.ShowOutage === 'True') ? 'OUTAGE' : 'PasswordReVerification';
        let dmaUJEmailVerification = (option.ShowOutage === 'True') ? 'OUTAGE' : 'EmailVerificationViaSendGridOTP';
        let dmaUJMobileVerification = (option.ShowOutage === 'True') ? 'OUTAGE' : 'MobileVerificationViaOTP';

        /*
         * ***************** STEP 1 **************** //
         * ----------------------------------------- //
         * ---------- Build the base file ---------- //
         * ----------------------------------------- //
         */
        gulp.src(['./src/arcbsciamb2c.onmicrosoft.com_B2C_1A_base.xml'])
            .pipe(rename(`${tenantName}_B2C_1A_base.xml`))
            .pipe((gulpif(env === 'prdus', stripCode({
                start_comment: 'start-dev-code-only-block',
                end_comment: 'end-dev-code-only-block'
            }))))
            .pipe(gulpif(env !== 'prdus' && env !== 'stgus', replace('DeploymentMode="Production"', 'DeploymentMode="Development"')))
            .pipe(gulpif(env !== 'prdus' && env !== 'stgus', replace('DeveloperMode="false"', 'DeveloperMode="true"')))
            .pipe(replace('arcbsciamb2c.onmicrosoft.com', tenantName))
            .pipe(replace('__IEFTokenLifetimeSecs__', option.iefTokenConfig.TokenLifetimeSecs))
            .pipe(replace('__IEFIdTokenLifetimeSecs__', option.iefTokenConfig.IdTokenLifetimeSecs))
            .pipe(replace('__IEFRefreshTokenLifetimeSecs__', option.iefTokenConfig.RefreshLifetimeSecs))
            .pipe(replace('__IEFRollingRefreshTokenLifetimeSecs__', option.iefTokenConfig.RollingRefreshLifetimeSecs))

            .pipe(replace('__SendGrid_From_Email__', option.sendGrid.fromEmail))
            .pipe(replace('__SendGrid_From_Name__', option.sendGrid.fromName))
            .pipe(replace('__SendGrid_Verification_Email_Template_Id__', option.sendGrid.verificationEmailTemplateId))
            .pipe(replace('__SendGrid_Verification_Email_Subject__', option.sendGrid.verificationEmailSubject))
            .pipe(replace('__SendGrid_Password_Change_Template_Id__', option.sendGrid.pwdChangeEmailTemplateId))
            .pipe(replace('__SendGrid_Password_Change_Subject__', option.sendGrid.pwdChangeEmailSubject))
            .pipe(replace('__SendGrid_Password_Reset_Template_Id__', option.sendGrid.pwdResetEmailTemplateId))
            .pipe(replace('__SendGrid_Password_Reset_Subject__', option.sendGrid.pwdResetEmailSubject))

            .pipe(replace('__inputVerificationDelayTimeInMilliseconds__', option.inputVerificationDelayTimeInMilliseconds || 2000))

            .pipe(gulp.dest(destPath));

        /*
         * ******************** STEP 2 ******************* //
         * ----------------------------------------------- //
         * ---------- Build the extension file ---------- //
         * ---------------------------------------------- //
         */
        gulp.src(['./src/arcbsciamb2c.onmicrosoft.com_B2C_1A_ext.xml'])
            .pipe(rename(`${tenantName}_B2C_1A_ext.xml`))
            .pipe(gulpif(env !== 'prdus' && env !== 'stgus', replace('DeploymentMode="Production"', 'DeploymentMode="Development"')))
            .pipe(gulpif(env !== 'prdus' && env !== 'stgus', replace('DeveloperMode="false"', 'DeveloperMode="true"')))
            .pipe(replace('arcbsciamb2c.onmicrosoft.com', tenantName))
            .pipe(replace('__IEFAuthenticationApplication_ClientId__', option.iefAuthenticationApplication.clientId))
            .pipe(replace('__AzureFunctions_ServiceURL__', option.AzureFunctions.ServiceURL))
            .pipe(replace('__AzureFunctions_OSCAPICreateDisabledUserFromCIAM_ServiceURL__', option.AzureFunctions.CreateDisabledUserFromCIAM_ServiceURL))
            .pipe(replace('__AzureFunctions_OSCAPIDataSyncEngine_ServiceURL__', option.AzureFunctions.DataSyncEngine_ServiceURL))
            .pipe(replace('__FunctionApp_Key__', option.AzureFunctions.x_functions_key))
            .pipe(replace('__APIGatewayFxnApp_CallCreatePendingOscUser_ServiceURL__', option.APIGatewayFxnApp.CallCreatePendingOscUser_ServiceURL))
            .pipe(replace('__APIGatewayFxnApp_CallActivatePendingOscUser_ServiceURL__', option.APIGatewayFxnApp.CallActivatePendingOscUser_ServiceURL))
            .pipe(replace('__APIGatewayFxnApp_CallFirebaseAnalyticsGCF_ServiceURL__', option.APIGatewayFxnApp.CallFirebaseAnalyticsGCF_ServiceURL))
            .pipe(replace('__IEFAuthenticationProxyApplication_ClientId__', option.iefAuthenticationProxyApplication.clientId))
            .pipe(replace('__IEFGraphApplication_Id__', option.iefGraphApplication.id))
            .pipe(replace('__IEFGraphApplication_ClientId__', option.iefGraphApplication.clientId))
            .pipe(replace('__AppInsightsInstrumentationKey__', option.AIInstrumentationKey))

            .pipe(replace('__metadata_url__', option.InAppRegistration.metadata_url))
            .pipe(replace('__jwt_audience__', option.InAppRegistration.jwt_audience))
            .pipe(replace('__jwt_issuer__', option.InAppRegistration.jwt_issuer))

            .pipe(replace('__SendGrid_ServiceURL__', option.sendGrid.serviceUrl))

            .pipe(gulp.dest(destPath));


        /*
         * ******************** STEP 3 ************************* //
         * ------------------------------------------------------ //
         * ----- Build the Relying Party file for NATIVE app----- //
         * ------------------------------------------------------ //
         * ---------- Password change relying party file -------- //
         * RP file needs __customUIPath.login, __customUIPath.passwordchange__ and __customUIPath.error__
         */
        gulp.src(['./src/arcbsciamb2c.onmicrosoft.com_B2C_1A_rp_password_change.xml'])
            .pipe(rename(`${tenantName}_B2C_1A_rp_password_change.xml`))
            .pipe(gulpif(env !== 'prdus' && env !== 'stgus', replace('DeploymentMode="Production"', 'DeploymentMode="Development"')))
            .pipe(gulpif(env !== 'prdus' && env !== 'stgus', replace('DeveloperMode="false"', 'DeveloperMode="true"')))
            .pipe(replace('arcbsciamb2c.onmicrosoft.com', tenantName))
            .pipe(replace('__customUIPath.passwordchange__', pwdChangePage))
            .pipe(replace('__customUIPath.login__', signInPage))
            .pipe(replace('__customUIPath.error__', errPage))
            .pipe(replace('__customUIPath.outage__', outagePage))
            .pipe(replace('__PasswordChangeUserJourneyToExecute__', dmaUJPasswordChange))
            .pipe(replace('__AppInsightsInstrumentationKey__', option.AIInstrumentationKey))
            .pipe(gulp.dest(destPath));

        /*
         * ---------- Password reset relying party file ---------- //
         * RP file needs __customUIPath.login, __customUIPath.passwordreset__ and __customUIPath.error__
         */
        gulp.src(['./src/arcbsciamb2c.onmicrosoft.com_B2C_1A_rp_password_reset.xml'])
            .pipe(rename(`${tenantName}_B2C_1A_rp_password_reset.xml`))
            .pipe(gulpif(env !== 'prdus' && env !== 'stgus', replace('DeploymentMode="Production"', 'DeploymentMode="Development"')))
            .pipe(gulpif(env !== 'prdus' && env !== 'stgus', replace('DeveloperMode="false"', 'DeveloperMode="true"')))
            .pipe(replace('arcbsciamb2c.onmicrosoft.com', tenantName))
            .pipe(replace('__customUIPath.passwordreset__', pwdResetPage))
            .pipe(replace('__customUIPath.login__', signInPage))
            .pipe(replace('__customUIPath.error__', errPage))
            .pipe(replace('__customUIPath.outage__', outagePage))
            .pipe(replace('__ForgotPasswordUserJourneyToExecute__', dmaUJForgotPassword))
            .pipe(replace('__AppInsightsInstrumentationKey__', option.AIInstrumentationKey))
            .pipe(gulp.dest(destPath));

        /*
         * ---------- Password re-verification relying party file -------- //
         * RP file needs __customUIPath.login, __customUIPath.passwordreverification__ and __customUIPath.error__
         */
        gulp.src(['./src/arcbsciamb2c.onmicrosoft.com_B2C_1A_rp_password_re_verification.xml'])
            .pipe(rename(`${tenantName}_B2C_1A_rp_password_re_verification.xml`))
            .pipe(gulpif(env !== 'prdus' && env !== 'stgus', replace('DeploymentMode="Production"', 'DeploymentMode="Development"')))
            .pipe(gulpif(env !== 'prdus' && env !== 'stgus', replace('DeveloperMode="false"', 'DeveloperMode="true"')))
            .pipe(replace('arcbsciamb2c.onmicrosoft.com', tenantName))
            .pipe(replace('__customUIPath.passwordreverification__', pwdReVerifyPage))
            .pipe(replace('__customUIPath.login__', signInPage))
            .pipe(replace('__customUIPath.error__', errPage))
            .pipe(replace('__customUIPath.outage__', outagePage))
            .pipe(replace('__UserJourneyToExecute__', dmaUJPasswordReVerification))
            .pipe(replace('__AppInsightsInstrumentationKey__', option.AIInstrumentationKey))
            .pipe(gulp.dest(destPath));

        /*
         * ---------- Email verification relying party file -------- //
         * RP file needs __customUIPath.login, __customUIPath.passwordreverification__ and __customUIPath.error__
         */
        gulp.src(['./src/arcbsciamb2c.onmicrosoft.com_B2C_1A_rp_email_verification.xml'])
            .pipe(rename(`${tenantName}_B2C_1A_rp_email_verification.xml`))
            .pipe(gulpif(env !== 'prdus' && env !== 'stgus', replace('DeploymentMode="Production"', 'DeploymentMode="Development"')))
            .pipe(gulpif(env !== 'prdus' && env !== 'stgus', replace('DeveloperMode="false"', 'DeveloperMode="true"')))
            .pipe(replace('arcbsciamb2c.onmicrosoft.com', tenantName))
            .pipe(replace('__customUIPath.emailverify__', emailVerifyPage))
            .pipe(replace('__customUIPath.login__', signInPage))
            .pipe(replace('__customUIPath.error__', errPage))
            .pipe(replace('__customUIPath.outage__', outagePage))
            .pipe(replace('__UserJourneyToExecute__', dmaUJEmailVerification))
            .pipe(replace('__AppInsightsInstrumentationKey__', option.AIInstrumentationKey))
            .pipe(gulp.dest(destPath));

        /*
         * ---------- Mobile verification relying party file -------- //
         * RP file needs __customUIPath.login, __customUIPath.passwordreverification__ and __customUIPath.error__
         */
        gulp.src(['./src/arcbsciamb2c.onmicrosoft.com_B2C_1A_rp_mobile_verification.xml'])
            .pipe(rename(`${tenantName}_B2C_1A_rp_mobile_verification.xml`))
            .pipe(gulpif(env !== 'prdus' && env !== 'stgus', replace('DeploymentMode="Production"', 'DeploymentMode="Development"')))
            .pipe(gulpif(env !== 'prdus' && env !== 'stgus', replace('DeveloperMode="false"', 'DeveloperMode="true"')))
            .pipe(replace('arcbsciamb2c.onmicrosoft.com', tenantName))
            .pipe(replace('__customUIPath.mobileverify__', emailVerifyPage))
            .pipe(replace('__customUIPath.login__', signInPage))
            .pipe(replace('__customUIPath.error__', errPage))
            .pipe(replace('__customUIPath.outage__', outagePage))
            .pipe(replace('__UserJourneyToExecute__', dmaUJMobileVerification))
            .pipe(replace('__AppInsightsInstrumentationKey__', option.AIInstrumentationKey))
            .pipe(gulp.dest(destPath));

        // ---------- Sign-in relying party file ---------- //
        gulp.src(['./src/arcbsciamb2c.onmicrosoft.com_B2C_1A_rp_sign_in.xml'])
            .pipe(rename(`${tenantName}_B2C_1A_rp_sign_in.xml`))
            .pipe(gulpif(env !== 'prdus' && env !== 'stgus', replace('DeploymentMode="Production"', 'DeploymentMode="Development"')))
            .pipe(gulpif(env !== 'prdus' && env !== 'stgus', replace('DeveloperMode="false"', 'DeveloperMode="true"')))
            .pipe(replace('arcbsciamb2c.onmicrosoft.com', tenantName))
            .pipe(replace('__customUIPath.login__', signInPage))
            .pipe(replace('__customUIPath.error__', errPage))
            .pipe(replace('__customUIPath.outage__', outagePage))
            .pipe(replace('__SignInUserJourneyToExecute__', dmaUJSignIn))
            .pipe(replace('__AppInsightsInstrumentationKey__', option.AIInstrumentationKey))
            .pipe(gulp.dest(destPath));

        // ---------- Build the in-app-registration relying party file ---------- //
        gulp.src(['./src/arcbsciamb2c.onmicrosoft.com_B2C_1A_rp_in_app_registration.xml'])
            .pipe(rename(`${tenantName}_B2C_1A_rp_in_app_registration.xml`))
            .pipe(gulpif(env !== 'prdus' && env !== 'stgus', replace('DeploymentMode="Production"', 'DeploymentMode="Development"')))
            .pipe(gulpif(env !== 'prdus' && env !== 'stgus', replace('DeveloperMode="false"', 'DeveloperMode="true"')))
            .pipe(replace('arcbsciamb2c.onmicrosoft.com', tenantName))
            .pipe(replace('__customUIPath.inappregistration__', inAppRegPage))
            .pipe(replace('__customUIPath.error__', errPage))
            .pipe(replace('__customUIPath.outage__', outagePage))
            .pipe(replace('__InAppRegistrationUserJourneyToExecute__', dmaUJInAppRegistration))
            .pipe(replace('__AppInsightsInstrumentationKey__', option.AIInstrumentationKey))
            .pipe(gulp.dest(destPath));

        // ---------- Build the in-app-registration-test relying party file ---------- //
        gulp.src(['./src/arcbsciamb2c.onmicrosoft.com_B2C_1A_rp_in_app_registration_test.xml'])
            .pipe(rename(`${tenantName}_B2C_1A_rp_in_app_registration_test.xml`))
            .pipe(gulpif(env !== 'prdus' && env !== 'stgus', replace('DeploymentMode="Production"', 'DeploymentMode="Development"')))
            .pipe(gulpif(env !== 'prdus' && env !== 'stgus', replace('DeveloperMode="false"', 'DeveloperMode="true"')))
            .pipe(replace('arcbsciamb2c.onmicrosoft.com', tenantName))
            .pipe(replace('__customUIPath.inappregistration__', inAppRegPage))
            .pipe(replace('__customUIPath.error__', errPage))
            .pipe(replace('__customUIPath.outage__', outagePage))
            .pipe(replace('__InAppRegistrationTestUserJourneyToExecute__', dmaUJInAppRegistrationTest))
            .pipe(replace('__AppInsightsInstrumentationKey__', option.AIInstrumentationKey))
            .pipe(gulp.dest(destPath));

        // ---------- Build the sign-up relying party file ---------- //
        gulp.src(['./src/arcbsciamb2c.onmicrosoft.com_B2C_1A_rp_sign_up.xml'])
            .pipe(rename(`${tenantName}_B2C_1A_rp_sign_up.xml`))
            .pipe(gulpif(env !== 'prdus' && env !== 'stgus', replace('DeploymentMode="Production"', 'DeploymentMode="Development"')))
            .pipe(gulpif(env !== 'prdus' && env !== 'stgus', replace('DeveloperMode="false"', 'DeveloperMode="true"')))
            .pipe(replace('arcbsciamb2c.onmicrosoft.com', tenantName))
            .pipe(replace('__customUIPath.registration__', acctCreate))
            .pipe(replace('__customUIPath.error__', errPage))
            .pipe(replace('__customUIPath.outage__', outagePage))
            .pipe(replace('__AppInsightsInstrumentationKey__', option.AIInstrumentationKey))
            .pipe(gulp.dest(destPath));

        // ******************** STEP 6 ********************** //
        // -------------------------------------------------- //
        // ---------- Build RP Policies for WEB app---------- //
        // -------------------------------------------------- //
        const customUIPathWEB = `https://rcbsa${option.customUILocation}meluitempl01.blob.core.windows.net/customui/web`;
        signInPage = `${customUIPathWEB}/sign-in.html`;
        pwdResetPage = `${customUIPathWEB}/pwd-reset.html`;
        pwdChangePage = `${customUIPathWEB}/pwd-change.html`;
        pwdSetPage = `${customUIPathWEB}/pwd-create.html`;
        errPage = `${customUIPathWEB}/error.html`;
        outagePage = `${customUIPathWEB}/outage.html`;
        let signInMainPage = `${customUIPathWEB}/sign-in-main.html`;
        let verifyIdentityPage = `${customUIPathWEB}/verify-identity.html`;
        let oscUJSignIn = (option.ShowOutage === 'True') ? 'OUTAGE' : (option.TurnOffSignIn2FA === 'True') ? 'SignInViaBrokerWithFirstUsePasswordSet-NO2FA' : 'SignInViaBrokerWithFirstUsePasswordSet';
        let oscUJActivate = (option.ShowOutage === 'True') ? 'OUTAGE' : 'ActivationViaBroker';
        let oscUJPwdChange = (option.ShowOutage === 'True') ? 'OUTAGE' : 'PasswordChangeViaBroker';
        let oscUJPwdReset = (option.ShowOutage === 'True') ? 'OUTAGE' : 'ForgotPassword';


        /*
         * ---------- Build the sign-in activation relying party file ---------- //
         * RP file needs __customUIPath.login, __customUIPath.passwordset__ and __customUIPath.error__
         */
        gulp.src(['./src/arcbsciamb2c.onmicrosoft.com_B2C_1A_donorconnect_activation.xml'])
            .pipe(rename(`${tenantName}_B2C_1A_donorconnect_activation.xml`))
            .pipe(gulpif(env !== 'prdus' && env !== 'stgus', replace('DeploymentMode="Production"', 'DeploymentMode="Development"')))
            //.pipe(gulpif(env !== 'prdus' && env !== 'stgus', replace('DeveloperMode="false"', 'DeveloperMode="true"')))
            .pipe(replace('arcbsciamb2c.onmicrosoft.com', tenantName))
            .pipe(replace('__customUIPath.passwordset__', pwdSetPage))
            .pipe(replace('__customUIPath.login__', signInPage))
            .pipe(replace('__customUIPath.loginmain__', signInMainPage))
            .pipe(replace('__customUIPath.error__', errPage))
            .pipe(replace('__customUIPath.outage__', outagePage))
            .pipe(replace('__ActivationUserJourneyToExecute__', oscUJActivate))
            .pipe(replace('__AppInsightsInstrumentationKey__', option.AIInstrumentationKey))
            .pipe(gulp.dest(destPath));

        /*
         * ---------- Build the password change relying party file ---------- //
         * RP file needs __customUIPath.login, __customUIPath.passwordchange__ and __customUIPath.error__
         */
        gulp.src(['./src/arcbsciamb2c.onmicrosoft.com_B2C_1A_donorconnect_password_change.xml'])
            .pipe(rename(`${tenantName}_B2C_1A_donorconnect_password_change.xml`))
            .pipe(gulpif(env !== 'prdus' && env !== 'stgus', replace('DeploymentMode="Production"', 'DeploymentMode="Development"')))
            //.pipe(gulpif(env !== 'prdus' && env !== 'stgus', replace('DeveloperMode="false"', 'DeveloperMode="true"')))
            .pipe(replace('arcbsciamb2c.onmicrosoft.com', tenantName))
            .pipe(replace('__customUIPath.passwordchange__', pwdChangePage))
            .pipe(replace('__customUIPath.login__', signInPage))
            .pipe(replace('__customUIPath.loginmain__', signInMainPage))
            .pipe(replace('__customUIPath.error__', errPage))
            .pipe(replace('__customUIPath.outage__', outagePage))
            .pipe(replace('__PasswordChangeUserJourneyToExecute__', oscUJPwdChange))
            .pipe(replace('__AppInsightsInstrumentationKey__', option.AIInstrumentationKey))
            .pipe(gulp.dest(destPath));

        /*
         * ---------- Build the password reset relying party file ---------- //
         * RP file needs __customUIPath.login, __customUIPath.passwordreset__ and __customUIPath.error__
         */
        gulp.src(['./src/arcbsciamb2c.onmicrosoft.com_B2C_1A_donorconnect_password_reset.xml'])
            .pipe(rename(`${tenantName}_B2C_1A_donorconnect_password_reset.xml`))
            .pipe(gulpif(env !== 'prdus' && env !== 'stgus', replace('DeploymentMode="Production"', 'DeploymentMode="Development"')))
            //.pipe(gulpif(env !== 'prdus' && env !== 'stgus', replace('DeveloperMode="false"', 'DeveloperMode="true"')))
            .pipe(replace('arcbsciamb2c.onmicrosoft.com', tenantName))
            .pipe(replace('__customUIPath.passwordreset__', pwdResetPage))
            .pipe(replace('__customUIPath.login__', signInPage))
            .pipe(replace('__customUIPath.error__', errPage))
            .pipe(replace('__customUIPath.outage__', outagePage))
            .pipe(replace('__ForgotPasswordUserJourneyToExecute__', oscUJPwdReset))
            .pipe(replace('__AppInsightsInstrumentationKey__', option.AIInstrumentationKey))
            .pipe(gulp.dest(destPath));

        /*
         * ---------- Build the sign-in relying party file ---------- //
         * RP file needs __customUIPath.login and __customUIPath.error__
         */
        gulp.src(['./src/arcbsciamb2c.onmicrosoft.com_B2C_1A_donorconnect_sign_in.xml'])
            .pipe(rename(`${tenantName}_B2C_1A_donorconnect_sign_in.xml`))
            .pipe(gulpif(env !== 'prdus' && env !== 'stgus', replace('DeploymentMode="Production"', 'DeploymentMode="Development"')))
            //.pipe(gulpif(env !== 'prdus' && env !== 'stgus', replace('DeveloperMode="false"', 'DeveloperMode="true"')))
            .pipe(replace('arcbsciamb2c.onmicrosoft.com', tenantName))
            .pipe(replace('__customUIPath.login__', signInPage))
            .pipe(replace('__customUIPath.loginmain__', signInMainPage))
            .pipe(replace('__customUIPath.verifyidentity__', verifyIdentityPage))
            .pipe(replace('__customUIPath.passwordset__', pwdSetPage))
            .pipe(replace('__customUIPath.error__', errPage))
            .pipe(replace('__customUIPath.outage__', outagePage))
            .pipe(replace('__SignInUserJourneyToExecute__', oscUJSignIn))
            .pipe(replace('__AppInsightsInstrumentationKey__', option.AIInstrumentationKey))
            .pipe(gulp.dest(destPath));

        //Copy the deployment script to the dist directory as well
        gulp.src([
            './New-B2CPolicy-CD.ps1' //Copy New-B2CPolicy-CD.ps1
        ])
            .pipe(gulp.dest(`${destPath}`));
    }
    done();
});
