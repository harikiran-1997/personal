#Requires -Version 5
#Requires -Assembly System.Web
#Requires -Module @{ ModuleName = "Az.Accounts"; ModuleVersion = "2.2.1" }
#Requires -Module @{ ModuleName = "Az.KeyVault"; ModuleVersion = "3.1.0" }

[CmdletBinding(
    PositionalBinding = $false,
    DefaultParameterSetName = "ValidFor"
)]

Param (
    [ValidateSet("bld","dev","dv2","tst","uat","stg","prd")]
    [string]
    $Environment = "dev",

    [ValidateNotNullOrEmpty()]
    [ValidateScript({[guid]$PSItem})]
    [string]
    $ObjectID = "244b0eca-9045-4d4e-ab58-621791d4f41a",

    [Parameter(ParameterSetName = "ValidFor")]
    [ValidateNotNullOrEmpty()]
    [timespan]
    $ValidFor = (New-TimeSpan -Minutes 20),

    [Parameter(ParameterSetName = "ExpiryTime")]
    [ValidateNotNullOrEmpty()]
    [string]
    $ExpiryTime = $null
)

Set-StrictMode -Version Latest
$ErrorActionPreference = [System.Management.Automation.ActionPreference]::Stop

if (-not $PSBoundParameters.ContainsKey("ObjectID")) {
    $ObjectID = switch ($Environment) {
        "prd" { "8effec79-a996-466a-9e2d-e619674e6bb2" }
        "stg" { "36af8998-d011-4ba2-adfd-50d2cb43e4dc" }
        "uat" { "2f0ea7b8-36c4-4b12-a672-4468380315b5" }
        "tst" { "53c0ad17-4f47-47e7-a7f4-16ba85dfc3fa" }
        "dv2" { "56dd5a96-52cc-441b-aefc-497f1bb9f97c" }
        "dev" { "9eb99a14-e2ea-4728-b291-ed206005705d" }
        "bld" { "88c11220-9418-4e02-9db6-e957b33cfe6f" }
    }
}

Add-Type -AssemblyName System.Web

if ($Environment -eq "prd") {
    $EnvironmentURL = "https://authbroker.donateblood.com.au"
} else {
    $EnvironmentURL = "https://authbroker-$($Environment).donateblood.com.au"
}

if ($PSCmdlet.ParameterSetName -eq "ValidFor") {
    $ExpiryTime = Get-Date -Date ([datetime]::Now + $ValidFor) -UFormat "%s"
}

$SecretKeyVault = "kv-rcb-$($Environment)-ciam"
$SecretKeyName = "signatureSecretKey"

Write-Verbose -Message ("Getting secret {0} from keyvault {1}" -f $SecretKeyName, $SecretKeyVault)
$SecretValue = (Get-AzKeyVaultSecret -VaultName $SecretKeyVault -Name $SecretKeyName).SecretValue
$SecretKey = if ($PSVersionTable.PSVersion -ge [version]"7.0.0") {
    ConvertFrom-SecureString -SecureString $SecretValue -AsPlainText
} else {
    try {
        $SecretStringPTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecretValue)
        [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($SecretStringPTR)
    } finally {
        [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($SecretStringPTR)
    }
}

Write-Verbose -Message ("Generating signature for objectID {0} and expiryTime {1}" -f $ObjectID, $ExpiryTime)
$HMAC512 = [System.Security.Cryptography.HMACSHA512]::new([System.Text.Encoding]::UTF8.GetBytes($SecretKey))
$SignatureHash = $HMAC512.ComputeHash([System.Text.Encoding]::UTF8.GetBytes(("'{0}'`n'{1}'" -f $ObjectID, $ExpiryTime)))
$Signature = ($SignatureHash | ForEach-Object {"{0:X2}" -f $PSItem}) -join ""

$QueryParameters = [System.Web.HttpUtility]::ParseQueryString($null)
$QueryParameters["action"] = "activate"
$QueryParameters["RelayState"] = "app/home"
$QueryParameters["objectId"] = $ObjectID
$QueryParameters["expiryTime"] = $ExpiryTime
$QueryParameters["signature"] = $Signature.ToLower()

$Endpoint = [System.UriBuilder] $EnvironmentURL
$Endpoint.Path = "/auth/execute"
$Endpoint.Query = $QueryParameters.ToString()

$ActivationLink = $Endpoint.Uri

Write-Output -InputObject $ActivationLink.AbsoluteUri

#Start-Process -FilePath $ActivationLink.AbsoluteUri
