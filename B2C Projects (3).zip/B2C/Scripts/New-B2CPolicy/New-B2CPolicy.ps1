#Requires -Version 5
#Requires -Module @{ ModuleName = "AzureADPreview"; ModuleVersion = "2.0.2.89" }

[CmdletBinding(
    ConfirmImpact = "High",
    PositionalBinding = $false,
    SupportsShouldProcess = $true,
    DefaultParameterSetName = 'Environment'
)]

Param (
    [Parameter(Mandatory = $true, ParameterSetName = 'TenantId')]
    [ValidateNotNullOrEmpty()]
    [ValidateSet("arcbsciamb2cbldus.onmicrosoft.com","arcbsciamb2cdevus.onmicrosoft.com","arcbsciamb2cdv2us.onmicrosoft.com","arcbsciamb2ctstus.onmicrosoft.com","arcbsciamb2cuatus.onmicrosoft.com","arcbsciamb2cstgus.onmicrosoft.com","arcbsciamb2cprdus.onmicrosoft.com")]
    [string] $TenantId,

    [Parameter(Mandatory = $true, ParameterSetName = 'Environment')]
    [ValidateNotNullOrEmpty()]
    [ValidateSet("bld","dev","dv2","tst","uat","stg","prd")]
    [string] $Environment = "bld",

    [Parameter(ParameterSetName = 'TenantId', Mandatory = $true)]
    [Parameter(ParameterSetName = 'Environment', Mandatory = $false)]
    [ValidateNotNullOrEmpty()]
    [ValidateScript({Test-Path -PathType Container -Path $PSItem})]
    [string] $PolicyDirectory = ".\dist\$($Environment)us"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = [System.Management.Automation.ActionPreference]::Stop

function New-B2CPolicy {
    [CmdletBinding(PositionalBinding = $false)]

    Param (
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string] $TenantId,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string] $PolicyDirectory,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string] $PolicyId
    )

    try {
        Write-Information -InformationAction Continue -MessageData "Uploading $PolicyId policy..."
        if (Get-AzureADMSTrustFrameworkPolicy -Id $PolicyId -ErrorAction Ignore) {
            Set-AzureADMSTrustFrameworkPolicy -Id $PolicyId -InputFilePath "$($PolicyDirectory)\$($TenantId)_$($PolicyId).xml" -OutputFilePath "$($PolicyDirectory)\$($TenantId)_$($PolicyId)_deployed.xml"
        } else {
            New-AzureADMSTrustFrameworkPolicy -InputFilePath "$($PolicyDirectory)\$($TenantId)_$($PolicyId).xml" -OutputFilePath "$($PolicyDirectory)\$($TenantId)_$($PolicyId)_deployed.xml"
        }
     }
     catch [Microsoft.Open.MSGraphBeta.Client.ApiException] {
        New-AzureADMSTrustFrameworkPolicy -InputFilePath "$($PolicyDirectory)\$($TenantId)_$($PolicyId).xml" -OutputFilePath "$($PolicyDirectory)\$($TenantId)_$($PolicyId)_deployed.xml"
     }
}

#---------- MODULE ----------

if ($PSCmdlet.ParameterSetName -eq "Environment") {
    $TenantId = "arcbsciamb2c{0}us.onmicrosoft.com" -f $Environment.ToLower()
}

$PolicyDirectory = Resolve-Path -Path $PolicyDirectory
Write-Verbose -Message "Using Policy Directory $($PolicyDirectory) for tenant $($TenantId)"

$AzureADCurrentSessionInfo = try {
    Get-AzureADCurrentSessionInfo
} catch [Microsoft.Open.Azure.AD.CommonLibrary.AadNeedAuthenticationException] {
    Connect-AzureAD -TenantID $TenantId
}

#---------- BASE POLICIES ----------
if ($PSCmdlet.ShouldProcess("$($AzureADCurrentSessionInfo.TenantDomain) Environment", "Deploy $PolicyDirectory")) {

    New-B2CPolicy -TenantId $TenantId -PolicyDirectory $PolicyDirectory -PolicyId "B2C_1A_base";
    New-B2CPolicy -TenantId $TenantId -PolicyDirectory $PolicyDirectory -PolicyId "B2C_1A_ext";

    #---------- DONOR MOBILE ----------
    New-B2CPolicy -TenantId $TenantId -PolicyDirectory $PolicyDirectory -PolicyId "B2C_1A_rp_password_change";
    New-B2CPolicy -TenantId $TenantId -PolicyDirectory $PolicyDirectory -PolicyId "B2C_1A_rp_password_reset";
    New-B2CPolicy -TenantId $TenantId -PolicyDirectory $PolicyDirectory -PolicyId "B2C_1A_rp_sign_in";
    New-B2CPolicy -TenantId $TenantId -PolicyDirectory $PolicyDirectory -PolicyId "B2C_1A_rp_in_app_registration";
    New-B2CPolicy -TenantId $TenantId -PolicyDirectory $PolicyDirectory -PolicyId "B2C_1A_rp_password_re_verification";
    New-B2CPolicy -TenantId $TenantId -PolicyDirectory $PolicyDirectory -PolicyId "B2C_1A_rp_email_verification";
    New-B2CPolicy -TenantId $TenantId -PolicyDirectory $PolicyDirectory -PolicyId "B2C_1A_rp_mobile_verification";

    if ($TenantId -notmatch "prdus") {
        New-B2CPolicy -TenantId $TenantId -PolicyDirectory $PolicyDirectory -PolicyId "B2C_1A_rp_sign_up";
        ##New-B2CPolicy -TenantId $TenantId -PolicyDirectory $PolicyDirectory -PolicyId "B2C_1A_rp_in_app_registration_test";
    }

    #---------- OSC ----------
    New-B2CPolicy -TenantId $TenantId -PolicyDirectory $PolicyDirectory -PolicyId "B2C_1A_donorconnect_activation";
    New-B2CPolicy -TenantId $TenantId -PolicyDirectory $PolicyDirectory -PolicyId "B2C_1A_donorconnect_password_change";
    New-B2CPolicy -TenantId $TenantId -PolicyDirectory $PolicyDirectory -PolicyId "B2C_1A_donorconnect_password_reset";
    New-B2CPolicy -TenantId $TenantId -PolicyDirectory $PolicyDirectory -PolicyId "B2C_1A_donorconnect_sign_in";
}
