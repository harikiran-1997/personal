﻿$ErrorActionPreference = "Stop";

function New-B2CExtensionProperty {
    Param (
        [string] $tenantId,
        [string] $applicationId,
        [string] $accessToken,
        [string] $extensionPropertyName,
        [string] $extensionPropertyDataType
    )

    "Creating $extensionPropertyName extension property...";
    $createExtensionPropertyRequestBody = "{`"name`":`"$extensionPropertyName`",`"dataType`":`"$extensionPropertyDataType`",`"targetObjects`":[`"User`"]}";
    $createExtensionPropertyResponse = Invoke-WebRequest "https://graph.windows.net/$tenantId/applications/$applicationId/extensionProperties/?api-version=1.6" -Method Post -Headers @{Authorization="Bearer $accessToken";"Content-Type"="application/json"} -Body $createExtensionPropertyRequestBody;
}

#---------- AUTHENTICATION ----------

#---------- Load Azure Active Directory Authentication Library (ADAL) assemblies ----------

$adalPath = "$PSScriptRoot\Microsoft.IdentityModel.Clients.ActiveDirectory.dll";

if (!(Test-Path $adalPath)) {
    "The assembly file $adal could not be found.";
    return;
}

[System.Reflection.Assembly]::LoadFile($adalPath);

$adalPlatformPath = "$PSScriptRoot\Microsoft.IdentityModel.Clients.ActiveDirectory.Platform.dll";

if (!(Test-Path $adalPlatformPath)) {
    "The assembly file $adalPlatformPath could not be found.";
    return;
}

[System.Reflection.Assembly]::LoadFile($adalPlatformPath);

#---------- Acquire access token for use with Azure Active Directory Graph API resource ----------

$authority = "https://login.microsoftonline.com/common";
$authenticationContext = New-Object Microsoft.IdentityModel.Clients.ActiveDirectory.AuthenticationContext($authority);
$resource = "https://graph.windows.net"
$clientId = "1950a258-227b-4e31-a9cf-717495945fc2"
$redirectUri = "urn:ietf:wg:oauth:2.0:oob"
$promptBehavior = [Microsoft.IdentityModel.Clients.ActiveDirectory.PromptBehavior]::Always;
$platformParameters = New-Object Microsoft.IdentityModel.Clients.ActiveDirectory.PlatformParameters($promptBehavior);
$authenticationResult = $authenticationContext.AcquireTokenAsync($resource, $clientId, $redirectUri, $platformParameters).Result;
$tenantId = $authenticationResult.TenantId;
$accessToken = $authenticationResult.AccessToken;

#---------- TENANT ----------

#---------- Get details of Azure Active Directory B2C tenant ----------

"Getting tenant details...";
$getTenantDetailsResponse = Invoke-WebRequest "https://graph.windows.net/$tenantId/tenantDetails/?api-version=1.6" -Method Get -Headers @{Authorization="Bearer $accessToken"};
$tenantDetails = (ConvertFrom-Json $getTenantDetailsResponse.Content).value;
$tenantName = $tenantDetails.VerifiedDomains | Where-Object Initial -eq "True" | Select-Object -First 1 -ExpandProperty name;
"Tenant name: $tenantName";

#---------- Get details of Azure Active Directory resource ----------

$directoryApplicationClientId = "00000002-0000-0000-c000-000000000000";
$directoryReadWriteRoleName = "Directory.ReadWrite.All";
$userReadPermissionName = "User.Read";

"Getting Azure Active Directory service principal details...";
$getDirectoryServicePrincipalResponse = Invoke-WebRequest "https://graph.windows.net/$tenantId/servicePrincipals?`$filter=appId+eq+'$directoryApplicationClientId'&api-version=1.6" -Method Get -Headers @{Authorization="Bearer $accessToken"};
$directoryServicePrincipal = (ConvertFrom-Json $getDirectoryServicePrincipalResponse.Content).value[0];
$directoryServicePrincipalId = $directoryServicePrincipal.objectId;
$directoryServicePrincipalDirectoryReadWriteRoleId = $directoryServicePrincipal.appRoles | Where-Object value -eq "$directoryReadWriteRoleName" | Select-Object -First 1 -ExpandProperty id;
$directoryServicePrincipalUserReadPermissionId = $directoryServicePrincipal.oauth2Permissions | Where-Object value -eq "$userReadPermissionName" | Select-Object -First 1 -ExpandProperty id;

#---------- APPLICATIONS ----------

#---------- EXTENSION PROPERTIES ----------

"Creating additional extension properties...";
# Build Graph ID
# $iefGraphApplicationId = "0d33f9c9-1d34-4c19-b4cb-6c943175d5cc";

# Test Graph ID
$iefGraphApplicationId = "519a5a20-058a-4fd9-9574-f842d7ff28c6";

# Dev Graph ID
# $iefGraphApplicationId = "cf017a9f-72f4-4185-b2f4-039c0ed65511"

#----New-B2CExtensionProperty -tenantId $tenantId -applicationId $iefGraphApplicationId -accessToken $accessToken -extensionPropertyName "BrokerId" -extensionPropertyDataType "String";

# The following extension properties are for masking the email address and phone number that is displayed on the 2FA choice form.
# New-B2CExtensionProperty -tenantId $tenantId -applicationId $iefGraphApplicationId -accessToken $accessToken -extensionPropertyName "MaskedAuthenticationPhoneNumber" -extensionPropertyDataType "String";
# New-B2CExtensionProperty -tenantId $tenantId -applicationId $iefGraphApplicationId -accessToken $accessToken -extensionPropertyName "MaskedAuthenticationEmail" -extensionPropertyDataType "String";
New-B2CExtensionProperty -tenantId $tenantId -applicationId $iefGraphApplicationId -accessToken $accessToken -extensionPropertyName "ForceChangePasswordNextSignIn" -extensionPropertyDataType "String";


