#Requires -Version 5
#Requires -Assembly System.Web
#Requires -Module @{ ModuleName = "Az.Accounts"; ModuleVersion = "2.2.1" }
#Requires -Module @{ ModuleName = "Az.KeyVault"; ModuleVersion = "3.1.0" }

[CmdletBinding(
    PositionalBinding = $false,
    DefaultParameterSetName = 'Secret+ValidFor'
)]

Param (
    [ValidateNotNullOrEmpty()]
    [ValidateSet('bld', 'dev', 'dv2', 'tst', 'uat', 'stg', 'prd')]
    [string]
    $Environment = 'bld',

    [ValidateNotNullOrEmpty()]
    [ValidateSet('email_verification', 'in_app_registration', 'mobile_verification')]
    [string]
    $Journey = 'in_app_registration',

    [Parameter(ParameterSetName = 'Secret+ValidFor')]
    [Parameter(ParameterSetName = 'Secret+ExpiryTime')]
    [ValidateNotNullOrEmpty()]
    [string]
    $Email = 'svc-pd-b2ckloudmonitoring@kloud.com.au',

    [Parameter(ParameterSetName = 'Secret+ValidFor')]
    [Parameter(ParameterSetName = 'Secret+ExpiryTime')]
    [ValidateNotNullOrEmpty()]
    [ValidateScript( {[guid]$PSItem} )]
    [string]
    $ObjectID = '8effec79-a996-466a-9e2d-e619674e6bb2',

    [Parameter(ParameterSetName = 'Secret+ValidFor')]
    [Parameter(ParameterSetName = 'Secret+ExpiryTime')]
    [ValidateNotNullOrEmpty()]
    [ValidatePattern('\d{6,8}')]
    [string]
    $ContactID = '000000',

    [Parameter(ParameterSetName = 'Secret+ValidFor')]
    [Parameter(ParameterSetName = 'Secret+ExpiryTime')]
    [ValidateNotNullOrEmpty()]
    [ValidatePattern('\d{10}')]
    [string]
    $Phone = '0400123456',

    [Parameter(ParameterSetName = 'Secret+ValidFor')]
    [ValidateNotNullOrEmpty()]
    [timespan]
    $ValidFor = (New-TimeSpan -Minutes 20),

    [Parameter(ParameterSetName = 'Secret+ExpiryTime')]
    [ValidateNotNullOrEmpty()]
    [datetime]
    $ExpiryTime,

    [Parameter(ParameterSetName = 'Secret+ValidFor')]
    [Parameter(ParameterSetName = 'Secret+ExpiryTime')]
    [ValidateSet('HS256')] # "HS384", "HS512" not supported..
    [string]
    $SignatureAlgorithm = 'HS256',

    [Parameter(ParameterSetName = 'IdTokenHint')]
    [ValidateNotNullOrEmpty()]
    [string]
    $IdTokenHint
)

Set-StrictMode -Version Latest
$ErrorActionPreference = [System.Management.Automation.ActionPreference]::Stop

# As per https://www.rfc-editor.org/rfc/rfc7515.html#appendix-C
function ConvertTo-Base64url {
    [CmdletBinding(DefaultParameterSetName = 'String')]
    [OutputType([string])]

    param (
        [Parameter(
            ParameterSetName = 'String',
            Mandatory = $true,
            ValueFromPipeline = $true,
            ValueFromPipelineByPropertyName = $true
        )]
        [ValidateNotNullOrEmpty()]
        [string]
        $String,

        [Parameter(
            ParameterSetName = 'Bytes',
            Mandatory = $true,
            ValueFromPipelineByPropertyName = $true
        )]
        [ValidateNotNullOrEmpty()]
        [byte[]]
        $Bytes
    )

    if ($PSCmdlet.ParameterSetName -eq 'String') {
        $Output = [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($String))
    } else {
        $Output = [Convert]::ToBase64String($Bytes)
    }

    # Remove all '=', replace '+' with '-', replace '/' with '_'
    return $Output.Replace('=', $null).Replace('+', '-').Replace('/', '_')
}

function ConvertFrom-Base64url {
    [CmdletBinding()]

    [OutputType([byte[]])]

    Param (
        [Parameter(
            Mandatory = $true,
            ValueFromPipeline = $true,
            ValueFromPipelineByPropertyName = $true
        )]
        [ValidateNotNullOrEmpty()]
        [string]
        $String
    )

    Begin {

    }

    Process {
        $Decoded = $String.Replace('-', '+').Replace('_', '/')

        switch ($Decoded.Length % 4) {
            0 {}
            2 {$Decoded += '=='}
            3 {$Decoded += '='}
            Default {Write-Warning 'Illegal base64 string!'}
        }

        Write-Output -InputObject ([Convert]::FromBase64String($Decoded))
    }

    End {

    }
}

Add-Type -AssemblyName System.Web

switch ($Environment) {
    'bld' {
        $ClientID = '461c9aaf-a776-4f94-bd98-d5d0ead9d9bc'
        $TenantID = 'ebfd88ff-cb6f-481b-a6a7-252038fa1eed'
        $TenantDomain = "account-${Environment}.donateblood.com.au"
    }
    'dev' {
        $ClientID = 'e2207036-589f-486f-b1f7-4f88f31b8cd7'
        $TenantID = 'ff1ebae6-e15a-407f-8869-03c9b0e1f5cb'
        $TenantDomain = "account-${Environment}.donateblood.com.au"
    }
    'dv2' {
        $ClientID = '27970250-641a-4d66-8085-aec829013da3'
        $TenantID = 'be54db53-4e95-479d-be24-f4377ab6b7aa'
        $TenantDomain = "account-${Environment}.donateblood.com.au"
    }
    'prd' {
        $ClientID = '5d3c7fbb-ce4a-4628-a3c5-1e281faa53e7'
        $TenantID = '0101cdc2-5552-4b12-af79-28baf12931c8'
        $TenantDomain = 'account.donateblood.com.au'
    }
    'stg' {
        $ClientID = '7899c2ba-d640-4262-88d0-d68a3adf7368'
        $TenantID = '30ebcd45-f381-420d-a7a7-5a6440293afe'
        $TenantDomain = "account-${Environment}.donateblood.com.au"
    }
    'tst' {
        $ClientID = '042e005e-c3b0-4082-876c-9093089756c0'
        $TenantID = '0a73d561-0010-403f-a710-8dbc37608b23'
        $TenantDomain = "account-${Environment}.donateblood.com.au"
    }
    'uat' {
        $ClientID = 'cdcc40db-3a26-41c0-83bc-acb261d18d78'
        $TenantID = '7990b8d4-b5bb-40a4-af66-1af5a29d206b'
        $TenantDomain = "account-${Environment}.donateblood.com.au"
    }
}

if (-not $PSBoundParameters.ContainsKey('ObjectID')) {
    $ObjectID = switch ($Environment) {
        'prd' { '8effec79-a996-466a-9e2d-e619674e6bb2' }
        'stg' { '36af8998-d011-4ba2-adfd-50d2cb43e4dc' }
        'uat' { '2f0ea7b8-36c4-4b12-a672-4468380315b5' }
        'tst' { '53c0ad17-4f47-47e7-a7f4-16ba85dfc3fa' }
        'dv2' { '56dd5a96-52cc-441b-aefc-497f1bb9f97c' }
        'dev' { '9eb99a14-e2ea-4728-b291-ed206005705d' }
        'bld' { '88c11220-9418-4e02-9db6-e957b33cfe6f' }
    }
}

$PolicyName = 'B2C_1A_rp_{0}' -f $Journey

$MetadataURL = 'https://{0}/{1}/{2}/v2.0/.well-known/openid-configuration' -f $TenantDomain, $TenantID, $PolicyName

$OIDCMetadata = Invoke-RestMethod -Uri $MetadataURL

$Endpoint = [System.UriBuilder] $OIDCMetadata.authorization_endpoint

$QueryParameters = [System.Web.HttpUtility]::ParseQueryString($Endpoint.Query)
$QueryParameters['client_id'] = $ClientID
$QueryParameters['nonce'] = (New-Guid).Guid
$QueryParameters['redirect_uri'] = "msal${ClientID}://auth"
$QueryParameters['response_mode'] = 'query'
$QueryParameters['response_type'] = 'code id_token token'
$QueryParameters['scope'] = "openid https://arcbsciamb2c${Environment}us.onmicrosoft.com/donormobile/email"

if ($PSCmdlet.ParameterSetName -like 'Secret+*') {
    $SecretKeyVault = "kv-rcb-${Environment}-ciam"
    $SecretKeyName = 'DmaJWTSecretKey'

    $Now = [datetime]::Now
    $IssuedAtTime = Get-Date -Date $Now -UFormat '%s'
    $NotBefore = Get-Date -Date $Now.AddMinutes(-5) -UFormat '%s'

    if ($PSCmdlet.ParameterSetName -like '*+ValidFor') {
        $ExpiryTime = $Now + $ValidFor
    }

    Write-Verbose -Message ('Getting secret {0} from keyvault {1}' -f $SecretKeyName, $SecretKeyVault)
    $SecretValue = (Get-AzKeyVaultSecret -VaultName $SecretKeyVault -Name $SecretKeyName).SecretValue
    $SecretKey = if ($PSVersionTable.PSVersion -ge [version]'7.0.0') {
        ConvertFrom-SecureString -SecureString $SecretValue -AsPlainText
    } else {
        try {
            $SecretStringPTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecretValue)
            [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($SecretStringPTR)
        } finally {
            [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($SecretStringPTR)
        }
    }

    Write-Verbose -Message ('Constructing Header/Payload/Signature')

    $UserDetailsToken = @{
        uuid = $ObjectID
    } | ConvertTo-Json -Compress

    $JWTHeader = @{
        'alg' = $SignatureAlgorithm
        'typ' = 'JWT'
    }

    $JWTPayload = @{
        'aud'                = $QueryParameters['redirect_uri']
        'contact_id'         = $ContactID
        'exp'                = Get-Date -Date $ExpiryTime -UFormat '%s'
        'iat'                = $IssuedAtTime
        'iss'                = 'Start In-App Registration PowerShell'
        'nbf'                = $NotBefore
        'phone'              = $Phone
        'tracking_id'        = (New-Guid).Guid
        'user_details_token' = $UserDetailsToken
        'user_exists'        = '0'
        'verify_email'       = $Email
    }

    $JWTHeaderJSON = $JWTHeader | ConvertTo-Json -Compress | ConvertTo-Base64url
    $JWTPayloadJSON = $JWTPayload | ConvertTo-Json -Compress | ConvertTo-Base64url

    $BlockToSign = $JWTHeaderJSON, $JWTPayloadJSON -join '.'

    $HMAC = switch ($SignatureAlgorithm) {
        'HS256' {New-Object -TypeName System.Security.Cryptography.HMACSHA256}
        'HS384' {New-Object -TypeName System.Security.Cryptography.HMACSHA384}
        'HS512' {New-Object -TypeName System.Security.Cryptography.HMACSHA512}
    }

    Write-Verbose -Message ('Generating signature with {0}' -f $SignatureAlgorithm)
    $HMAC.Key = [System.Text.Encoding]::UTF8.GetBytes($SecretKey)
    $SignatureHash = $HMAC.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($BlockToSign))
    $SignatureJSON = ConvertTo-Base64url -Bytes $SignatureHash

    $SignedJWT = $BlockToSign, $SignatureJSON -join '.'

    $QueryParameters['client_assertion_type'] = 'urn:ietf:params:oauth:client-assertion-type:jwt-bearer'
    $QueryParameters['client_assertion'] = $SignedJWT
} else {
    $QueryParameters['id_token_hint'] = $IdTokenHint

    ## https://account-dv2.donateblood.com.au/be54db53-4e95-479d-be24-f4377ab6b7aa/B2C_1A_donorconnect_sign_in/oauth2/v2.0/authorize?client_id=1cd8d8df-3f36-46d4-8c8f-c79a569c14f7&nonce=defaultNonce&redirect_uri=https%3A%2F%2Fjwt.ms%2F&scope=openid&response_type=id_token&prompt=login

    # $IdTokenParts = $IdTokenHint.Split('.')
    # $IdTokenHeaderBytes = ConvertFrom-Base64url -String $IdTokenParts[0]
    # $IdTokenHeader = ConvertFrom-Json -InputObject ([System.Text.Encoding]::UTF8.GetString($IdTokenHeaderBytes))

    # # $IdTokenPayloadBytes = ConvertFrom-Base64url -String $IdTokenParts[1]
    # # $IdTokenPayload = ConvertFrom-Json -InputObject ([System.Text.Encoding]::UTF8.GetString($IdTokenPayloadBytes))

    # $IdTokenSignatureBytes = ConvertFrom-Base64url -String $IdTokenParts[2]

    # $BlockToHash = [System.Text.Encoding]::UTF8.GetBytes(($IdTokenParts[0], $IdTokenParts[1] -join '.'))

    # $SHA = switch ($IdTokenHeader.alg) {
    #     'RS256' {[System.Security.Cryptography.SHA256]::Create()}
    #     'RS384' {[System.Security.Cryptography.SHA384]::Create()}
    #     'RS512' {[System.Security.Cryptography.SHA512]::Create()}
    # }

    # $SignatureHash = $SHA.ComputeHash($BlockToHash)

    # $IssuerMetadataURL = '{0}/.well-known/openid-configuration' -f 'https://account-dv2.donateblood.com.au/proxy/idp/v1/oauth'
    # ## $IssuerMetadataURL = '{0}/.well-known/openid-configuration' -f 'https://account-dv2.donateblood.com.au/be54db53-4e95-479d-be24-f4377ab6b7aa/B2C_1A_donorconnect_sign_in/v2.0/'
    # $IssuerMetadata = Invoke-RestMethod -Uri $IssuerMetadataURL
    # $JWKSEndpoint = $IssuerMetadata.jwks_uri
    # $JWKS = Invoke-RestMethod -Uri $JWKSEndpoint

    # $RSAKeys = if ((Get-Member -InputObject $IdTokenHeader -Name 'kid' -ErrorAction Ignore) -and @($JWKS.keys | Where-Object -Property 'kid' -EQ -Value $IdTokenHeader.'kid').count -eq  1) {
    #     Write-Verbose -Message ('Using specified key id [{0}] from JWKS' -f $IdTokenHeader.'kid')

    #     $jwk = $JWKS.keys | Where-Object -Property 'kid' -eq -Value $IdTokenHeader.'kid'

    #     $RSAParameters = New-Object -TypeName System.Security.Cryptography.RSAParameters
    #     $RSAParameters.Exponent = ConvertFrom-Base64url -String $jwk.e
    #     $RSAParameters.Modulus = ConvertFrom-Base64url -String $jwk.n

    #     $RSAKey = [System.Security.Cryptography.RSACng]::Create($RSAParameters)

    #     Write-Output -InputObject $RSAKey
    # } else {
    #     Write-Verbose -Message ('Trying all keys [{0}] from JWKS' -f $JWKS.keys.count)
    #     foreach ($jwk in $JWKS.keys) {
    #         $RSAParameters = New-Object -TypeName System.Security.Cryptography.RSAParameters
    #         $RSAParameters.Exponent = ConvertFrom-Base64url -String $jwk.e
    #         $RSAParameters.Modulus = ConvertFrom-Base64url -String $jwk.n

    #         $RSAKey = [System.Security.Cryptography.RSACng]::Create($RSAParameters)

    #         Write-Output -InputObject $RSAKey
    #     }
    # }

    # foreach ($RSAKey in $RSAKeys) {
    #     $RSADeformatter = New-Object -TypeName System.Security.Cryptography.RSAPKCS1SignatureDeformatter($RSAKey);
    #     $RSADeformatter.SetHashAlgorithm($SHA.GetType().BaseType.Name)
    #     $RSADeformatter.VerifySignature($SignatureHash, $IdTokenSignatureBytes)
    # }
}

$Endpoint.Query = $QueryParameters.ToString()

Write-Output -InputObject $Endpoint.Uri.AbsoluteUri
