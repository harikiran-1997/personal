#Requires -Version 5

[CmdletBinding(
    PositionalBinding = $false
)]

Param (
    [ValidateNotNullOrEmpty()]
    [ValidateSet("bld", "dev", "dv2", "tst", "uat", "stg", "prd")]
    [string]
    $Environment = "bld",

    [ValidateNotNullOrEmpty()]
    [string]
    $SignInName = "svc-pd-b2ckloudmonitoring@kloud.com.au",

    [ValidateNotNullOrEmpty()]
    [ValidatePattern("\d{6,8}")]
    [string]
    $ContactID = "000000",

    [ValidateNotNullOrEmpty()]
    [ValidatePattern("\d{10}")]
    [string]
    $Phone = "+61400123456"
)

function New-Password {
    [CmdletBinding(PositionalBinding = $false)]

    [OutputType([string])]

    Param (
        [ValidateRange(1, 128)]
        [int]
        $Length = 64
    )

    $Bytes = New-Object -TypeName System.Byte[] -ArgumentList $Length

    [System.Security.Cryptography.RNGCryptoServiceProvider]::Fill($Bytes)

    Write-Output -InputObject ([System.Convert]::ToBase64String($Bytes).Substring(0, $Length))
}

$graphApplicationClientId = switch ($Environment) {
    "prd" { "d9a757b5b2504d6c944f1b05cb2c04f1" }
    "stg" { "2d303538408f46dbb218c4c5825f7ea9" }
    "uat" { "b9ff2a0d1be1448e9f52ba3170256c05" }
    "tst" { "f42fa1ef6c864f04806f403371ffac0f" }
    "dv2" { "9c4ffb402e994009bfa6e3652689f618" }
    "dev" { "07745c17d92247bb848c6c046152f1d3" }
    "bld" { "ada375c50608411a84629894ec0fbca1" }
}

$SignInNames = @(
    [Microsoft.Open.AzureAD.Model.SignInName]::new("emailAddress", $SignInName)
)

$ExtensionProperties = [System.Collections.Generic.Dictionary`2[System.String, System.String]]::new()
$ExtensionProperties.Add("extension_$($graphApplicationClientId)_AuthenticationPhoneNumber", $Phone)
$ExtensionProperties.Add("extension_$($graphApplicationClientId)_ContactId", $ContactID)
$ExtensionProperties.Add("extension_$($graphApplicationClientId)_ForceChangePasswordNextSignIn", $false)
$ExtensionProperties.Add("extension_$($graphApplicationClientId)_MaskedAuthenticationEmail", $SignInName)
$ExtensionProperties.Add("extension_$($graphApplicationClientId)_MaskedAuthenticationPhoneNumber", $Phone)

$NewPassword = New-Password
$NewPasswordProfile = [Microsoft.Open.AzureAD.Model.PasswordProfile]::new($NewPassword, $true, $true)

$NewUserParameters = @{
    AccountEnabled    = $false
    CreationType      = "LocalAccount"
    DisplayName       = $SignInName
    ExtensionProperty = $ExtensionProperties
    PasswordPolicies  = "DisablePasswordExpiration, DisableStrongPassword"
    PasswordProfile   = $NewPasswordProfile
    SignInNames       = $SignInNames
    Verbose           = $true
}

Connect-AzureAD
New-AzureADUser @NewUserParameters
