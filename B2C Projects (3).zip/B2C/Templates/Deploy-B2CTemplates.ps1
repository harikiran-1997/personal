#Requires -Version 5
#Requires -Module Microsoft.PowerShell.Archive

[CmdletBinding(
    ConfirmImpact = "High",
    PositionalBinding = $false,
    SupportsShouldProcess = $true,
    DefaultParameterSetName = "Default"
)]

Param (
    [Parameter(Mandatory = $true)]
    [ValidateSet("bld", "dev", "dv2", "tst", "uat", "stg", "prd")]
    [string]
    $Environment,

    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string]
    $BasePath = ".\dist\"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = [System.Management.Automation.ActionPreference]::Stop

# Ensure all target files are up-to-date
Remove-Item -Path (Join-Path -Path $BasePath -ChildPath "$($Environment)us") -Recurse
gulp build

$StorageAccountName = "rcbsa$($Environment)meluitempl01.blob.core.windows.net"
$StorageContainerUI = "customui"
$StorageContainerEmails = "emails"

Push-Location -Path (Join-Path -Path $BasePath -ChildPath "$($Environment)us")

try {
    # Get/Update AzCopy
    if (-not (Test-Path -PathType Leaf -Path ..\AzCopy.exe)) {
        Write-Verbose -Message "Getting AzCopy"
        Invoke-WebRequest -Uri https://aka.ms/downloadazcopy-v10-windows -OutFile ..\AzCopy.zip
        Expand-Archive -Path ..\AzCopy.zip -DestinationPath .. -Force
        Get-ChildItem -Path ..\azcopy_windows_*\azcopy.exe | Sort-Object -Property LastWriteTime -Descending | Select-Object -First 1 | Copy-Item -Destination ..\AzCopy.exe -Force
    }

    if ($PSCmdlet.ShouldProcess("$($Environment.ToUpper()) Environment", "Deploy $($PWD.Path)")) {
        Write-Verbose -Message "Publishing B2C templates to $($Environment.ToUpper())"

        $env:AZCOPY_CRED_TYPE = "OAuthToken"
        ..\azcopy.exe login --tenant-id "redcrossbloodservice.onmicrosoft.com"
        ..\azcopy.exe copy .\* "https://$($StorageAccountName)/$($StorageContainerUI)/" --exclude-pattern="*.html" --overwrite=ifSourceNewer --recursive --put-md5 --cache-control="max-age=604800; public; must-revalidate;"
        ..\azcopy.exe copy .\* "https://$($StorageAccountName)/$($StorageContainerUI)/" --include-pattern="*.html" --overwrite=ifSourceNewer --recursive --put-md5 --cache-control="no-cache;"
        ..\azcopy.exe copy emails "https://$($StorageAccountName)/$($StorageContainerEmails)/" --exclude-pattern="*.html" --overwrite=ifSourceNewer --recursive --put-md5 --cache-control="max-age=604800; public; must-revalidate;"
        ..\azcopy.exe copy emails "https://$($StorageAccountName)/$($StorageContainerEmails)/" --include-pattern="*.html" --overwrite=ifSourceNewer --recursive --put-md5 --cache-control="no-cache;"
        ..\azcopy.exe logout
        $env:AZCOPY_CRED_TYPE = ""
    }
} finally {
    Pop-Location
}
