var ARCLB2C = ARCLB2C || {};
ARCLB2C.Passwords = ARCLB2C.Passwords || {};

(function (ARCLB2C, $, window, document, undefined) {

    /*------Show/Hide Password Toggler ------*/

    function makePwdToggler(pwd) {
        // Create show-password checkbox
        var checkbox = document.createElement('input');
        checkbox.setAttribute('type', 'checkbox');
        var id = pwd.id + 'togglercheckbox';
        checkbox.setAttribute('id', id);
        checkbox.setAttribute('class', 'password-toggler-checkbox sr-only');
        checkbox.setAttribute('tabindex', '-1');

        var label = document.createElement('label');
        label.setAttribute('for', id);

        var icon = document.createElement('i');
        icon.setAttribute('class', 'fa fa-eye');
        icon.setAttribute('aria-hidden', 'true');
        label.appendChild(icon);

        var container = document.createElement('span');
        container.id = id + 'icon';
        container.className = 'password-toggler';
        container.appendChild(checkbox);
        container.appendChild(label);

        // Add show-password checkbox under password input
        pwd.insertAdjacentElement('afterend', container);

        // Add toggle password callback
        function toggle(e) {
            if (e.keyCode !== 32 && e.keyCode !== 9) { // spacebar and tab fires the 'onclick' event (as well as 'onkeydown' event), and because this function handles both, we ignore the spacebar and tab key onkeydown event here
                if (pwd.type === 'password') {
                    pwd.type = 'text';
                } else {
                    pwd.type = 'password';
                }
                icon.classList.toggle('fa-eye-slash');
            }
        }
        checkbox.onclick = toggle;
        // For non-mouse usage
        checkbox.onkeydown = toggle;
    }

    function setupPwdTogglers() {
        var pwdInputs = document.querySelectorAll('input[type=password]');
        for (var i = 0; i < pwdInputs.length; i++) {
            makePwdToggler(pwdInputs[i]);
        }
    }

    setupPwdTogglers();

/*------ Change Password Validation ------*/

    function delay(callback, ms) {
        var timer = 0;
        return function () {
            var context = this, args = arguments;
            clearTimeout(timer);
            timer = setTimeout(function () {
                callback.apply(context, args);
            }, ms || 0);
        };
    }

    var newPasswordInput = $('#newPassword');
    var reenterPasswordInput = $('#reenterPassword');

    function handlePasswordChange(e) {

        var validIconHtml = '<div class="password-valid"><i class="fa fa-check" aria-hidden="true"></i></div>';
        if (newPasswordInput.val()) {
            if (!newPasswordInput.hasClass('invalid')) {
                if (!newPasswordInput.next('.password-valid').length) {
                    newPasswordInput.after(validIconHtml);
                }
            } else {
                newPasswordInput.next('.password-valid').remove();
            }
        } else {
            newPasswordInput.next('.password-valid').remove(); // remove tick it if it has been added via the other part of this if/else statement
        }

        if (reenterPasswordInput.val()) {
            if (reenterPasswordInput.val() !== newPasswordInput.val()) {
                reenterPasswordInput.removeClass('valid');
                reenterPasswordInput.addClass('invalid');
                reenterPasswordInput.next('.password-valid').remove();
            } else {
                reenterPasswordInput.removeClass('invalid');
                reenterPasswordInput.addClass('valid');
                if (!reenterPasswordInput.next('.password-valid').length) {
                    reenterPasswordInput.after(validIconHtml);
                }
            }
        } else {
            reenterPasswordInput.next('.password-valid').remove();
        }
    }

    reenterPasswordInput.keyup(delay(handlePasswordChange, 2000));
    newPasswordInput.keyup(delay(handlePasswordChange, 2000)); // we need it on the newPassword input in case they change the new password after already successfully confirming the password

})(ARCLB2C, jQuery, window, document);
