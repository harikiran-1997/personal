var ARCLB2C = ARCLB2C || {};
ARCLB2C.ResetLink = ARCLB2C.ResetLink || {};

(function (ARCLB2C, $, window, document, undefined) {

    /*------ Prevent user email address being appended to the Forgot Password link (since ARCL don't want PII logged anywhere) ------*/

    $("#forgotPassword").mousedown(function () {
        $("#signInName").val("");
    });

})(ARCLB2C, jQuery, window, document);
