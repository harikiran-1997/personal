var ARCLB2C = ARCLB2C || {};
ARCLB2C.Validation = ARCLB2C.Validation || {};

(function (ARCLB2C, $, window, document, undefined) {

/*------ Hide the 'This info is required.' <div>s (since they don't really add much value, plus aren't in line with ARCL UX beliefs) ------*/
    
    $('div.error').watch('aria-hidden', function () {
        $('div.error:contains("This information is required.")').hide();
    });

})(ARCLB2C, jQuery, window, document);