var ARCLB2C = ARCLB2C || {};
ARCLB2C.BypassScreens = ARCLB2C.BypassScreens || {};

(function (ARCLB2C, $, window, document, undefined) {

    /*------START - Bypass redundant screens ------*/

    // skip the redundant screens where you confirm the email address to send the verification code to in the 'log in' and 'password reset flows'
    $("#readOnlyEmailVerificationControl_but_send_code").addClass('js-enabled').click(); // this JS works in tandem with the SCSS in bypass-screens.scss - the CSS shows a spinner, and this JS automatically clicks the button for the user. Also add's a 'JS-enabled' class, so that the corresponding CSS only shows the spinner (and makes the button appear disabled) when JS is enabled - this is to support older versions of the app where JS is not enabled/available
    
    //skip screen or rename button text
    // we have to do a watch on the continue button becoming visible/not disabled, because the 'continue' button is simply 'shown' in the UI (via AJAX), rather than being made visible by a new page load
    $('#continue').watch('disabled', function () {
        // skip the (redundant) screen 'continue' (to confirm your account/email address) in the 'log in' and 'password reset flows'    
        if (!$("#continue").attr("disabled") && $("input#email-Readonly").length && $("input#email-Readonly").is(":visible")) { // check if continue button is not disabled, and "input#email-Readonly" exists and is visible
            $("#continue").click();
        }
    });

    // change the text of the continue button on the email verification and password reset flows
    if ($("input#radioVerify_email").is(":visible") || $("input#email").is(":visible")) { //check if  "input#radioVerify_email" (email verification flow) is visible or "input#email" is visible (pwd reset flow)
        $("#continue").html('SEND CODE').attr('aria-label', 'SEND CODE');
    }


/*------END - Bypass redundant screens ------*/

})(ARCLB2C, jQuery, window, document);