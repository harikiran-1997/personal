/*
 *    Filename:       Gulpfile.js
 *    Notes:          Builds the Distribution versions of the Custom UI. Each environment
 *                    (Build, Dev, Test, Stage and Prod) has separate folders.
 *    Purpose:        Builds the Distribution versions of the Custom UI.
 *    Author:         Warwick Jaensch (Telstra Purple)
 *    Date Created:   January 22nd 2018
 *    Revision History:
 *    Name:           Date:         Description:
 *      WCJ           17/01/18      Initial version.
 */

const gulp = require('gulp');
const concat = require('gulp-concat');
const cssmin = require('gulp-cssmin');
const inject = require('gulp-inject');
const jshint = require('gulp-jshint');
const notify = require('gulp-notify');
const removeCode = require('gulp-remove-code');
const rename = require('gulp-rename');
const replace = require('gulp-replace');
const sass = require('gulp-sass')(require('node-sass'));
const sourcemaps = require('gulp-sourcemaps');
const uglify = require('gulp-uglify');

const options = {
    'bldus': {
        'oscEnvironment': {
            'baseurl': 'https://tst2.donateblood.com.au',
            'my_baseurl': 'https://my-tst2.donateblood.com.au',
            'brokerBaseURL': 'https://authbroker-bld.donateblood.com.au',
            'termcondURL': 'https://www.lifeblood.com.au/terms-conditions',
            'privpolURL': 'https://www.lifeblood.com.au/privacy',
            'collstmtURL': 'https://www.lifeblood.com.au/privacy#collection-statement'
        },
        'sendGrid': {
            'template_images_Url': 'https://rcbsabldmeluitempl01.blob.core.windows.net/emails',
            'portal_login_url': 'https://my-tst2.donateblood.com.au/app/utils/login_form/redirect/home/',
            'lifeblood_tel_str': '13 14 95',
            'lifeblood_tel': '131495'
        },
        'customUILocation': 'bld'
    },
    'devus': {
        'oscEnvironment': {
            'baseurl': 'https://tst.donateblood.com.au',
            'my_baseurl': 'https://my-tst.donateblood.com.au',
            'brokerBaseURL': 'https://authbroker-dev.donateblood.com.au',
            'termcondURL': 'https://www.lifeblood.com.au/terms-conditions',
            'privpolURL': 'https://www.lifeblood.com.au/privacy',
            'collstmtURL': 'https://www.lifeblood.com.au/privacy#collection-statement'
        },
        'sendGrid': {
            'template_images_Url': 'https://rcbsadevmeluitempl01.blob.core.windows.net/emails',
            'portal_login_url': 'https://my-tst.donateblood.com.au/app/utils/login_form/redirect/home/',
            'lifeblood_tel_str': '13 14 95',
            'lifeblood_tel': '131495'
        },
        'customUILocation': 'dev'
    },
    'dv2us': {
        'oscEnvironment': {
            'baseurl': 'https://tst1.donateblood.com.au',
            'my_baseurl': 'https://my-tst1.donateblood.com.au',
            'brokerBaseURL': 'https://authbroker-dv2.donateblood.com.au',
            'termcondURL': 'https://www.lifeblood.com.au/terms-conditions',
            'privpolURL': 'https://www.lifeblood.com.au/privacy',
            'collstmtURL': 'https://www.lifeblood.com.au/privacy#collection-statement'
        },
        'sendGrid': {
            'template_images_Url': 'https://rcbsadv2meluitempl01.blob.core.windows.net/emails',
            'portal_login_url': 'https://my-tst1.donateblood.com.au/app/utils/login_form/redirect/home/',
            'lifeblood_tel_str': '13 14 95',
            'lifeblood_tel': '131495'
        },
        'customUILocation': 'dv2'
    },
    'tstus': {
        'oscEnvironment': {
            'baseurl': 'https://tst3.donateblood.com.au',
            'my_baseurl': 'https://my-tst3.donateblood.com.au',
            'brokerBaseURL': 'https://authbroker-tst.donateblood.com.au',
            'termcondURL': 'https://www.lifeblood.com.au/terms-conditions',
            'privpolURL': 'https://www.lifeblood.com.au/privacy',
            'collstmtURL': 'https://www.lifeblood.com.au/privacy#collection-statement'
        },
        'sendGrid': {
            'template_images_Url': 'https://rcbsatstmeluitempl01.blob.core.windows.net/emails',
            'portal_login_url': 'https://my-tst3.donateblood.com.au/app/utils/login_form/redirect/home/',
            'lifeblood_tel_str': '13 14 95',
            'lifeblood_tel': '131495'
        },
        'customUILocation': 'tst'
    },
    'uatus': {
        'oscEnvironment': {
            'baseurl': 'https://tst5.donateblood.com.au',
            'my_baseurl': 'https://my-tst5.donateblood.com.au',
            'brokerBaseURL': 'https://authbroker-uat.donateblood.com.au',
            'termcondURL': 'https://www.lifeblood.com.au/terms-conditions',
            'privpolURL': 'https://www.lifeblood.com.au/privacy',
            'collstmtURL': 'https://www.lifeblood.com.au/privacy#collection-statement'
        },
        'sendGrid': {
            'template_images_Url': 'https://rcbsauatmeluitempl01.blob.core.windows.net/emails',
            'portal_login_url': 'https://my-tst5.donateblood.com.au/app/utils/login_form/redirect/home/',
            'lifeblood_tel_str': '13 14 95',
            'lifeblood_tel': '131495'
        },
        'customUILocation': 'uat'
    },
    'stgus': {
        'oscEnvironment': {
            'baseurl': 'https://tst4.donateblood.com.au',
            'my_baseurl': 'https://my-tst4.donateblood.com.au',
            'brokerBaseURL': 'https://authbroker-stg.donateblood.com.au',
            'termcondURL': 'https://www.lifeblood.com.au/terms-conditions',
            'privpolURL': 'https://www.lifeblood.com.au/privacy',
            'collstmtURL': 'https://www.lifeblood.com.au/privacy#collection-statement'
        },
        'sendGrid': {
            'template_images_Url': 'https://rcbsastgmeluitempl01.blob.core.windows.net/emails',
            'portal_login_url': 'https://my-tst4.donateblood.com.au/app/utils/login_form/redirect/home/',
            'lifeblood_tel_str': '13 14 95',
            'lifeblood_tel': '131495'
        },
        'customUILocation': 'stg'
    },
    'prdus': {
        'oscEnvironment': {
            'baseurl': 'https://www.donateblood.com.au',
            'my_baseurl': 'https://my.donateblood.com.au',
            'brokerBaseURL': 'https://authbroker.donateblood.com.au',
            'termcondURL': 'https://www.lifeblood.com.au/terms-conditions',
            'privpolURL': 'https://www.lifeblood.com.au/privacy',
            'collstmtURL': 'https://www.lifeblood.com.au/privacy#collection-statement'
        },
        'sendGrid': {
            'template_images_Url': 'https://rcbsaprdmeluitempl01.blob.core.windows.net/emails',
            'portal_login_url': 'https://my.donateblood.com.au/app/utils/login_form/redirect/home/',
            'lifeblood_tel_str': '13 14 95',
            'lifeblood_tel': '131495'
        },
        'customUILocation': 'prd'
    }
};

gulp.task('build', done => {
    for (let env in options) {
        const option = options[env];

        const randomNumber = Math.random();

        const destPath = `./dist/${env}`;
        const customUIPath = `https://rcbsa${option.customUILocation}meluitempl01.blob.core.windows.net/customui`;
        const customUIPathNATIVE = `https://rcbsa${option.customUILocation}meluitempl01.blob.core.windows.net/customui/native`;
        const customUIPathWEB = `https://rcbsa${option.customUILocation}meluitempl01.blob.core.windows.net/customui/web`;

        /*
         * ******************** STEP 1 ************************* //
         * ------------------------------------------------------ //
         * ---------- Build the CustomUI for NATIVE app---------- //
         * ------------------------------------------------------ //
         */

        // SASS options
        const sassOptions = {
            errLogToConsole: true,
            outputStyle: 'expanded'
        };

        // Concatenate and minify the style files.
        const cssStreamNATIVE = gulp.src([
            './src/native/scss/native-styles.scss',
            './src/web/font-awesome/css/font-awesome.css'])
            .pipe(replace('__customUIPathNATIVE__', customUIPathNATIVE))
            .pipe(replace('__customUIPathWEB__', customUIPathWEB))
            // Output the non-minified version
            .pipe(sass(sassOptions).on('error', function (err) {
                notify().write(err);
                this.emit('end');
            }))
            .pipe(concat('styles.css'))
            .pipe(gulp.dest(`${destPath}/native/css`))
            // Minify to .min.css and add sourcemaps
            .pipe(cssmin())
            .pipe(rename({ extname: '.min.css' }))
            .pipe(gulp.dest(`${destPath}/native/css`));


        // Copy the font files.
        gulp.src(['./src/native/fonts/*'])
            .pipe(gulp.dest(`${destPath}/native/fonts`));

        // Copy the image files.
        gulp.src(['./src/native/images/*'])
            .pipe(gulp.dest(`${destPath}/native/images`));

        // Load the HTML files, modify them, and then copy to destination
        let htmlStreamNative = gulp.src(['./src/native/*.html']);

        // Inject the HTML partials
        htmlStreamNative = htmlStreamNative
            .pipe(inject(gulp.src(['./src/html-partials/head.html']), {
                starttag: '<!-- inject:head:{{ext}} -->',
                removeTags: true,
                transform: function (filePath, file) {
                    // Return file contents as string
                    return file.contents.toString('utf8');
                }
            }))
            .pipe(inject(gulp.src(['./src/html-partials/gtm-noscript.html']), {
                starttag: '<!-- inject:noscript:{{ext}} -->',
                removeTags: true,
                transform: function (filePath, file) {
                    // Return file contents as string
                    return file.contents.toString('utf8');
                }
            }));

        // Inject the concatenated, minified, style files to each of the HTML files and remove any external files.
        htmlStreamNative = htmlStreamNative.pipe(inject(cssStreamNATIVE, {
            removeTags: true,
            transform: function (filePath, file) {
                return '<style>' + file.contents.toString('utf8') + '</style>';
            }
        }));

        // Remove any external files from each of the HTML files.
        htmlStreamNative = htmlStreamNative.pipe(removeCode({
            production: true
        }));

        // Replace the placeholders with the proper values
        htmlStreamNative = htmlStreamNative.pipe(replace('__customUIPath__', customUIPath));
        htmlStreamNative = htmlStreamNative.pipe(replace('__randomNumber__', randomNumber));
        htmlStreamNative = htmlStreamNative.pipe(replace('__oscBasePath__', option.oscEnvironment.my_baseurl));

        htmlStreamNative.pipe(gulp.dest(`${destPath}/native`));

        /*
         * ******************** STEP 2 ************************* //
         * ------------------------------------------------------ //
         * ---------- Build the CustomUI for WEB app ---------- //
         * ------------------------------------------------------ //
         */

        // Concatenate and minify the style files.
        const cssStream = gulp.src([
            './src/web/scss/web-styles.scss',
            './src/web/font-awesome/css/font-awesome.css'])
            .pipe(replace('__customUIPathWEB__', customUIPathWEB))
            // Output the non-minified version
            .pipe(sass(sassOptions).on('error', function (err) {
                notify().write(err);
                this.emit('end');
            }))
            .pipe(concat('styles.css'))
            .pipe(gulp.dest(`${destPath}/web/css`))
            // Minify to .min.css and add sourcemaps
            .pipe(cssmin())
            .pipe(rename({ extname: '.min.css' }))
            .pipe(gulp.dest(`${destPath}/web/css`));

        // Copy the font files.
        gulp.src(['./src/web/fonts/*'])
            .pipe(gulp.dest(`${destPath}/web/fonts`));
        gulp.src(['./src/web/font-awesome/*'])
            .pipe(gulp.dest(`${destPath}/web/font-awesome`));

        // Copy the image files.
        gulp.src(['./src/web/images/*'])
            .pipe(gulp.dest(`${destPath}/web/images`));

        gulp.src(['./src/*.png', './src/*.ico'])
            .pipe(gulp.dest(`${destPath}/`));

        // Load the HTML files, modify them, and then copy to destination
        let htmlStreamWeb = gulp.src(['./src/web/*.html']);

        // Inject the HTML partials
        htmlStreamWeb = htmlStreamWeb
            .pipe(inject(gulp.src(['./src/html-partials/head.html']), {
                starttag: '<!-- inject:head:{{ext}} -->',
                removeTags: true,
                transform: function (filePath, file) {
                    // Return file contents as string
                    return file.contents.toString('utf8');
                }
            }))
            .pipe(inject(gulp.src(['./src/html-partials/gtm-noscript.html']), {
                starttag: '<!-- inject:noscript:{{ext}} -->',
                removeTags: true,
                transform: function (filePath, file) {
                    // Return file contents as string
                    return file.contents.toString('utf8');
                }
            }))
            .pipe(inject(gulp.src(['./src/web/html-partials/header.html']), {
                starttag: '<!-- inject:header:{{ext}} -->',
                removeTags: true,
                transform: function (filePath, file) {
                    // Return file contents as string
                    return file.contents.toString('utf8');
                }
            }))
            .pipe(inject(gulp.src(['./src/web/html-partials/footer.html']), {
                starttag: '<!-- inject:footer:{{ext}} -->',
                removeTags: true,
                transform: function (filePath, file) {
                    // Return file contents as string
                    return file.contents.toString('utf8');
                }
            }));

        // Inject the concatenated, minified, style files to each of the HTML files and remove any external files.
        htmlStreamWeb = htmlStreamWeb.pipe(inject(cssStream, {
            removeTags: true,
            transform: function (filePath, file) {
                return '<style>' + file.contents.toString('utf8') + '</style>';
            }
        }));

        // Remove any external files from each of the HTML files.
        htmlStreamWeb = htmlStreamWeb.pipe(removeCode({
            production: true
        }));

        // Replace the placeholders with the proper values
        htmlStreamWeb = htmlStreamWeb.pipe(replace('__customUIPath__', customUIPath));
        htmlStreamWeb = htmlStreamWeb.pipe(replace('__randomNumber__', randomNumber));
        htmlStreamWeb = htmlStreamWeb.pipe(replace('__oscBasePath__', option.oscEnvironment.my_baseurl));
        htmlStreamWeb = htmlStreamWeb.pipe(replace('__myoscBasePath__', option.oscEnvironment.my_baseurl));
        htmlStreamWeb = htmlStreamWeb.pipe(replace('__termcondURL__', option.oscEnvironment.termcondURL));
        htmlStreamWeb = htmlStreamWeb.pipe(replace('__privpolURL__', option.oscEnvironment.privpolURL));
        htmlStreamWeb = htmlStreamWeb.pipe(replace('__collstmtURL__', option.oscEnvironment.collstmtURL));
        htmlStreamWeb = htmlStreamWeb.pipe(replace('__brokerBaseURL__', option.oscEnvironment.brokerBaseURL));

        htmlStreamWeb.pipe(gulp.dest(`${destPath}/web`));

        /*
         * ***************** STEP 3 **************** //
         * ----------------------------------------- //
         * ---------- Build the email templates for SendGrid inc images for storage accounts ------- //
         * ----------------------------------------- //
         */

        gulp.src(['./src/emails/*.html'])
            .pipe(replace('__Email_Images_BaseURL__', option.sendGrid.template_images_Url))
            .pipe(replace('__Email_Login_URL__', option.sendGrid.portal_login_url))
            .pipe(replace('__Email_TEL_STR__', option.sendGrid.lifeblood_tel_str))
            .pipe(replace('__Email_TEL__', option.sendGrid.lifeblood_tel))
            .pipe(gulp.dest(`${destPath}/emails`));

        gulp.src(['./src/emails/images/*.png'])
            .pipe(gulp.dest(`${destPath}/emails/images`));

        /*
         * ***************** STEP 4 **************** //
         * ----------------------------------------- //
         * ---------- Build the global files ------- //
         * ----------------------------------------- //
         */

        // JS Hint
        gulp.src(['./src/js/*.js', '!./src/js/libs/*.js'])
            .pipe(jshint())
            .pipe(jshint.reporter('jshint-stylish'));

        // Minify JS, and create source maps, and rename file to .min.js (we keep a non-minified version just for dev reference purposes)
        gulp.src(['./src/js/libs/watch.js', './src/js/passwords.js', './src/js/bypass-screens.js', './src/js/validation.js', './src/js/resetlink.js']) // We need to list them specifically, so that we can put them in order (watch.js first)
            .pipe(concat('lifeblood.js')) // This is done so as to allow the possible addition of other separate JS functionality files
            .pipe(gulp.dest(`${destPath}/js`))
            .pipe(sourcemaps.init())
            .pipe(rename({ extname: '.min.js' }))
            .pipe(uglify({ mangle: true })) // .pipe(uglify({ mangle: true }).on('error', console.error))
            .pipe(sourcemaps.write('.'))
            .pipe(gulp.dest(`${destPath}/js`));

    }
    done();

});

// Watches

gulp.task('watch', function () {
    gulp.watch(['src/**/*.*'], gulp.series('watchNotifyHtmlStart', 'build', 'watchNotifyHtmlFinish')); // Note: we want .html and .css files to trigger the watch
});

gulp.task('watchNotifyHtmlStart', async function () {
    return notify('Running \'HTML\' watch task').write(''), async function (done) {
        return done();
    };
});

gulp.task('watchNotifyHtmlFinish', async function () {
    return notify('Finished running \'HTML\' watch task').write(''), async function (done) {
        return done();
    };
});
