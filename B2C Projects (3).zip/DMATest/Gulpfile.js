const gulp = require('gulp');
const replace = require('gulp-replace');
const log = require('fancy-log');

const options = {
    "bldus": {
        //old endpoint
        "identityMetadata_old": "https://login.microsoftonline.com/arcbsciamb2cbldus.onmicrosoft.com/common/v2.0/.well-known/openid-configuration",
        //new endpoint
        "identityMetadata": "https://arcbsciamb2cbldus.b2clogin.com/ebfd88ff-cb6f-481b-a6a7-252038fa1eed/common/v2.0/.well-known/openid-configuration",
        "clientID": "4c387dcd-dd95-471a-af01-5c3472532035",//Lifeblood <ENV>-H or Lifeblood <ENV>-N application Id for the B2C tenant
        "verify_email": "adee.lnasir@gmail.com", // Email address to be verified for the mobile verification policy
        "verify_mobile": "+61450459957", // Mobile number to be verified for the mobile verification policy        
        "contact_id": "6693661", //Contact Id OF THE USER - Required for Mobile and email verification policies
        //Below is required for in-app registration policy
        "user_details_token": "eyJ1dWlkIjoiZTRmNTIwMWMtOGIzMC00Zjk5LTgwNDgtYTM3OWUxZmQzZjM4IiwidG9rZW4iOiJBQUFBS2dBQUFBSUFBQUFBQUFBQUFhNzB5eXpPdVlLWkxTNGNrckNodVBHWnRRcWtLektpaU9hNGVzZ3U5N1N4NWdFbjlHamNFdHp2S0hxM2FXWEk1ZkhxNDA5bW5VSEcrdk9NM01YMkpPSkcwNTQvZjFPazhmd3FabnUrODhVdXloZVYycjJjZFc5WW1XZzVQYmFlVnMwb3ppMS9oNlFCM2g1WWI2TmVPbVlFUFRzeGVMV3RlQXpVWUFhZVVtOGRsWC9zU2xMT0ZXbFhtZFlMZFhRYkVKbFd2R0haTko2eWFRUGpDVFZ1KytoaGg1bGk1cEIrS3kzS0h6WG5qVDdLRmhiQnI3Tlc1TkoyZDdOcjRFYkQ5eFV2SU5icWVibFlqZUEvdzdjalBUMk8zZDduNDhobzh1ZlJaREZHSnhsZlFXSU84VVpnTVhQTndyU0RGcjI3V0t1c3ZVRnQxeWovdUN5Wk5pdXdhbkowZ1VPNjlYUG9LM3JndlgvVXAyWXNwSGdNNEFUSWlRVUJxNDRYZFk2WmlpWVJWc2EyV0loSkZMRFBPOFBQOGdYVXZCbDdmTUFYMHIwZzNsa1lLeTdJZGEreFJJRmxpWjh3cC9UaW5hSUpjclJRWVd6aU5DcndtYmRqSC9tTEVuZTk2SnFrem9nalBIeGtWZjBmK0dFZWhOTXNaM0Jwc1BlWmRYcmtOOWwzM25mQXJTVlBQQUlONUJsRmJ0U29vVk9CR3dIaktNUzhSVXUvdk12c1l5eVNkTG9JcXVRMndQdS9td1hXQmx1SjMxWHFIU2JETi82dFlXbDNiNnltd1NTeWs4WUNkZGdMS0VUTlc5VUFNaDVWIn0=",
        "phone": "0450459957",
        "tracking_id": "df4f1598-df70-4864-99dc-6d31b1e4cc37", //Required for in-app registration policy
        "secret": "ixDO5=N,w#3^gx9zW]x93*)O",//Lifeblood <ENV>-H or Lifeblood <ENV>-N application secret configured as a DMAJWTSecretKey policy key for the B2C tenant
        //old issuer
        "issuer_old": "https://login.microsoftonline.com/arcbsciamb2cbldus.onmicrosoft.com/v2.0/",
        //new issuer
        "issuer": "AWS Donor API",//"https://arcbsciamb2cbldus.b2clogin.com/ebfd88ff-cb6f-481b-a6a7-252038fa1eed/v2.0/"
        'tenantIdOrName': 'ebfd88ff-cb6f-481b-a6a7-252038fa1eed',
        "audience": "https://localhost:3000/auth/oidc/callback"
    },
    "devus": { 
        //old endpoint
        "identityMetadata_old": "https://login.microsoftonline.com/arcbsciamb2cdevus.onmicrosoft.com/common/v2.0/.well-known/openid-configuration",
        //new endpoint        
        "identityMetadata": "https://arcbsciamb2cdevus.b2clogin.com/ff1ebae6-e15a-407f-8869-03c9b0e1f5cb/common/v2.0/.well-known/openid-configuration",
        "clientID": "e2207036-589f-486f-b1f7-4f88f31b8cd7",//Lifeblood <ENV>-H or Lifeblood <ENV>-N application Id for the B2C tenant
        "verify_email": "adee.lnasir@gmail.com", // Email address to be verified for the mobile verification policy
        "verify_mobile": "+61450459957", // Mobile number to be verified for the mobile verification policy        
        "contact_id": "6693661", //Contact Id OF THE USER - Required for Mobile and email verification policies
        //Below is required for in-app registration policy
        "user_details_token": "eyJ1dWlkIjoiYTk3NzYxMWEtNTM1MS00ZDRhLTg5YWYtZDdhYjljMDBjNzNjIiwidG9rZW4iOiJBQUFBS2dBQUFBSUFBQUFBQUFBQUFUNEFyeU9ZSWhJS0lTNWVuWmY2TXhPdXpwaXBLdWo3N0d6ZFBKMXRtT1hFWk0ySmlxUzlLU2tEeWtnRm1QdFlMRURuRzNDTlM3dDJnc1BhT0NlL0JwQXVSYUcrNXFaUHk5NXdTZ1ZsN0xxK1Avejg4SFd2Ym95L0RpaUZlK0ZKS3pud2ZZaGh0Tzc4WXorVEFBQ1ZYdmZMUFN1ZHFVZGhVeVVEQUtSWFE3TFo2RllYWnJOTEgwTm1ITE8rRllaTHQ1KytidFpqUEJ1Wmt5TVFJR2g2NStsRWJhbTFzY1hWUWlnSUU1YnYyeWpYaVp2WE9JRkZ2bEN4N2VaWFdGRmFRYlROTUN1U3NxeGZNRnI2aWZFNFNTazRTVGhpRGVSUm5YSC9WNm5URDJ6M1NxTWpON0JLQ29RSnhQTGVRME8xaUN5U3pScmVXZktaSGpESTVXbWl4YXk0TWxxcCtNNU12Q0pRUldTcTZ2YzY2OVRCL1FYZkt3K0FYMG81T2Q4ejM5ZkhTcml2MDRjcDdRdzhkcWxaQjE5bUZ5eGpvTVVhVzI0U1gzTEVkaThoVUNFckRxc2kzSUlXemZscGhEcUI5bi9YQjhQS1ZKNWw2aVN4N1BvbkY5QU1JR2hqakxXVHUwZlhIRThPL0FaSXlDTDJZbSsxdEdWa3kxRkVvZUhoTHBhOFRFQ1Bab05SdWI1MHBvL2RYMUp3c1BCdXN1MmxTK3I3SUVvY21hRzRmYXp6dFl2VmpXWDE4bElJNElpeXljZ1U4Z3Nob3JidURoRVBqT1Zob25lNXNDbXRWWndrZU5EbzBkYUpDbDhoIn0=",
        "phone": "0450459957",
        "tracking_id": "e0f4da8b-c5aa-4bae-81f5-9fa0515f61a4", //Required for in-app registration policy
        "secret": "I5~Qx0$oUm][*f$KU6`I#5q:",//Lifeblood <ENV>-H or Lifeblood <ENV>-N application secret configured as a DMAJWTSecretKey policy key for the B2C tenant
        //old issuer
        "issuer_old": "https://login.microsoftonline.com/arcbsciamb2cdevus.onmicrosoft.com/v2.0/",
        //new issuer
        "issuer": "AWS Donor API",//"https://arcbsciamb2cdevus.b2clogin.com/ff1ebae6-e15a-407f-8869-03c9b0e1f5cb/v2.0/"
        'tenantIdOrName': 'ff1ebae6-e15a-407f-8869-03c9b0e1f5cb',
        "audience": "https://localhost:3000/auth/oidc/callback"
    },
    "dv2us": { 
        //old endpoint
        "identityMetadata_old": "https://login.microsoftonline.com/arcbsciamb2cdv2us.onmicrosoft.com/common/v2.0/.well-known/openid-configuration",
        //new endpoint
        "identityMetadata": "https://arcbsciamb2cdv2us.b2clogin.com/be54db53-4e95-479d-be24-f4377ab6b7aa/common/v2.0/.well-known/openid-configuration",
        "clientID": "27970250-641a-4d66-8085-aec829013da3",//Lifeblood <ENV>-H or Lifeblood <ENV>-N application Id for the B2C tenant
        "verify_email": "adee.lnasir@gmail.com", // Email address to be verified for the mobile verification policy
        "verify_mobile": "+61450459957", // Mobile number to be verified for the mobile verification policy        
        "contact_id": "6693661", //Contact Id OF THE USER - Required for Mobile and email verification policies
        //Below is required for in-app registration policy
        "user_details_token": "eyJ1dWlkIjoiZjE2NTRhNTQtNmZiMy00Y2MxLTk0YTQtYTBkNWNhODNmNGUxIiwidG9rZW4iOiJBQUFBS2dBQUFBSUFBQUFBQUFBQUFUelpmSE5Rb25OMnc2UGVWYVkyOUVCQU9mY1U0Rmc2a1BnMFhWeW1naHdsVGtEZWlPaEFYa1lXZFN6b0ZFZUE2UWltaVd0RnVwL0JMWnE3blpMMFh3YktuSDJHemVjMWdsaythdHgyd0Rud25jUUhYVkxtaStROUN3NFl5TWJtbExzTGVTTC9sZVR3MWpaQmFKYnlNNllIZ1BGL1ViN1YvNklWSFAwMUJHV2NxY21BeEppVklHZ2ZiRk93bkcrTmRoU2c2V1JKWllUODFJVzFLMjJjc0didUVrYnMwdWFWRk9Ta3lrK2h2TWc4dUtmb3JPak1aV3lGZEdwY2VyWmpRell0UngwN0p0V3RZeVIrS3RtQTcwYk5kVzljODZ0MHRNVStYYkI4ZUVXM3RJWHE2RVh4K210bVByNUFUODNyKzhNRU9iVGg3VGkvemNBTVl1TGtvSktUY1VJVTcvTC9NL3k0RlZCT3dRQXdpb1lNd2JRWmhrV0JKT2ZGUlpPYWJRTjRGWDYvdVA3VFo0VFhPcjR6VHRDQXdta1hWNVI0UWNtSnhiaDQxSUhyOHIxUnlNQlk5bUNYU0VJSmRacnBOb1VmeDBxUXZkK2x4SlhMZUdXZStXUHI3cEFvZi9Yc0lJU2dLN2xkRUtyQ09wdkxET0pycUo2Umd4RjMwNjVnVUZpV2IxT3M0V005Z2VTWlF1RnROT2NqU1FEVGUwNzZiVXJFODJPV3lNeDlFdkhtS2lMbTU4V2cyYldiNUFlZk9pYW5FRG10MXlkSkdBeXRCRThQbmR1OVRMRkNTaHczSlp2amxnZHNhQVYvIn0=",
        "phone": "0450459957",
        "tracking_id": "0bb2f28a-7a7a-48da-b150-4cd930b805a1", //Required for in-app registration policy
        "secret": '9mM9jOu41e0#wXP2?E2}"V(b',//Lifeblood <ENV>-H or Lifeblood <ENV>-N application secret configured as a DMAJWTSecretKey policy key for the B2C tenant
        //old issuer
        "issuer_old": "https://login.microsoftonline.com/arcbsciamb2cdv2us.onmicrosoft.com/v2.0/",
        //new issuer
        "issuer": "AWS Donor API",//"https://arcbsciamb2cdv2us.b2clogin.com/be54db53-4e95-479d-be24-f4377ab6b7aa/v2.0/"
        'tenantIdOrName': 'be54db53-4e95-479d-be24-f4377ab6b7aa',
        "audience": "https://localhost:3000/auth/oidc/callback"
    },
    "tstus": {
        //old endpoint
        "identityMetadata_old": "https://login.microsoftonline.com/arcbsciamb2ctstus.onmicrosoft.com/common/v2.0/.well-known/openid-configuration",
        //new endpoint
        "identityMetadata": "https://arcbsciamb2ctstus.b2clogin.com/0a73d561-0010-403f-a710-8dbc37608b23/common/v2.0/.well-known/openid-configuration",
        "clientID": "042e005e-c3b0-4082-876c-9093089756c0",//Lifeblood <ENV>-H or Lifeblood <ENV>-N application Id for the B2C tenant
        "verify_email": "adee.lnasir@gmail.com", // Email address to be verified for the mobile verification policy
        "verify_mobile": "+61450459957", // Mobile number to be verified for the mobile verification policy        
        "contact_id": "6693661", //Contact Id OF THE USER - Required for Mobile and email verification policies
        //Below is required for in-app registration policy
        "user_details_token": "eyJ1dWlkIjoiNjE3MmE3MmItYTUwYi00ODVmLWJjOGUtYjY3Njg4OGRhNzUzIiwidG9rZW4iOiJBQUFBS2dBQUFBSUFBQUFBQUFBQUFhb2tBdzVzUzcrRm5pSUlOQ1d3QjlHSjBaWjVQejVsUWJhWUt1c0greTExQk55bHVCc2JJWit1RGFaYXEzUFlLcHg5YzJkeU5SdTlocCtlUnVMMjFINGw4bUc0SnVWQlduclFIRXY3VGFwSWlpWnZEZHQvYVpyOHVWa1J1eWhNTnBzSTNvTUVpRVRIVUFmQmc4a2tBV2dveEF6cTJYMVBhYk92SjFTaWVRMUpNNmlUSURkUFNlQmhBWmRSamRReXBhSmdFc3dyLzc5N2VsRDkzNi9LemhPa2xvV1dEV3ZYdXZkankwR2YzcjhObDBKSXk3L3d3dWRrRWdXeHdudzFXSDZ2ZVlOWkpvYjdWSENoTzFiUFV1MmFBazlzOEN2OVpkblZpUk1qMmJtZ1JzdUNFNTVTcXdhZTFOVGJzQmFWbFlYWGcxV1IyU0oxNGY0WS9IWERWTkhab3A4em1JVWdtK3JMMXRvaDFyY3BINUpLN25GTWhLL1dBNmI3QWxzQ09iTG9mYWlMVTI5Qm1IYzdla1hPNnB4bGxMNlQzTVlNcnpRV0R4NlFndGFkSDQvdVErV3plQjFWSktIUWVUNU5TQW51S0VqRTZPZXZmK3Jqd0Y5VzVWM09JV0NPYldTckpyNGQ2UUZDZjdIem13TUV3S24xWnZVa1o4bjI2WHNmVFBhWXg2ZHlSMjVRN3hCTzgxaTE4NFdqb21YRVlFSUpFVkQwZFhBRnIxNkZidUVJbXhlbkZ4OWZRWFhDTWFkZ3RDMG16blFjZ1ZJb0xDSjUrcDQ0ZUs0ZHRPZFF6OWlIeXM4YitlbnExUUhEIn0=",
        "phone": "0450459957",
        "tracking_id": "38633389-4b7b-4a53-a24f-9a46b183b6b9", //Required for in-app registration policy
        "secret": "q/8Sr48vu.2Q1Bowh.:?i(!I",//Lifeblood <ENV>-H or Lifeblood <ENV>-N application secret configured as a DMAJWTSecretKey policy key for the B2C tenant
        //old issuer
        "issuer_old": "https://login.microsoftonline.com/arcbsciamb2ctstus.onmicrosoft.com/v2.0/",
        //new issuer
        "issuer": "AWS Donor API",//"https://arcbsciamb2ctstus.b2clogin.com/0a73d561-0010-403f-a710-8dbc37608b23/v2.0/"
        'tenantIdOrName': '0a73d561-0010-403f-a710-8dbc37608b23',
        "audience": "https://localhost:3000/auth/oidc/callback"
    },
    "uatus": {
        //old endpoint
        "identityMetadata_old": "https://login.microsoftonline.com/arcbsciamb2cuatus.onmicrosoft.com/common/v2.0/.well-known/openid-configuration",
        //new endpoint 
        "identityMetadata": "https://arcbsciamb2cuatus.b2clogin.com/7990b8d4-b5bb-40a4-af66-1af5a29d206b/common/v2.0/.well-known/openid-configuration",
        "clientID": "f890f87c-accd-4d31-827f-10423aa1ddaa",//Lifeblood <ENV>-H or Lifeblood <ENV>-N application Id for the B2C tenant
        "verify_email": "adee.lnasir@gmail.com", // Email address to be verified for the mobile verification policy
        "verify_mobile": "+61450459957", // Mobile number to be verified for the mobile verification policy        
        "contact_id": "6693661", //Contact Id OF THE USER - Required for Mobile and email verification policies
        //Below is required for in-app registration policy
        "user_details_token": "eyJ1dWlkIjoiM2ExMDYzN2EtMDI2NC00M2YwLTk1MDUtMDZiYjk1YjgyNDlmIiwidG9rZW4iOiJBQUFBS2dBQUFBSUFBQUFBQUFBQUFZa3lHRy9lcHh5RTdZZ1FHUUw3eXlrdXNFeE5oNllJVXdlV3ZHWUhObHVTZXkvV1pPRDN4T1lpMWR6cUdUc1ZNdnZvTGNBMXpGRE5tUkhEajVwMTNucSt0anEzeCtnUTMrdHd2ZVBEOUxmOGNmR2dpTmp4YVFmak5iOXRYQ0hKNUlubUIwdjhXTHpMMGN2S0N6TnQzaHZha0pleVhrN0NMZCs0RGRqeEduanJyTk16NmI5bnRXWmUzWGNTN2Y2K3U5VDR2SUxHYWUwZml1WkFrMFBLUjlWSStlSlIyclpwdVA4WTg2bTh5WGRZamtWdk5WaGNSSEFpVDhuUWZPVTV5cHpWK2JTa01WN2xMY2F6aWJZbytIbFpnM2R2V1dRNnRabGlqMGR1MFZOL05kSXVHb002bzc4NURoUnF2OHFGUDE2N2FaZnRtejcxMm4xbEpRODZiR1BaVVJKS1JsUHF4K2oyZmZqc2F6MG96QjVvcUNUQUl1UDRlVTlOWFp3Z29RV2JFdzV4SHJacU5UVW1zVUlCRERneWZycUovNm1LMjJVREdrbCsxYU5KMGV4U1I3NGdJUTNYYlczWHBPSUpmMGhFSjF1NHhPek5la1VTUXV3elJXeHdHK20yNWtTSDVyQzNVUDFTWXVnS1VnbG5DOEVNT2JxbjZFbzBvOUl2eUVhWDRmaHFyZ1NmMkhuRGJLaTdQWTNzV3k5RUg0VkVTQ1VKMEVlUXF5U1djdGxJZlpnOGJxTUdFeG9QUWNaLzlIbUVoVWZhNDluWUZsUUpuSDVlWm5aV0MyT3BLZkZ2MEJ0N3RVcEpFYnZRIn0=",
        "phone": "0450459957",
        "tracking_id": "4530a006-487a-4b7c-9fef-ae546c7c187b", //Required for in-app registration policy
        "secret": "5T4~=>%Q8979423.y_gH&!Mx",//Lifeblood <ENV>-H or Lifeblood <ENV>-N application secret configured as a DMAJWTSecretKey policy key for the B2C tenant
        //old issuer
        "issuer_old": "https://login.microsoftonline.com/arcbsciamb2cuatus.onmicrosoft.com/v2.0/",
        //new issuer
        "issuer": "AWS Donor API",//"https://arcbsciamb2cuatus.b2clogin.com/7990b8d4-b5bb-40a4-af66-1af5a29d206b/v2.0/"
        'tenantIdOrName': '7990b8d4-b5bb-40a4-af66-1af5a29d206b',
        "audience": "https://localhost:3000/auth/oidc/callback"
    },
    "stgus": {
        //old endpoint
        "identityMetadata_old": "https://login.microsoftonline.com/arcbsciamb2cstgus.onmicrosoft.com/common/v2.0/.well-known/openid-configuration",
        //new endpoint
        "identityMetadata": "https://account-stg.donateblood.com.au/30ebcd45-f381-420d-a7a7-5a6440293afe/common/v2.0/.well-known/openid-configuration",
        "clientID": "2ebda191-b013-4f28-8f00-6f0c5d9a04fa",//Lifeblood <ENV>-H or Lifeblood <ENV>-N application Id for the B2C tenant
        "verify_email": "adee.lnasir@gmail.com", // Email address to be verified for the mobile verification policy
        "verify_mobile": "+61450459957", // Mobile number to be verified for the mobile verification policy        
        "contact_id": "6693661", //Contact Id OF THE USER - Required for Mobile and email verification policies
        //Below is required for in-app registration policy
        "user_details_token": "eyJ1dWlkIjoiYzUyODE3NGUtMjM4My00ZTRhLWI4ZTMtN2E0ZTViYWQyMDM5IiwidG9rZW4iOiJBQUFBS2dBQUFBSUFBQUFBQUFBQUFSN3FaVHVSV3hDM2tsYlgxQUVOdU5sN1ZQcXBDZ2M2NVZRVXF1TS9rUTJrRnhMWTAyMkdIb3NLZGI0dkRFRzdEdCthTi9hYXgzOEdvemNYaGdDdlB4S1lWek15M2d2NFIwaDhiSWJRS2ZkbU56dTBZTFYzemlaVGdRcHJWaU5CT3FPTVZXNUNOLytFMmtlQkFnTW1OWHlEa3NrQzRZS0FCWUd1RGU5ZkxzMnB2TzJNNU9Ic0xWelh1UzErZG5FaFVoNUJuQVVzaVJpdnlFbUZhTFBpTXFtVFpoUnBWTm8wczdoTllUUml3QlR4UG8xQUo1VkVIbTFHYS8xSmFlTlFsZU1lbWwvL2YvaTV1T0Y5Yjh5cVgwOEp1ZkJRVC8zMndFSnBpTk5wWUt1WU5QKzlsa0s5TU5XdGFSV0M2bjNrMzVXNnRRQi81T3B5Q0M2T3ZKVjJJM1FQSWlwNUtUVWdsRmQ2NVUvNDF5OHlXQzZxbjhNYlJmc2h3OENIK0dUM1BaNjdiYU84MmZDWE1DbURBWVRwVWQ1QnRRaDlnV0ZCSkZGb3RoVUNHQ2tkSmdKWlRveTRsN0dkWG52c2lZQy9XdVk0Zlp5L09zTDc2Z2xKcVVwU1NBLzhNS29hYTB5dlBaQnZlWDIrL3RMZDNkZ2svZXJTOEtxbWNOaGZtcDVyeThQWnU5VDVuZnd2UCtEQXhrd20zcFZwL0lJVFl0YWFDRW9rdUFTckxOQVRmL2hLRVhrUDJweWJsM2x6U2htTCtLUUhCSHJyR2I1RTZlbVpFbUdZNmVUSlJZejlpaEI1QUJrekF2Y0pVdXhrIn0=",
        "phone": "0450459957",
        "tracking_id": "2129cbe4-342d-4558-913c-c16f6752055a", //Required for in-app registration policy
        "secret": "Eu-TV0*o=9NB8K8LEq0D5$oZ",//Lifeblood <ENV>-H or Lifeblood <ENV>-N application secret configured as a DMAJWTSecretKey policy key for the B2C tenant
        //old issuer
        "issuer_old": "https://login.microsoftonline.com/arcbsciamb2cstgus.onmicrosoft.com/v2.0/",
        //new issuer
        "issuer": "AWS Donor API",//"https://account-stg.donateblood.com.au/30ebcd45-f381-420d-a7a7-5a6440293afe/v2.0/"
        'tenantIdOrName': '30ebcd45-f381-420d-a7a7-5a6440293afe',
        "audience": "https://localhost:3000/auth/oidc/callback"
    },
    "prdus": {
        //old endpoint
        "identityMetadata_old": "https://login.microsoftonline.com/arcbsciamb2cprdus.onmicrosoft.com/common/v2.0/.well-known/openid-configuration",
        //new endpoint
        "identityMetadata": "https://account.donateblood.com.au/0101cdc2-5552-4b12-af79-28baf12931c8/common/v2.0/.well-known/openid-configuration",
        "clientID": "938b0606-06d8-4244-8a08-054753c95a78",//Lifeblood <ENV>-H or Lifeblood <ENV>-N application Id for the B2C tenant
        "verify_email": "adee.lnasir@gmail.com", // Email address to be verified for the mobile verification policy
        "verify_mobile": "+61450459957", // Mobile number to be verified for the mobile verification policy        
        "contact_id": "6693661", //Contact Id OF THE USER - Required for Mobile and email verification policies
        //Below is required for in-app registration policy
        "user_details_token": "",
        "phone": "",
        "tracking_id": "", //Required for in-app registration policy
        "secret": "Ho0=TvfB6-cl2Q0V.P95>D7D",//Lifeblood <ENV>-H or Lifeblood <ENV>-N application secret configured as a DMAJWTSecretKey policy key for the B2C tenant
        //old issuer
        "issuer_old": "https://login.microsoftonline.com/arcbsciamb2cprdus.onmicrosoft.com/v2.0/",
        //new issuer
        "issuer": "AWS Donor API",
        'tenantIdOrName': '0101cdc2-5552-4b12-af79-28baf12931c8',
        "audience": "https://localhost:3000/auth/oidc/callback"
    }
};

gulp.task('build', done => {
    
/*
  _______ ____  _____   ____  
 |__   __/ __ \|  __ \ / __ \ 
    | | | |  | | |  | | |  | |
    | | | |  | | |  | | |  | |
    | | | |__| | |__| | |__| |
    |_|  \____/|_____/ \____/ 
                              
    DONT FORGET TO CHANGE THE BELOW TARGET ENVIRONMENT BEFORE RUNNING IT
    Also change the relevant values in above environment sections
*/    
    const env = 'bldus';
    const configType='new';    
    const option = options[env];

    const destPath = `./dist/`;


    log(`Starting to copy the root files for '${env}' environment.`);

    //copy all files
    gulp.src(['./**',
    '!./dist/**',           //exclude the dist folder for now
    '!./app.js',             //exclude the app.js
    '!./gulpfile.js'             //exclude the app.js
    ])
    .pipe(gulp.dest(`${destPath}`));

    //prepare app.js and replace to destination
    if(configType === 'old')
    {
        gulp.src(['./app.js'])
        .pipe(replace('__identityMetadata__', option.identityMetadata_old))
        .pipe(replace('__clientID__', option.clientID))
        .pipe(replace('__verify_email__', option.verify_email))        
        .pipe(replace('__verify_mobile__', option.verify_mobile))
        .pipe(replace('__contact_id__', option.contact_id))
        .pipe(replace('__user_details_token__', option.user_details_token))
        .pipe(replace('__phone__', option.phone))
        .pipe(replace('__tracking_id__', option.tracking_id))
        .pipe(replace('__secret__', option.secret))
        .pipe(replace('__issuer__', option.issuer_old))
        .pipe(replace('__tenantIdOrName__', option.tenantIdOrName))
        .pipe(replace('__audience__', option.audience))
        .pipe(gulp.dest(destPath));
    }
    else
    {
        gulp.src(['./app.js'])
        .pipe(replace('__identityMetadata__', option.identityMetadata))
        .pipe(replace('__clientID__', option.clientID))
        .pipe(replace('__verify_email__', option.verify_email))        
        .pipe(replace('__verify_mobile__', option.verify_mobile))
        .pipe(replace('__contact_id__', option.contact_id))
        .pipe(replace('__user_details_token__', option.user_details_token))
        .pipe(replace('__phone__', option.phone))
        .pipe(replace('__tracking_id__', option.tracking_id))
        .pipe(replace('__secret__', option.secret))
        .pipe(replace('__issuer__', option.issuer))
        .pipe(replace('__tenantIdOrName__', option.tenantIdOrName))
        .pipe(replace('__audience__', option.audience))
        .pipe(gulp.dest(destPath));
    }
    
    done();
});
