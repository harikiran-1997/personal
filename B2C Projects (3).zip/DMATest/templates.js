const fs = require('fs');
const path = require('path');

const ejs = require('ejs');

var templates = fs.readdirSync(path.join(__dirname, './templates'));

templates.forEach(fileName => {
    var fileContent = fs.readFileSync(path.join(__dirname, './templates', fileName));
    var template = ejs.compile(fileContent.toString());
    exports[fileName.slice(0, -4)] = template;
});
