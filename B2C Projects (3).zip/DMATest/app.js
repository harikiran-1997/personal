const fs = require('fs');
const path = require('path');

const express = require('express');
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const passport = require('passport');
const OIDCStrategy = require('passport-azure-ad').OIDCStrategy;
const jwt = require('jsonwebtoken');
//const samlp = require('samlp');

//const claimsMapper = require('./claimsMapper');
const templates = require('./templates');

function generateUniqueID() {
    var uniqueID = '';
    const chars = 'abcdef0123456789';

    for (var i = 0; i < 20; i++) {
        uniqueID += chars.substr(Math.floor((Math.random() * 15)), 1);
    }

    return uniqueID;
};

const app = express();
app.use(cookieParser());

app.use(bodyParser.urlencoded({
    extended: true
}));

passport.use(
    new OIDCStrategy(
        {            
            identityMetadata: '__identityMetadata__', 
            clientID: '__clientID__',
            responseType: 'id_token',
            responseMode: 'form_post',
            redirectUrl: 'https://localhost:3000/auth/oidc/callback',
            isB2C: true,
            validateIssuer: false,
            passReqToCallback: true,
            allowHttpForRedirectUrl: true, // Required to set to true if you want to use http url for redirectUrl like http://localhost:3000.
            useCookieInsteadOfSession: true,
            cookieEncryptionKeys: [
                {
                    key: '12345678901234567890123456789012',
                    iv: '123456789012'
                }
            ],
            loggingLevel: 'info',
            nonceLifetime: 300,
            nonceMaxAmount: 5
        },
        (req, iss, sub, profile, jwtClaims, accessToken, refreshToken, params, done) => {
            done(null, jwtClaims);
        })
);

app.use(passport.initialize());
app.use(function (err, req, res, next) {
    console.error(err.stack)
    res.status(500).send('Something broke!')
  });

app.get('/', (req, res) => {
    if (req.user) {
        res.send(`Hello, ${req.user.name}!`);
    } else {
        res.send('Hello, World!');
    }
});

app.get(
    '/create',
    (req, res, next) => {

        req.query.p = 'B2C_1A_rp_in_app_registration';
        next();
        
    },
    (req, res, next) => {

        //create and sign the JWT and add it to the strategy

        //Current Date/Time
        const now = Math.round(new Date().getTime() / 1000);

        //we are subtracting 2 minutes to handle the time difference between Azure and AWS servers. 
        //We were getting 403: NotBeforeError, jwt not active
        let MS_PER_MINUTE = 60000;
        let durationInMinutes = 2
        const nowMinus2 = Math.round((new Date().getTime() - durationInMinutes * MS_PER_MINUTE) / 1000);
        // Add 20 minutes to the current time
        const expiryActivation = new Date().getTime() + (20 * 60 * 1000);//change it to 20
        const the_TTL = Math.round(expiryActivation / 1000);

        var token = jwt.sign(
            {
                //Email address to be verified for the new user
                verify_email: '__verify_email__',
                //User details token for OSC by AWS API Gateway (DMA)
                user_details_token: '__user_details_token__',
                contact_id:'',
                phone: '__phone__',
                user_exists:'0',
                //Firebase tracking Id
                tracking_id: '__tracking_id__',
                nbf: nowMinus2,
                iat: nowMinus2,
                exp: the_TTL
            },            
            '__secret__', //JWT signing shared secret key
            {
                //token issuer                 
                issuer: '__issuer__', 
                audience: '__audience__'
            }
        );
        console.log(`JWT token signed. Setting extra query string params.`);                    

        var extraAuthReqQueryParams= {
            'client_assertion_type': 'urn:ietf:params:oauth:client-assertion-type:jwt-bearer',
            'client_assertion': token
        }
        console.log('before azuread-openidconnect');
        passport.authenticate('azuread-openidconnect', {
            tenantIdOrName: '__tenantIdOrName__',
            extraAuthReqQueryParams: extraAuthReqQueryParams,
            failureRedirect: '/failure',
            session: false,
            response: res
        })(req, res, next);
    },
    (req, res) => {
        console.log('inside auth before redirect');
        res.redirect('/');
    }
);

app.get(
    '/verify',
    (req, res, next) => {

        req.query.p = 'B2C_1A_rp_email_verification';
        next();
        
    },
    (req, res, next) => {

        //create and sign the JWT and add it to the strategy

        //Current Date/Time
        const now = Math.round(new Date().getTime() / 1000);

        //we are subtracting 2 minutes to handle the time difference between Azure and AWS servers. 
        //We were getting 403: NotBeforeError, jwt not active
        let MS_PER_MINUTE = 60000;
        let durationInMinutes = 2
        const nowMinus2 = Math.round((new Date().getTime() - durationInMinutes * MS_PER_MINUTE) / 1000);
        // Add 20 minutes to the current time
        const expiryActivation = new Date().getTime() + (20 * 60 * 1000);//change it to 20
        const the_TTL = Math.round(expiryActivation / 1000);

        var token = jwt.sign(
            {
                //Email address to be verified for the new user
                verify_email: '__verify_email__',
                contact_id:'__contact_id__',
                nbf: nowMinus2,
                iat: nowMinus2,
                exp: the_TTL
            },            
            '__secret__', //JWT signing shared secret key
            {
                //token issuer                 
                issuer: '__issuer__', 
                audience: '__audience__'
            }
        );
        console.log(`JWT token signed. Setting extra query string params.`);                    

        var extraAuthReqQueryParams= {
            'client_assertion_type': 'urn:ietf:params:oauth:client-assertion-type:jwt-bearer',
            'client_assertion': token
        }
        console.log('before azuread-openidconnect');
        passport.authenticate('azuread-openidconnect', {
            tenantIdOrName: '__tenantIdOrName__',
            extraAuthReqQueryParams: extraAuthReqQueryParams,
            failureRedirect: '/failure',
            session: false,
            response: res
        })(req, res, next);
    },
    (req, res) => {
        console.log('inside auth before redirect');
        res.redirect('/');
    }
);

app.get(
    '/verify-mobile',
    (req, res, next) => {

        req.query.p = 'B2C_1A_rp_mobile_verification';
        next();
        
    },
    (req, res, next) => {

        //create and sign the JWT and add it to the strategy

        //Current Date/Time
        const now = Math.round(new Date().getTime() / 1000);

        //we are subtracting 2 minutes to handle the time difference between Azure and AWS servers. 
        //We were getting 403: NotBeforeError, jwt not active
        let MS_PER_MINUTE = 60000;
        let durationInMinutes = 2
        const nowMinus2 = Math.round((new Date().getTime() - durationInMinutes * MS_PER_MINUTE) / 1000);
        // Add 20 minutes to the current time
        const expiryActivation = new Date().getTime() + (20 * 60 * 1000);//change it to 20
        const the_TTL = Math.round(expiryActivation / 1000);

        var token = jwt.sign(
            {
                //Email address to be verified for the new user
                verify_mobile: '__verify_mobile__',
                contact_id:'__contact_id__',
                nbf: nowMinus2,
                iat: nowMinus2,
                exp: the_TTL
            },            
            '__secret__', //JWT signing shared secret key
            {
                //token issuer                 
                issuer: '__issuer__', 
                audience: '__audience__'
            }
        );
        console.log(`JWT token signed. Setting extra query string params.`);                    

        var extraAuthReqQueryParams= {
            'client_assertion_type': 'urn:ietf:params:oauth:client-assertion-type:jwt-bearer',
            'client_assertion': token
        }
        console.log('before azuread-openidconnect');
        passport.authenticate('azuread-openidconnect', {
            tenantIdOrName: '__tenantIdOrName__',
            extraAuthReqQueryParams: extraAuthReqQueryParams,
            failureRedirect: '/failure',
            session: false,
            response: res
        })(req, res, next);
    },
    (req, res) => {
        console.log('inside auth before redirect');
        res.redirect('/');
    }
);

app.post(
    '/auth/oidc/callback',
    (req, res, next) => {
        console.log('inside callback');
        passport.authenticate('azuread-openidconnect', {
            failureRedirect: '/failure',
            session: false,
            response: res
        })(req, res, next);
    },
    (req, res, next) => {
        console.log('inside callback before send');
        res.send();
    }
);

app.get('/failure', (req, res, next) => {

    console.log('inside failure');
    //console.log(`Received request: '${JSON.stringify(req)}'.`);
    //console.log(`sending response: '${JSON.stringify(res)}'.`);

});

module.exports = app;
