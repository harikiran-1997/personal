#Requires -Version 5

### Recommended to run this in the Azure Cloud Shell of the target environment

[CmdletBinding(
    PositionalBinding = $false,
    DefaultParameterSetName = "SingleUser"
)]
param (
    # Must be one of the environments: BLD,DEV,DV2,TST,UAT,STG,PRD
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [ValidateSet("BLD","DEV","DV2","TST","UAT","STG","PRD")]
    [string]
    $Environment = "PRD",

    [Parameter(Mandatory = $true, ParameterSetName = "SingleUser")]
    [ValidateNotNullOrEmpty()]
    [string]
    $UserDisplayName,

    [Parameter(Mandatory = $true, ParameterSetName = "SingleUser")]
    [ValidateNotNullOrEmpty()]
    [string]
    $UserEmail,

    [Parameter(Mandatory = $true, ParameterSetName = "MultipleUsers")]
    [ValidateNotNullOrEmpty()]
    [ValidateCount(1,10)]
    [hashtable[]]
    $People,

    # Only for Telstra Purple administrators
    [switch]
    $GlobalAdmin
    )

Set-StrictMode -Version Latest
$ErrorActionPreference = [System.Management.Automation.ActionPreference]::Stop

$Environment = $Environment.ToUpper()

if ($PSCmdlet.ParameterSetName -eq "SingleUser") {
    $People = @(
        @{Name = $UserDisplayName; Email = $UserEmail}
    )
}
<#
} else {
    $People = @(
        #@{Name = "Barry Ingram"; Email = "bingram@redcrossblood.org.au"}
        #@{Name = "Raheel Alikhan"; Email = "ralikhan@redcrossblood.org.au"}
        #@{Name = "Robbie Vidler"; Email = "rvidler@redcrossblood.org.au"}
    )
}
#>

$EmailAddress = New-Object -TypeName Microsoft.Open.MSGraph.Model.EmailAddress
$EmailAddress.Name = "B2C Admin Notices - ARCL Squad"
$EmailAddress.Address = "c3ebf37b.purple.telstra.com@au.teams.ms"

$CCRecipient = New-Object -TypeName Microsoft.Open.MSGraph.Model.Recipient
$CCRecipient.EmailAddress = $EmailAddress

$MessageInfo = New-Object -TypeName Microsoft.Open.MSGraph.Model.InvitedUserMessageInfo
$MessageInfo.CustomizedMessageBody = "Hello. You are invited to manage ARCL B2C $Environment environment."
$MessageInfo.CcRecipients = $CCRecipient
$MessageInfo.MessageLanguage = "en-AU"

Connect-AzureAD
$AADTenant = Get-AzureADTenantDetail
$AADTenantDomain = $AADTenant.VerifiedDomains | Where-Object -Property Initial -eq -Value $true | Select-Object -ExpandProperty Name
$AADTenantURL = "https://portal.azure.com/$($AADTenantDomain)"

if ($GlobalAdmin) {
    # Global Admins (Telstra Purple)
    $AADGroups = Get-AzureADGroup -Filter "DisplayName eq 'Azure AD B2C Log Retention ($Environment)'"
    $AADRoles = Get-AzureADDirectoryRole | Where-Object -Property DisplayName -eq -Value "Company Administrator"
} else {
    # Global Readers (ARCL Support Teams)
    $AADGroups = Get-AzureADGroup -Filter "DisplayName eq 'ARCL B2C Support'"
    $AADRoles = Get-AzureADDirectoryRole | Where-Object -FilterScript {$PSItem.DisplayName -eq "Global Reader" -or $PSItem.DisplayName -eq "Service Support Administrator"}
}

foreach ($Person in $People) {
    $Person["InviteResult"] = New-AzureADMSInvitation -InvitedUserEmailAddress $Person.Email -InvitedUserDisplayName $Person.Name -InviteRedirectUrl $AADTenantURL -InvitedUserMessageInfo $MessageInfo -SendInvitationMessage $true -Verbose

    foreach ($AADGroup in $AADGroups) {
        Add-AzureADGroupMember -ObjectId $AADGroup.ObjectId -RefObjectId $Person["InviteResult"].InvitedUser.Id
    }
    foreach ($AADRole in $AADRoles) {
        Add-AzureADDirectoryRoleMember -ObjectId $AADRole.ObjectId -RefObjectId $Person["InviteResult"].InvitedUser.Id
    }
}

Get-AzureADUser -Filter "UserType eq 'Guest'" | Format-Table -Property DisplayName,UserPrincipalName,UserType,UserState,ObjectID
