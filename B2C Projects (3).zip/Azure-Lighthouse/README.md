# Azure Delegated Resource Management

This template enables your customer to project their subscription into your Managed Service Provider tenant

*NOTE*: You must modify the parameter file to reflect your environment before deploying

```powershell
$Environment = "BLD"
New-AzDeployment -Location australiasoutheast -TemplateParameterFile "delegatedResourceManagement.parameters.${Environment}.json" -TemplateFile "delegatedResourceManagement.json" -Verbose

New-AzDeployment -Location australiasoutheast -TemplateParameterFile "azureDevOps.parameters.${Environment}.json" -TemplateFile "azureDevOps.json" -Verbose
```
