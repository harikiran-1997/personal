param(
    [Parameter(Mandatory = $true)][string]$applicationId,
    [Parameter(Mandatory = $true)][string]$secret,
    [Parameter(Mandatory = $true)][string]$tenant,
    [Parameter(Mandatory = $true)][string]$SpokeSubscriptionId,
    [Parameter(Mandatory = $true)][string]$aksResourcegroupName,
    [Parameter(Mandatory = $true)][string]$aksClusterName,
    [Parameter(Mandatory = $true)][string]$privateDnsZoneResourceGroup,
    [Parameter(Mandatory = $true)][string]$privateDnsZoneName
)

az login --service-principal -u $applicationid -p $secret --tenant $tenant
az account set --subscription $SpokeSubscriptionId

# Enable HTTP application routing
az aks enable-addons --addons web_application_routing --name $aksClusterName --resource-group $aksResourcegroupName
Write-Output "HTTP application routing is enabled."

# Get the Azure Private DNS zone ID
$zoneId = az network private-dns zone show --resource-group $privateDnsZoneResourceGroup --name $privateDnsZoneName --query "id" --output tsv
az aks approuting zone add --ids $zoneId --name $aksClusterName --resource-group $aksResourcegroupName --attach-zones
Write-Output "Private DNS zone attached to AKS application routing successfully."