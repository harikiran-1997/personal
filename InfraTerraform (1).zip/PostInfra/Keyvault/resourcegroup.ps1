param(
    [Parameter(Mandatory = $true)][string]$applicationId,
    [Parameter(Mandatory = $true)][string]$secret,
    [Parameter(Mandatory = $true)][string]$tenant,
    [Parameter(Mandatory = $true)][string]$spokeSubscriptionId,
    [Parameter(Mandatory = $true)][string]$resourcegroupname,
    [Parameter(Mandatory = $true)][string]$location,
    [Parameter(Mandatory = $true)][string]$tags
)

$securesecret = $Secret | ConvertTo-SecureString -AsPlainText -Force
$cred = New-Object -TypeName PSCredential -ArgumentList $applicationId, $securesecret
Clear-AzContext -Force
Connect-AzAccount -ServicePrincipal -Credential $cred -Tenant $tenant

Set-AzContext -SubscriptionId $spokeSubscriptionId | out-Null
$rgexists = Get-AzResourceGroup -Name $resourcegroupname -ErrorAction SilentlyContinue
if ($rgexists){
    echo "***************resourcegroup exists ********************"
}
else{
   New-AzResourceGroup -Name $resourcegroupname -Location $location -Tag $tags
}
