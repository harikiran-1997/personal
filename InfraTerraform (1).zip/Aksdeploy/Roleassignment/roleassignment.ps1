param(
    [Parameter(Mandatory = $true)][string]$applicationId,
    [Parameter(Mandatory = $true)][string]$secret,
    [Parameter(Mandatory = $true)][string]$tenant,
    [Parameter(Mandatory = $true)][string]$devsubscriptionid,
    [Parameter(Mandatory = $true)][string]$devsubscriptioname,
    [Parameter(Mandatory = $true)][string]$devaksrgname,
    [Parameter(Mandatory = $true)][string]$devaksclustername,
    [Parameter(Mandatory = $true)][string]$devappcfgrgname,
    [Parameter(Mandatory = $true)][string]$devappcfgname,
    [Parameter(Mandatory = $true)][string]$devappcfgkvname,
    [Parameter(Mandatory = $true)][string]$devacrrgname,
    [Parameter(Mandatory = $true)][string]$devacrname,
    [Parameter(Mandatory = $true)][string]$uatsubscriptionid,
    [Parameter(Mandatory = $true)][string]$uatsubscriptioname,
    [Parameter(Mandatory = $true)][string]$uataksrgname,
    [Parameter(Mandatory = $true)][string]$uataksclustername,
    [Parameter(Mandatory = $true)][string]$uatappcfgrgname,
    [Parameter(Mandatory = $true)][string]$uatappcfgname,
    [Parameter(Mandatory = $true)][string]$uatappcfgkvname,
    [Parameter(Mandatory = $true)][string]$uatacrrgname,
    [Parameter(Mandatory = $true)][string]$uatacrname,
    [Parameter(Mandatory = $true)][string]$prdsubscriptionid,
    [Parameter(Mandatory = $true)][string]$prdsubscriptioname,
    [Parameter(Mandatory = $true)][string]$prdaksrgname,
    [Parameter(Mandatory = $true)][string]$prdaksclustername,
    [Parameter(Mandatory = $true)][string]$prdappcfgrgname,
    [Parameter(Mandatory = $true)][string]$prdappcfgname,
    [Parameter(Mandatory = $true)][string]$prdappcfgkvname,
    [Parameter(Mandatory = $true)][string]$prdacrrgname,
    [Parameter(Mandatory = $true)][string]$prdacrname

)


function Assign-GroupsToDevResources {
    param (
        [Parameter(Mandatory = $true)]
        [string]$applicationId,
        [string]$secret,
        [string]$tenant,
        [string]$SubscriptionId,
        [string]$SubscriptionName,
        [string]$aksResourceGroup,
        [string]$aksClusterName,
        [string]$appcfgResourceGroup,
        [string]$appcfgname,
        [string]$appcfgkvname,
        [string]$acrresourceGroupName,
        [string]$registryName
    )
    $securesecret = $secret | ConvertTo-SecureString -AsPlainText -Force
    $cred = New-Object -TypeName PSCredential -ArgumentList $applicationId, $securesecret
    Clear-AzContext -Force
    Connect-AzAccount -ServicePrincipal -Credential $cred -Tenant $tenant
    Set-AzContext -SubscriptionId $SubscriptionId
    # Define the mapping of Azure AD groups to role definitions, scopes, and resources
    $groupRoleMapping = @{
        "AZSG_RES_$SubscriptionName_DEV_AKS_RBACClusterAdmins" = @{
            RoleDefinition = "Azure Kubernetes Service RBAC Cluster Admin"
            Scope          = "/subscriptions/$SubscriptionId/resourcegroups/$aksResourceGroup/providers/Microsoft.ContainerService/managedClusters/$aksClusterName"

        }
        "AZSG_RES_$SubscriptionName_DEV_AKS_ServiceClusterAdmins" = @{
            RoleDefinition = "Azure Kubernetes Service Cluster Admin Role"
            Scope          = "/subscriptions/$SubscriptionId/resourcegroups/$aksResourceGroup/providers/Microsoft.ContainerService/managedClusters/$aksClusterName"
        }
        "AZSG_RES_$SubscriptionName_DEV_AKS_LogAnalyticsReader" = @{
            RoleDefinition = "Log Analytics Reader"
            Scope          = "/subscriptions/$SubscriptionId/resourcegroups/$aksResourceGroup/providers/Microsoft.ContainerService/managedClusters/$aksClusterName"
        }
        "AZSG_RES_$SubscriptionName_DEV_AKS_ServiceClusterMonitoring" = @{
            RoleDefinition = "Azure Kubernetes Service Cluster Monitoring User"
            Scope          = "/subscriptions/$SubscriptionId/resourcegroups/$aksResourceGroup/providers/Microsoft.ContainerService/managedClusters/$aksClusterName"
        }
        "AZSG_RES_$SubscriptionName_DEV_AKS_RBACWriter" = @{
            RoleDefinition = "Azure Kubernetes Service RBAC Writer"
            Scope          = "/subscriptions/$SubscriptionId/resourcegroups/$aksResourceGroup/providers/Microsoft.ContainerService/managedClusters/$aksClusterName"
        }
        "AZSG_RES_$SubscriptionName_DEV_AKS_ServiceContributor" = @{
            RoleDefinition = "Azure Kubernetes Service Contributor Role"
            Scope          = "/subscriptions/$SubscriptionId/resourcegroups/$aksResourceGroup/providers/Microsoft.ContainerService/managedClusters/$aksClusterName"
        }
        "AZSG_RES_$SubscriptionName_DEV_AKS_RBACReader" = @{
            RoleDefinition = "Azure Kubernetes Service RBAC Reader"
            Scope          = "/subscriptions/$SubscriptionId/resourcegroups/$aksResourceGroup/providers/Microsoft.ContainerService/managedClusters/$aksClusterName"
        }
        "AZSG_RES_$SubscriptionName_DEV_AKS_ServiceClusterUser" = @{
            RoleDefinition = "Azure Kubernetes Service Cluster User Role"
            Scope          = "/subscriptions/$SubscriptionId/resourcegroups/$aksResourceGroup/providers/Microsoft.ContainerService/managedClusters/$aksClusterName"
        }
        "AZSG_RES_$SubscriptionName_DEV_AppConfig_DataOwner" = @{
            RoleDefinition = "App Configuration Data Owner"
            Scope          = "/subscriptions/$SubscriptionId/resourceGroups/$appcfgResourceGroup/providers/Microsoft.AppConfiguration/configurationStores/$appcfgname"
        }
        "AZSG_RES_$SubscriptionName_DEV_AppConfig_Contributors" = @{
            RoleDefinition = "Managed Application Contributor Role"
            Scope          = "/subscriptions/$SubscriptionId/resourceGroups/$appcfgResourceGroup/providers/Microsoft.AppConfiguration/configurationStores/$appcfgname"
        }

        "AZSG_RES_$SubscriptionName_DEV_KeyVault_Contribitors" = @{
            RoleDefinition = "Key Vault Contributor"
            Scope          = "/subscriptions/$SubscriptionId/resourceGroups/$appcfgResourceGroup/providers/Microsoft.KeyVault/vaults/$appcfgkvname"
        }
        "AZSG_RES_$SubscriptionName_DEV_KeyVault_SecretsOfficer" = @{
            RoleDefinition = "Key Vault Secrets Officer"
            Scope          = "/subscriptions/$SubscriptionId/resourceGroups/$appcfgResourceGroup/providers/Microsoft.KeyVault/vaults/$appcfgkvname"
        }
        "AZSG_RES_$SubscriptionName_DEV_KeyVault_Readers" = @{
            RoleDefinition = "Key Vault Reader"
            Scope          = "/subscriptions/$SubscriptionId/resourceGroups/$appcfgResourceGroup/providers/Microsoft.KeyVault/vaults/$appcfgkvname"
        }
        "AZSG_RES_$SubscriptionName_DEV_KeyVaultSecretsUsers" = @{
            RoleDefinition = "Key Vault Secrets User"
            Scope          = "/subscriptions/$SubscriptionId/resourceGroups/$appcfgResourceGroup/providers/Microsoft.KeyVault/vaults/$appcfgkvname"
        }
        "AZSG_RES_$SubscriptionName_DEV_ACR_Delete" = @{
            RoleDefinition = "AcrDelete"
            Scope          = "/subscriptions/$SubscriptionId/resourceGroups/$acrresourceGroupName/providers/Microsoft.ContainerRegistry/registries/$registryName"
        }
        "AZSG_RES_$SubscriptionName_DEV_ACR_Pull" = @{
            RoleDefinition = "AcrPull"
            Scope          = "/subscriptions/$SubscriptionId/resourceGroups/$acrresourceGroupName/providers/Microsoft.ContainerRegistry/registries/$registryName"
        }
        "AZSG_RES_$SubscriptionName_DEV_ACR_Push" = @{
            RoleDefinition = "AcrPush"
            Scope          = "/subscriptions/$SubscriptionId/resourceGroups/$acrresourceGroupName/providers/Microsoft.ContainerRegistry/registries/$registryName"
        }

    }

    try {
        # Get Azure AD groups matching the specified subscription name
        $groups = Get-AzADGroup | Where-Object { $_.DisplayName -like "*$SubscriptionName*" }

        # Check if any groups were found
        if ($groups) {
            # Loop through each Azure AD group and assign it to the respective resource with the specified role and scope
            foreach ($group in $groups) {
                $groupName = $group
                if ($groupRoleMapping.ContainsKey($groupName)) {
                    $groupMapping = $groupRoleMapping[$groupName]
                    $roleDefinition = $groupMapping.RoleDefinition
                    $scope = $groupMapping.Scope
                    $resourceName = $groupMapping.Resource
                    New-AzRoleAssignment -ObjectId $group.Id `
                                         -RoleDefinitionName $roleDefinition `
                                         -Scope $scope `
                                         -RoleAssignmentName "${groupName}_$roleDefinition"
                } else {
                    Write-Warning "No role mapping found for Azure AD group '$groupName'. Skipping assignment."
                }
            }
        } else {
            Write-Warning "No Azure AD groups matching '$SubscriptionName' were found."
        }
    } catch {
        Write-Error "Error occurred: $_"
    }
}

function Assign-GroupsToUatResources {
    param (
        [Parameter(Mandatory = $true)]
        [string]$applicationId,
        [string]$secret,
        [string]$tenant,
        [string]$SubscriptionId,
        [string]$SubscriptionName,
        [string]$aksResourceGroup,
        [string]$aksClusterName,
        [string]$appcfgResourceGroup,
        [string]$appcfgname,
        [string]$appcfgkvname,
        [string]$acrresourceGroupName,
        [string]$registryName
    )
    $securesecret = $secret | ConvertTo-SecureString -AsPlainText -Force
    $cred = New-Object -TypeName PSCredential -ArgumentList $applicationId, $securesecret
    Clear-AzContext -Force
    Connect-AzAccount -ServicePrincipal -Credential $cred -Tenant $tenant
    Set-AzContext -SubscriptionId $SubscriptionId

    # Define the mapping of Azure AD groups to role definitions, scopes, and resources
    $groupRoleMapping = @{
        "AZSG_RES_$SubscriptionName_UAT_AKS_RBACClusterAdmins" = @{
            RoleDefinition = "Azure Kubernetes Service RBAC Cluster Admin"
            Scope          = "/subscriptions/$SubscriptionId/resourcegroups/$aksResourceGroup/providers/Microsoft.ContainerService/managedClusters/$aksClusterName"

        }
        "AZSG_RES_$SubscriptionName_UAT_AKS_ServiceClusterAdmins" = @{
            RoleDefinition = "Azure Kubernetes Service Cluster Admin Role"
            Scope          = "/subscriptions/$SubscriptionId/resourcegroups/$aksResourceGroup/providers/Microsoft.ContainerService/managedClusters/$aksClusterName"
        }
        "AZSG_RES_$SubscriptionName_UAT_AKS_LogAnalyticsReader" = @{
            RoleDefinition = "Log Analytics Reader"
            Scope          = "/subscriptions/$SubscriptionId/resourcegroups/$aksResourceGroup/providers/Microsoft.ContainerService/managedClusters/$aksClusterName"
        }
        "AZSG_RES_$SubscriptionName_UAT_AKS_ServiceClusterMonitoring" = @{
            RoleDefinition = "Azure Kubernetes Service Cluster Monitoring User"
            Scope          = "/subscriptions/$SubscriptionId/resourcegroups/$aksResourceGroup/providers/Microsoft.ContainerService/managedClusters/$aksClusterName"
        }
        "AZSG_RES_$SubscriptionName_UAT_AKS_RBACWriter" = @{
            RoleDefinition = "Azure Kubernetes Service RBAC Writer"
            Scope          = "/subscriptions/$SubscriptionId/resourcegroups/$aksResourceGroup/providers/Microsoft.ContainerService/managedClusters/$aksClusterName"
        }
        "AZSG_RES_$SubscriptionName_UAT_AKS_ServiceContributor" = @{
            RoleDefinition = "Azure Kubernetes Service Contributor Role"
            Scope          = "/subscriptions/$SubscriptionId/resourcegroups/$aksResourceGroup/providers/Microsoft.ContainerService/managedClusters/$aksClusterName"
        }
        "AZSG_RES_$SubscriptionName_UAT_AKS_RBACReader" = @{
            RoleDefinition = "Azure Kubernetes Service RBAC Reader"
            Scope          = "/subscriptions/$SubscriptionId/resourcegroups/$aksResourceGroup/providers/Microsoft.ContainerService/managedClusters/$aksClusterName"
        }
        "AZSG_RES_$SubscriptionName_UAT_AKS_ServiceClusterUser" = @{
            RoleDefinition = "Azure Kubernetes Service Cluster User Role"
            Scope          = "/subscriptions/$SubscriptionId/resourcegroups/$aksResourceGroup/providers/Microsoft.ContainerService/managedClusters/$aksClusterName"
        }
        "AZSG_RES_$SubscriptionName_UAT_AppConfig_DataOwner" = @{
            RoleDefinition = "App Configuration Data Owner"
            Scope          = "/subscriptions/$SubscriptionId/resourceGroups/$appcfgResourceGroup/providers/Microsoft.AppConfiguration/configurationStores/$appcfgname"
        }
        "AZSG_RES_$SubscriptionName_UAT_AppConfig_Contributors" = @{
            RoleDefinition = "Managed Application Contributor Role"
            Scope          = "/subscriptions/$SubscriptionId/resourceGroups/$appcfgResourceGroup/providers/Microsoft.AppConfiguration/configurationStores/$appcfgname"
        }

        "AZSG_RES_$SubscriptionName_UAT_KeyVault_Contribitors" = @{
            RoleDefinition = "Key Vault Contributor"
            Scope          = "/subscriptions/$SubscriptionId/resourceGroups/$appcfgResourceGroup/providers/Microsoft.KeyVault/vaults/$appcfgkvname"
        }
        "AZSG_RES_$SubscriptionName_UAT_KeyVault_SecretsOfficer" = @{
            RoleDefinition = "Key Vault Secrets Officer"
            Scope          = "/subscriptions/$SubscriptionId/resourceGroups/$appcfgResourceGroup/providers/Microsoft.KeyVault/vaults/$appcfgkvname"
        }
        "AZSG_RES_$SubscriptionName_UAT_KeyVault_Readers" = @{
            RoleDefinition = "Key Vault Reader"
            Scope          = "/subscriptions/$SubscriptionId/resourceGroups/$appcfgResourceGroup/providers/Microsoft.KeyVault/vaults/$appcfgkvname"
        }
        "AZSG_RES_$SubscriptionName_UAT_KeyVaultSecretsUsers" = @{
            RoleDefinition = "Key Vault Secrets User"
            Scope          = "/subscriptions/$SubscriptionId/resourceGroups/$appcfgResourceGroup/providers/Microsoft.KeyVault/vaults/$appcfgkvname"
        }
        "AZSG_RES_$SubscriptionName_UAT_ACR_Delete" = @{
            RoleDefinition = "AcrDelete"
            Scope          = "/subscriptions/$SubscriptionId/resourceGroups/$acrresourceGroupName/providers/Microsoft.ContainerRegistry/registries/$registryName"
        }
        "AZSG_RES_$SubscriptionName_UAT_ACR_Pull" = @{
            RoleDefinition = "AcrPull"
            Scope          = "/subscriptions/$SubscriptionId/resourceGroups/$acrresourceGroupName/providers/Microsoft.ContainerRegistry/registries/$registryName"
        }
        "AZSG_RES_$SubscriptionName_UAT_ACR_Push" = @{
            RoleDefinition = "AcrPush"
            Scope          = "/subscriptions/$SubscriptionId/resourceGroups/$acrresourceGroupName/providers/Microsoft.ContainerRegistry/registries/$registryName"
        }

    }

    try {
        # Get Azure AD groups matching the specified subscription name
        $groups = Get-AzADGroup | Where-Object { $_.DisplayName -like "*$SubscriptionName*" }

        # Check if any groups were found
        if ($groups) {
            # Loop through each Azure AD group and assign it to the respective resource with the specified role and scope
            foreach ($group in $groups) {
                $groupName = $group
                if ($groupRoleMapping.ContainsKey($groupName)) {
                    $groupMapping = $groupRoleMapping[$groupName]
                    $roleDefinition = $groupMapping.RoleDefinition
                    $scope = $groupMapping.Scope
                    $resourceName = $groupMapping.Resource
                    New-AzRoleAssignment -ObjectId $group.Id `
                                         -RoleDefinitionName $roleDefinition `
                                         -Scope $scope `
                                         -RoleAssignmentName "${groupName}_$roleDefinition"
                } else {
                    Write-Warning "No role mapping found for Azure AD group '$groupName'. Skipping assignment."
                }
            }
        } else {
            Write-Warning "No Azure AD groups matching '$SubscriptionName' were found."
        }
    } catch {
        Write-Error "Error occurred: $_"
    }
}

function Assign-GroupsToProdResources {
    param (
        [Parameter(Mandatory = $true)]
        [string]$applicationId,
        [string]$secret,
        [string]$tenant,
        [string]$SubscriptionId,
        [string]$SubscriptionName,
        [string]$aksResourceGroup,
        [string]$aksClusterName,
        [string]$appcfgResourceGroup,
        [string]$appcfgname,
        [string]$appcfgkvname,
        [string]$acrresourceGroupName,
        [string]$registryName
    )

    $securesecret = $secret | ConvertTo-SecureString -AsPlainText -Force
    $cred = New-Object -TypeName PSCredential -ArgumentList $applicationId, $securesecret
    Clear-AzContext -Force
    Connect-AzAccount -ServicePrincipal -Credential $cred -Tenant $tenant
    Set-AzContext -SubscriptionId $SubscriptionId

    $groupRoleMapping = @{
        "AZSG_RES_$SubscriptionName_PROD_AKS_RBACClusterAdmins" = @{
            RoleDefinition = "Azure Kubernetes Service RBAC Cluster Admin"
            Scope          = "/subscriptions/$SubscriptionId/resourcegroups/$aksResourceGroup/providers/Microsoft.ContainerService/managedClusters/$aksClusterName"

        }
        "AZSG_RES_$SubscriptionName_PROD_AKS_ServiceClusterAdmins" = @{
            RoleDefinition = "Azure Kubernetes Service Cluster Admin Role"
            Scope          = "/subscriptions/$SubscriptionId/resourcegroups/$aksResourceGroup/providers/Microsoft.ContainerService/managedClusters/$aksClusterName"
        }
        "AZSG_RES_$SubscriptionName_PROD_AKS_LogAnalyticsReader" = @{
            RoleDefinition = "Log Analytics Reader"
            Scope          = "/subscriptions/$SubscriptionId/resourcegroups/$aksResourceGroup/providers/Microsoft.ContainerService/managedClusters/$aksClusterName"
        }
        "AZSG_RES_$SubscriptionName_PROD_AKS_ServiceClusterMonitoring" = @{
            RoleDefinition = "Azure Kubernetes Service Cluster Monitoring User"
            Scope          = "/subscriptions/$SubscriptionId/resourcegroups/$aksResourceGroup/providers/Microsoft.ContainerService/managedClusters/$aksClusterName"
        }
        "AZSG_RES_$SubscriptionName_PROD_AKS_RBACWriter" = @{
            RoleDefinition = "Azure Kubernetes Service RBAC Writer"
            Scope          = "/subscriptions/$SubscriptionId/resourcegroups/$aksResourceGroup/providers/Microsoft.ContainerService/managedClusters/$aksClusterName"
        }
        "AZSG_RES_$SubscriptionName_PROD_AKS_ServiceContributor" = @{
            RoleDefinition = "Azure Kubernetes Service Contributor Role"
            Scope          = "/subscriptions/$SubscriptionId/resourcegroups/$aksResourceGroup/providers/Microsoft.ContainerService/managedClusters/$aksClusterName"
        }
        "AZSG_RES_$SubscriptionName_PROD_AKS_RBACReader" = @{
            RoleDefinition = "Azure Kubernetes Service RBAC Reader"
            Scope          = "/subscriptions/$SubscriptionId/resourcegroups/$aksResourceGroup/providers/Microsoft.ContainerService/managedClusters/$aksClusterName"
        }
        "AZSG_RES_$SubscriptionName_PROD_AKS_ServiceClusterUser" = @{
            RoleDefinition = "Azure Kubernetes Service Cluster User Role"
            Scope          = "/subscriptions/$SubscriptionId/resourcegroups/$aksResourceGroup/providers/Microsoft.ContainerService/managedClusters/$aksClusterName"
        }
        "AZSG_RES_$SubscriptionName_PROD_AppConfig_DataOwner" = @{
            RoleDefinition = "App Configuration Data Owner"
            Scope          = "/subscriptions/$SubscriptionId/resourceGroups/$appcfgResourceGroup/providers/Microsoft.AppConfiguration/configurationStores/$appcfgname"
        }
        "AZSG_RES_$SubscriptionName_PROD_AppConfig_Contributors" = @{
            RoleDefinition = "Managed Application Contributor Role"
            Scope          = "/subscriptions/$SubscriptionId/resourceGroups/$appcfgResourceGroup/providers/Microsoft.AppConfiguration/configurationStores/$appcfgname"
        }

        "AZSG_RES_$SubscriptionName_PROD_KeyVault_Contribitors" = @{
            RoleDefinition = "Key Vault Contributor"
            Scope          = "/subscriptions/$SubscriptionId/resourceGroups/$appcfgResourceGroup/providers/Microsoft.KeyVault/vaults/$appcfgkvname"
        }
        "AZSG_RES_$SubscriptionName_PROD_KeyVault_SecretsOfficer" = @{
            RoleDefinition = "Key Vault Secrets Officer"
            Scope          = "/subscriptions/$SubscriptionId/resourceGroups/$appcfgResourceGroup/providers/Microsoft.KeyVault/vaults/$appcfgkvname"
        }
        "AZSG_RES_$SubscriptionName_PROD_KeyVault_Readers" = @{
            RoleDefinition = "Key Vault Reader"
            Scope          = "/subscriptions/$SubscriptionId/resourceGroups/$appcfgResourceGroup/providers/Microsoft.KeyVault/vaults/$appcfgkvname"
        }
        "AZSG_RES_$SubscriptionName_PROD_KeyVaultSecretsUsers" = @{
            RoleDefinition = "Key Vault Secrets User"
            Scope          = "/subscriptions/$SubscriptionId/resourceGroups/$appcfgResourceGroup/providers/Microsoft.KeyVault/vaults/$appcfgkvname"
        }
        "AZSG_RES_$SubscriptionName_PROD_ACR_Delete" = @{
            RoleDefinition = "AcrDelete"
            Scope          = "/subscriptions/$SubscriptionId/resourceGroups/$acrresourceGroupName/providers/Microsoft.ContainerRegistry/registries/$registryName"
        }
        "AZSG_RES_$SubscriptionName_PROD_ACR_Pull" = @{
            RoleDefinition = "AcrPull"
            Scope          = "/subscriptions/$SubscriptionId/resourceGroups/$acrresourceGroupName/providers/Microsoft.ContainerRegistry/registries/$registryName"
        }
        "AZSG_RES_$SubscriptionName_PROD_ACR_Push" = @{
            RoleDefinition = "AcrPush"
            Scope          = "/subscriptions/$SubscriptionId/resourceGroups/$acrresourceGroupName/providers/Microsoft.ContainerRegistry/registries/$registryName"
        }

    }

    try {
        # Get Azure AD groups matching the specified subscription name
        $groups = Get-AzADGroup | Where-Object { $_.DisplayName -like "*$SubscriptionName*" }

        # Check if any groups were found
        if ($groups) {
            # Loop through each Azure AD group and assign it to the respective resource with the specified role and scope
            foreach ($group in $groups) {
                $groupName = $group
                if ($groupRoleMapping.ContainsKey($groupName)) {
                    $groupMapping = $groupRoleMapping[$groupName]
                    $roleDefinition = $groupMapping.RoleDefinition
                    $scope = $groupMapping.Scope
                    $resourceName = $groupMapping.Resource
                    New-AzRoleAssignment -ObjectId $group.Id `
                                         -RoleDefinitionName $roleDefinition `
                                         -Scope $scope `
                                         -RoleAssignmentName "${groupName}_$roleDefinition"
                } else {
                    Write-Warning "No role mapping found for Azure AD group '$groupName'. Skipping assignment."
                }
            }
        } else {
            Write-Warning "No Azure AD groups matching '$SubscriptionName' were found."
        }
    } catch {
        Write-Error "Error occurred: $_"
    }
}

Assign-GroupsToDevResources -applicationId $applicationId -secret $secret -tenant $tenant -SubscriptionId $devsubscriptionid -SubscriptionName $devsubscriptioname -aksResourceGroup $devaksrgname -aksClusterName $devaksclustername -appcfgResourceGroup $devappcfgrgname -appcfgname $devappcfgname -appcfgkvname $devappcfgkvname -acrresourceGroupName $devacrrgname -registryName $devacrname

Assign-GroupsToUatResources -applicationId $applicationId -secret $secret -tenant $tenant -SubscriptionId $uatsubscriptionid -SubscriptionName $uatsubscriptioname -aksResourceGroup $uataksrgname -aksClusterName $uataksclustername -appcfgResourceGroup $uatappcfgrgname -appcfgname $uatappcfgname -appcfgkvname $uatappcfgkvname -acrresourceGroupName $uatacrrgname -registryName $uatacrname

Assign-GroupsToUatResources -applicationId $applicationId -secret $secret -tenant $tenant -SubscriptionId $prdsubscriptionid -SubscriptionName $prdsubscriptioname -aksResourceGroup $prdaksrgname -aksClusterName $prdaksclustername -appcfgResourceGroup $prdappcfgrgname -appcfgname $prdappcfgname -appcfgkvname $prdappcfgkvname -acrresourceGroupName $prdacrrgname -registryName $prdacrname
