# Hudson Bay Terraform Code for "dev-aks-cluster203" Kubernetes Cluster Support tool. 
## This repository folder **terraform203support** holds the IaC for kubernetes cluster "dev-aks-cluster203" support tools placed under DevOps subscription.

### Terraform files list in the current folder holds the kubernetes cluster support tools.

Support tools are tools that are installed in the kubernetes cluster to help the moment of the application within kubernetes cluster.

1. [Locals](./0-locals.tf)
2. [Provider](./1-provider.tf)
3. [ArgoCD](./2-argocd.tf)
4. [ArgoCD Image Updater](./3-argo-imageupdater.tf)
5. [Nginx Ingress](./4-nginx-ingress.tf)
6. [Sealed Secrets](./5-sealed-secrets.tf)
7. [Prometheus](./6-prometheus.tf)
8. [Grafana](./7-grafana.tf)
9. [Backend](./backend.tf)
10. [Variables](./variables.tf)

## CRDs - Cert-Manager

CRDs are installed on the cluster manually for cert-manager to avoid fat fingering helm deployment that results in all certificates in the cluster being wiped out:
kubectl apply -f https://github.com/cert-manager/cert-manager/releases/download/v1.14.4/cert-manager.crds.yaml -n cert-manager

## Usage in Terraform

Please view each file for more details on the implementation.

## Authors

Module is maintained by **HBCM DevOps**

## Copyright

@Hudson Bay Capital