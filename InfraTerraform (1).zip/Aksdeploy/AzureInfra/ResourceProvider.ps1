param(
    [string]$ApplicationId,
    [string]$Secret,
    [string]$Tenant,
    [string]$spokeSubscriptionId
)

$securesecret = $Secret | ConvertTo-SecureString -AsPlainText -Force
$cred = New-Object -TypeName PSCredential -ArgumentList $ApplicationId, $securesecret
Clear-AzContext -Force
Connect-AzAccount -ServicePrincipal -Credential $cred -Tenant $Tenant

Set-AzContext -SubscriptionId $spokeSubscriptionId | out-Null

$containerregistry = Get-AzResourceProvider -ListAvailable | where ProviderNamespace -eq 'Microsoft.ContainerRegistry' -ErrorAction SilentlyContinue

if ($containerregistry.RegistrationState -eq "NotRegistered") {
    register-AzResourceProvider -ProviderNamespace 'Microsoft.ContainerRegistry'
    echo "***************registered Resource Provider ContainerRegistry ********************"
}
else{
    echo "***************ContainerRegistry Already registered********************"

}

$Postgressregister = Get-AzResourceProvider -ListAvailable | where ProviderNamespace -eq 'Microsoft.DBforPostgreSQL' -ErrorAction SilentlyContinue

if ($Postgressregister.RegistrationState -eq "NotRegistered") {
    register-AzResourceProvider -ProviderNamespace 'Microsoft.DBforPostgreSQL'
    echo "***************registered Resource Provider Postgres ********************"
}
else{
    echo "***************Postgres Already registered********************"

}

$AppCfgregister = Get-AzResourceProvider -ListAvailable | where ProviderNamespace -eq 'Microsoft.AppConfiguration' -ErrorAction SilentlyContinue

if ($AppCfgregister.RegistrationState -eq "NotRegistered") {
    register-AzResourceProvider -ProviderNamespace 'Microsoft.AppConfiguration'
    echo "***************registered Resource Provider AppConfiguration ********************"
}
else{
    echo "***************AppConfiguration Already registered********************"

}


$ContainerServicesregister = Get-AzResourceProvider -ListAvailable | where ProviderNamespace -eq 'Microsoft.ContainerService' -ErrorAction SilentlyContinue

if ($ContainerServicesregister.RegistrationState -eq "NotRegistered") {
    register-AzResourceProvider -ProviderNamespace 'Microsoft.ContainerService'
    echo "***************registered Resource Provider Microsoft.ContainerService ********************"
}
else{
    echo "***************Container Services Already registered********************"

}

$ManagedIdentityregister = Get-AzResourceProvider -ListAvailable | where ProviderNamespace -eq 'Microsoft.ManagedIdentity' -ErrorAction SilentlyContinue

if ($ManagedIdentityregister.RegistrationState -eq "NotRegistered") {
    register-AzResourceProvider -ProviderNamespace 'Microsoft.ManagedIdentity'
    echo "***************registered Resource Provider Microsoft.ManagedIdentity ********************"
}
else{
    echo "***************Microsoft.ManagedIdentity Already registered********************"

}