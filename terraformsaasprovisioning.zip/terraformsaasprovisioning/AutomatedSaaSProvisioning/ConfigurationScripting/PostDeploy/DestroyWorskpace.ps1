param(
    [Parameter(Mandatory=$true)][string]$accesstoken,
    [Parameter(Mandatory=$true)][string]$CustomerId,
    [Parameter(Mandatory=$true)][string]$Orgname,
    [Parameter(Mandatory=$true)][string]$VMname
)

$WorkspaceName = "dqa-ndc-$CustomerId-$VMname"

$Header = @{
    "authorization" = "Bearer $accesstoken"
 }

#Get Workspace 
$Parameters = @{
Method      = "GET"
Uri         = "https://app.terraform.io/api/v2/organizations/$Orgname/workspaces"
Headers     = $Header
ContentType = "application/vnd.api+json"
}
$job = Invoke-RestMethod @Parameters
$getworkspace = $job.data.attributes.name -eq $WorkspaceName

#remove workspace 
$Parameters = @{
Method      = "DELETE"
Uri         = "https://app.terraform.io/api/v2/organizations/$Orgname/workspaces/$getworkspace"
Headers     = $Header
ContentType = "application/vnd.api+json"
}
Invoke-RestMethod @Parameters