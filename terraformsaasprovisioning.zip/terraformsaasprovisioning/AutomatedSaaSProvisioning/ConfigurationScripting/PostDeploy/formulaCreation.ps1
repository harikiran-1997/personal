param(
    [Parameter(Mandatory=$true)][string]$ClientSPApplicationId,
    [Parameter(Mandatory=$true)][string]$ClientSPSecret,
    [Parameter(Mandatory=$true)][string]$ClientTenantID,
    [Parameter(Mandatory=$true)][string]$ClientSubscriptionID,
    [Parameter(Mandatory=$true)][string]$LabName,
    [Parameter(Mandatory=$true)][string]$sharedgalleryName,
    [Parameter(Mandatory=$true)][string]$DefinitionName,
    [Parameter(Mandatory=$true)][string]$ImageVersion,
    [Parameter(Mandatory=$true)][string]$domainusername,
    [Parameter(Mandatory=$true)][string]$domainsecret,
    [Parameter(Mandatory=$true)][string]$domainname
    )

Write-Host -Debug "secretvalue is: $domainsecret"
function createFormula {
    Write-Host "Formula creation started"
    $deploy = New-AzResourceGroupDeployment `
    -ResourceGroupName $RGName `
    -TemplateFile "ConfigurationScripting/PostDeploy/formuladeploy.json" `
    -labName $LabName `
    -formulaName $formulaName `
    -labVirtualNetworkName $labVirtualNetworkName `
    -labSubnetName $labSubnetName `
    -galleryName $sharedgalleryName `
    -imagedefname $DefinitionName `
    -version $ImageVersion `
    -Join_Active_Directory_domain_domainAdminUsername $domainusername `
    -Join_Active_Directory_domain_domainAdminPassword $domainsecret `
    -Join_Active_Directory_domain_domainToJoin $domainname 
    $deploy
}
$RGName = "rg-odw-ndc-rg"
$labVirtualNetworkName = "vn-ODW-NDC-VNET"
$labSubnetName = "ODW-NDC-SUBNET"
$formulaName = $DefinitionName -replace ("\.","")
$formulaName

$securesecret = $ClientSPSecret | ConvertTo-SecureString -AsPlainText -Force

$cred = New-Object -TypeName PSCredential -ArgumentList $ClientSPApplicationId, $securesecret

Clear-AzContext -Force
Connect-AzAccount -ServicePrincipal -Credential $cred -Tenant $ClientTenantID
Set-AzContext -SubscriptionId $ClientSubscriptionID

$ErrorActionPreference = 'SilentlyContinue'
$Getformula = (Get-AzResource -ResourceId "/subscriptions/$ClientSubscriptionID/resourcegroups/$RGName/providers/microsoft.devtestlab/labs/$LabName/formulas/$formulaName").Name

$flag = $true
if($Getformula){
    Write-Verbose -Message "formula already exists" -Verbose
}
else{
  while($flag){
    createFormula

    if((Get-AzResourceGroupDeployment -Name "formuladeploy" -ResourceGroupName $RGName).ProvisioningState -eq 'Failed'){
      $Formuladeployment = ((Get-AzResourceGroupDeploymentoperation -ResourceGroupName $RGName -DeploymentName "formuladeploy").TargetResource) -match 'formulas'
      $Formuladeployment.GetType()
      Remove-AzResource -ResourceId $Formuladeployment[0] -Force
      
    }else {
      $flag = $false
    }
  }
}
