param(
    [Parameter(Mandatory=$true)][string]$domainname,
    [Parameter(Mandatory=$true)][string]$CustomerID,
    [Parameter(Mandatory=$true)][string]$accesstoken,
    [Parameter(Mandatory=$true)][string]$RepoPAT,
    [Parameter(Mandatory=$true)][string]$RepoURL,
    [Parameter(Mandatory=$true)][string]$envname
)


$workspaceName = @("WS-$CustomerID-FC","WS-$CustomerID-DQA-DC","WS-$CustomerID-DQA-NDC-$envname","WS-$CustomerID-DQA-DC-$envname")
$organizationName = "DCTEnterprise"
$add = @()
foreach($workspace in $workspaceName){

    $ErrorActionPreference = "Stop"

    $baseUri = "https://app.terraform.io/"
    $authHeader = @{ Authorization = "Bearer $accesstoken" }
    $contentType = "application/vnd.api+json; charset=utf-8"

    Write-Host "Getting state information for $organizationName - $workspace"

    $workspaceResp = Invoke-RestMethod -Uri "$baseUri/api/v2/organizations/$organizationName/workspaces/$workspace" -Headers $authHeader -ContentType $contentType
    $currentStateVersionLink = $workspaceResp.data.relationships.'current-state-version'.links.related

    Write-Host "Current state link: $currentStateVersionLink"

    $uri = $baseUri + $currentStateVersionLink + "?include=outputs"
    $outputResp = Invoke-RestMethod -Uri $uri -Headers $authHeader -ContentType $contentType
    Write-Host -Verbose "outputresponce $outputResp"
    $outputvalue = $outputResp.included.attributes.value
    $add += $outputvalue
}


$apppoolpassword = $add[0].apppoolvalue
$apppoolusername = $add[0].apppoolusername -split "@$domainname"
$dbpassword = $add[0].dbvalue
$dctpassword = $add[0].dctvalue
$dqmailpassword = $add[0].dqmailvalue
$dbusername = $add[0].dbusername
$dctusername = $add[0].dctusername
$azsearchkey = $add[1]
$azsearchuri = $add[2]
$storagekey = $add[3]
$storagename = $add[4]
$appvmname = $add[5]
$connectionstring = $add[6].TrimStart("Endpoint= ")
$dbvmname = $add[7]
$dbinsightsvm = $add[8]

$Body = @{

          IIS = @{
            AppPoolUser = "DWS$CustomerID\$apppoolusername";
            AppPoolPassword = "$apppoolpassword"
          };
          dbUser = @{
            Name= "$dbusername";
            Password= "$dbpassword"
          };
          DCTUser= @{
            Name= "$dctusername";
            Password = "$dctpassword"
          };
          ADServerFQDN = "OU=TestClient1_App_Servers,DC=DWS$CustomerID,DC=onmincrosoft,DC=com";
          FileStorage = @{
            AccountName = "$storagename";
            AccountKey= "$storagekey"
          };
          TimeZone = "Eastern Standard Time";
          DomainComponentPath = "$domainname";
          Search= @{
            ServiceKey = "$azsearchkey";
            searchEngineUrl = "$azsearchuri"
          };
          messageHub = @{
            ConnectionString = "$connectionstring"
          };
          Suite= @{
            DB= @{
              Server = "$dbvmname"
            }
          };
          App = @{
            Server= "$appvmname"
          };
          reportServer = "$dbvmname";
          Insights= @{
            DQMailUser= @{
              Name = "DWS$CustomerID\$apppoolusername";
              Password = "$apppoolpassword"
            };
            DB= @{
              Server= "$dbinsightsvm"
            }
          }
        }

ConvertTo-Json -InputObject $Body | Out-File $env:BUILD_ARTIFACTSTAGINGDIRECTORY/$organizationName.json
