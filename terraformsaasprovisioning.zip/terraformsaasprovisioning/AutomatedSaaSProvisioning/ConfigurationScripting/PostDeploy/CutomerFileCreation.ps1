param 
(
    [Parameter(Mandatory=$true)][string]$ClientSPApplicationId,
    [Parameter(Mandatory=$true)][string]$ClientSPSecret,
    [Parameter(Mandatory=$true)][string]$ClientTenantID,
    [Parameter(Mandatory=$true)][string]$ClientSubscriptionID,
    [Parameter(Mandatory=$true)][string]$CustomerId,
    [Parameter(Mandatory=$true)][string]$RepoPAT,
    [Parameter(Mandatory=$true)][string]$RepoURL,
    [Parameter(Mandatory=$true)][string]$displayName,
    [Parameter(Mandatory=$true)][string]$mailNickname,
    [Parameter(Mandatory=$true)][string]$apppoolmailNickname
)

$securesecret = $ClientSPSecret | ConvertTo-SecureString -AsPlainText -Force
$cred = New-Object -TypeName PSCredential -ArgumentList $ClientSPapplicationId, $securesecret
Clear-AzContext -Force
Connect-AzAccount -ServicePrincipal -Credential $cred -Tenant $ClientTenantID
Set-AzContext -SubscriptionId $ClientSubscriptionID 
$Groupname = "AAD DC Administrators"
#Install-Module -Name AzureAD -Force
#User Creation and assigning role's to that user.

$apppooldisplayname = $CustomerId + "APP.POOL"

$response = $null

# Define AppId, secret and scope, your tenant name and endpoint URL
$Scope = "https://graph.microsoft.com/.default"

$Url = "https://login.microsoftonline.com/$ClientTenantID/oauth2/v2.0/token"

# Add System.Web for urlencode
Add-Type -AssemblyName System.Web

# Create body
$Body = @{
    client_id = $ClientSPApplicationId
    client_secret = $ClientSPSecret
    scope = $Scope
    grant_type = 'client_credentials'
}

# Splat the parameters for Invoke-Restmethod for cleaner code
$PostSplat = @{
    ContentType = 'application/x-www-form-urlencoded'
    Method = 'POST'
    # Create string by joining bodylist with '&'
    Body = $Body
    Uri = $Url
}
# Request the token!
$Request = Invoke-RestMethod @PostSplat
#$Request
# Create header
$Header = @{
    Authorization = "$($Request.token_type) $($Request.access_token)"
}

function Get-GroupId {
    param 
    (
        [string] $token,
        [string] $groupname
    )

    $Header = @{
        Authorization = "Bearer $token"
        ConsistencyLevel = "eventual"
    }

    $listGroupGraphurl = "https://graph.microsoft.com/v1.0/groups?`$search=`"displayName:$groupname`"&`$count=true&`$select=id,displayName&`$top=1"
    $r = Invoke-RestMethod -Headers $Header -Method Get -Uri $listGroupGraphurl 
    if($r.'@odata.count' -gt 0){
        return $r.value.id
    }
    else{
        return $null
    }

}
Function GeneratePassword
{
    $MinimumPasswordLength = 12
    $MaximumPasswordLength = 16
    $PasswordLength = Get-Random -InputObject ($MinimumPasswordLength..$MaximumPasswordLength)
    $AllowedPasswordCharacters = [char[]]'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!'
    $Regex = "(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*\W)"

    do {
            $Password = ([string]($AllowedPasswordCharacters |
            Get-Random -Count $PasswordLength) -replace ' ')
       }    until ($Password -cmatch $Regex)

    return $Password

}

$username = "$displayName@dws$CustomerId.onmicrosoft.com"
$apppoolusername = "$apppooldisplayname@dws$CustomerId.onmicrosoft.com"


$filepath = "$CustomerId.json"
#create lab user creation
try{
    $GetUserGraphUrl = "https://graph.microsoft.com/v1.0/users/$username"
    $apires = Invoke-RestMethod -Headers $Header -Method GET -Uri $GetUserGraphUrl -ContentType application/json 
    Write-Host "User Already Exists"
    git clone -b master https://$RepoPAT@$RepoURL
    cd "Developer%20Workstations/Artifacts/ConfigureWorkstation"
    ls
    $domainpassword = (Get-Content -Path $filepath -Raw) |  ConvertFrom-Json
    $domainpassword = $domainpassword.azurePortal.password

    $GetapppoolUserGraphUrl = "https://graph.microsoft.com/v1.0/users/$apppoolusername"
    $apires = Invoke-RestMethod -Headers $Header -Method GET -Uri $GetapppoolUserGraphUrl -ContentType application/json 
    Write-Host "User Already Exists"
    git clone -b master https://$RepoPAT@$RepoURL
    cd "Developer%20Workstations/Artifacts/ConfigureWorkstation"
    ls
    $apppoolpwd = (Get-Content -Path $filepath -Raw) |  ConvertFrom-Json
    $apppoolpwd = $apppoolpwd.apppool.password

    Write-Host "##vso[task.setvariable variable=domainusername;]$username"
    Write-Host "##vso[task.setvariable variable=domainpassword;]$domainpassword"
    Write-Host "##vso[task.setvariable variable=apppooluser;]$apppoolusername"
    Write-Host "##vso[task.setvariable variable=apppoolpwd;]$apppoolpwd"
    Write-Host "##vso[task.setvariable variable=apppooldisplay;]$apppooldisplayname"
    
}
catch{
    $password = GeneratePassword
    $createUserGraphUrl = "https://graph.microsoft.com/v1.0/users"
    $createUserBody = '{
    "accountEnabled": true,
    "displayName": "'+ $displayName  +'",
    "mailNickname": "'+ $mailNickname +'",
    "userPrincipalName": "'+ $username +'",
    "passwordProfile" : {
        "forceChangePasswordNextSignIn": false,
        "password": "'+ $password +'"
    }
    }'
    Write-Host -Debug $password
    #create lab user
    $response = Invoke-RestMethod -Headers $Header -Method Post -Uri $createUserGraphUrl -ContentType application/json -Body $createUserBody
    $userobjectid = $response.id

    $groupobjectid = Get-GroupId -token $Request.access_token -groupname $Groupname
    $addMemberToGroupGraphUrl = 'https://graph.microsoft.com/v1.0/groups/' + $groupobjectid + '/members/$ref'
    $addMemberBody = @{ "@odata.id" = "https://graph.microsoft.com/v1.0/directoryObjects/$userobjectid" }
    $addMemberBody = $addMemberBody | ConvertTo-Json
    Invoke-RestMethod -Headers $Header -Method Post -Uri $addMemberToGroupGraphUrl -ContentType application/json -Body $addMemberBody                 
     $contributorroleid = (Get-AzRoleDefinition -Name "Contributor").Id
    New-AzRoleAssignment -ObjectId $userobjectid -RoleDefinitionId $contributorroleid -Scope "/subscriptions/$ClientSubscriptionID"
    $useracessadministratorrole = (Get-AzRoleDefinition -Name "User Access Administrator").Id
    New-AzRoleAssignment -ObjectId $userobjectid -RoleDefinitionId $useracessadministratorrole -Scope "/subscriptions/$ClientSubscriptionID"

    #create apppool user
    $apppoolpassword = GeneratePassword
    $createapppoolUserGraphUrl = "https://graph.microsoft.com/v1.0/users"
    $createapppoolUserBody = '{
    "accountEnabled": true,
    "displayName": "'+ $apppooldisplayname  +'",
    "mailNickname": "'+ $apppoolmailNickname +'",
    "userPrincipalName": "'+ $apppoolusername +'",
    "passwordProfile" : {
        "forceChangePasswordNextSignIn": false,
        "password": "'+ $apppoolpassword +'"
    }
    }'

    $apppooluser = Invoke-RestMethod -Headers $Header -Method Post -Uri $createapppoolUserGraphUrl -ContentType application/json -Body $createapppoolUserBody
    $apppoolobjectid = $apppooluser.id

    $groupobjectid = Get-GroupId -token $Request.access_token -groupname $Groupname
    $addMemberToGroupGraphUrl = 'https://graph.microsoft.com/v1.0/groups/' + $groupobjectid + '/members/$ref'
    $addMemberBody = @{ "@odata.id" = "https://graph.microsoft.com/v1.0/directoryObjects/$apppoolobjectid" }
    $addMemberBody = $addMemberBody | ConvertTo-Json
    Invoke-RestMethod -Headers $Header -Method Post -Uri $addMemberToGroupGraphUrl -ContentType application/json -Body $addMemberBody                 
     $contributorroleid = (Get-AzRoleDefinition -Name "Contributor").Id
    New-AzRoleAssignment -ObjectId $apppoolobjectid -RoleDefinitionId $contributorroleid -Scope "/subscriptions/$ClientSubscriptionID"
    $useracessadministratorrole = (Get-AzRoleDefinition -Name "User Access Administrator").Id
    New-AzRoleAssignment -ObjectId $apppoolobjectid -RoleDefinitionId $useracessadministratorrole -Scope "/subscriptions/$ClientSubscriptionID"

    #Customer File Creation.

    $storageaccountrgname = "rg-ODW-DC-RG"

    $resourcegroup = (Get-AzResourceGroup | Where-Object {$_.ResourceGroupName -eq $storageaccountrgname}).ResourceGroupName

    $storageAcctName = "saodw"+$CustomerId

    $context  = (Get-AzStorageAccount -Name $storageAcctName -ResourceGroupName $resourcegroup).Context

    $filestoreuri = $context.FileEndPoint
    $filestoreuri = $filestoreuri -replace 'https://','' -replace '/' ,''

    $storagekey = (Get-AzStorageAccountKey -ResourceGroupName $resourcegroup -AccountName $storageAcctName)[0].Value

    $filesharename = "dtlenv-fileshare"


    $Body = @{
        company= "WestField"

        fileStore= @{
        URI="$filestoreuri";
        user= 'Azure\' + $storageAcctName;
        pass= "$storagekey";
        name= "$filesharename"
        };
        repository= @{
        URI= "dev.azure.com/dws$CustomerId/DuckCreekSuite/_git/DuckCreek";
        user= 'dws' + $CustomerId;
        token= "$RepoPAT"
        };
        azurePortal= @{
        user= "$username";
        password= "$Password";
        tenantId= "$ClientTenantID";
        subscriptionId= "$ClientSubscriptionID"
        };
        apppool = @{
        user = "$apppoolusername";
        password = "$apppoolpassword"
        }
        }

    #Copy files to hosted agent.
    ConvertTo-Json -InputObject $Body | Out-File $env:BUILD_ARTIFACTSTAGINGDIRECTORY/$CustomerId.json

    #Copy Customer file to the Repo.

    git config --global user.email "ajay.manthena@aggne.com"
    git config --global user.name "ajay"

    git clone -b master https://$RepoPAT@$RepoURL

    ls

    cd "Developer%20Workstations/Artifacts/ConfigureWorkstation"

    Copy-Item $env:BUILD_ARTIFACTSTAGINGDIRECTORY\$CustomerId.json

    cd ..

    cd PostDeployConfig

    Copy-Item $env:BUILD_ARTIFACTSTAGINGDIRECTORY\$CustomerId.json

    cd ..

    git add .

    git commit -m "Adding New Customer File In Artifact Repo"

    git push


    Write-Host "##vso[task.setvariable variable=domainusername;]$username"
    Write-Host "##vso[task.setvariable variable=domainpassword;]$password"
    Write-Host "##vso[task.setvariable variable=apppooluser;]$apppoolusername"
    Write-Host "##vso[task.setvariable variable=apppoolpwd;]$apppoolpassword"
    Write-Host "##vso[task.setvariable variable=apppooldisplay;]$apppooldisplayname"

}