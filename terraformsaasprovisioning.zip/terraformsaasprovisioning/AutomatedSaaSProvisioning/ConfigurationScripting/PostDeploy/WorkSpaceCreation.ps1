param(
    [Parameter(Mandatory=$true)][string]$accesstoken,
    [Parameter(Mandatory=$true)][string]$CustomerId,
    [Parameter(Mandatory=$true)][string]$Orgname,
    [Parameter(Mandatory=$true)][string]$envname

)

$version = "1.0.6" 
$WorkspaceNamendc = "WS-$CustomerId-DQA-NDC-$envname"
$WorkspaceNamedc = "WS-$CustomerId-DQA-DC-$envname"
$workingdirectoryDQANDC = "Workspaces/WS-DQA-NDC-ENVX"
$workingdirectoryDQADC = "Workspaces/WS-DQA-DC-ENVX"

$Header = @{
    "authorization" = "Bearer $accesstoken"
 }
 
$Bodyndc = '{
    "data": {
      "attributes": {
        "name": "' + $WorkspaceNamendc + '",
        "resource-count": 0,
        "terraform_version": "' + $version + '",
        "working-directory": "' + $workingdirectoryDQANDC + '",
        "updated-at": "2017-11-29T19:18:09.976Z"
      },
      "type": "workspaces"
    }
  }' 


$Parameters = @{
Method      = "POST"
Uri         = "https://app.terraform.io/api/v2/organizations/$Orgname/workspaces"
Headers     = $Header
ContentType = "application/vnd.api+json"
Body        = $Bodyndc
}
Invoke-RestMethod @Parameters 


$Bodydc = '{
  "data": {
    "attributes": {
      "name": "' + $WorkspaceNamedc + '",
      "resource-count": 0,
      "terraform_version": "' + $version + '",
      "working-directory": "' + $workingdirectoryDQADC + '",
      "updated-at": "2017-11-29T19:18:09.976Z"
    },
    "type": "workspaces"
  }
}' 


$Parameters = @{
Method      = "POST"
Uri         = "https://app.terraform.io/api/v2/organizations/$Orgname/workspaces"
Headers     = $Header
ContentType = "application/vnd.api+json"
Body        = $Bodydc
}
Invoke-RestMethod @Parameters 