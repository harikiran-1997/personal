
param(
    [Parameter(Mandatory=$true)][string]$SourceSubID,
    [Parameter(Mandatory=$true)][string]$TargetsubID,
    [Parameter(Mandatory=$true)][string]$MasterServiceprincipalAppId,
    [Parameter(Mandatory=$true)][string]$MasterServiceprincipalAppSecret,
    [Parameter(Mandatory=$true)][string]$MasterTenantId,
    [Parameter(Mandatory=$true)][string]$sourcegalleryrg,
    [Parameter(Mandatory=$true)][string]$SharedGalleryName,
    [Parameter(Mandatory=$true)][string]$imagedef,
    [Parameter(Mandatory=$true)][string]$location,
    [Parameter(Mandatory=$true)][string]$ImageVersion
)

$targetgalleryrg = "rg-SIG-RG"
$version = $ImageVersion
$securesecret = $MasterServiceprincipalAppSecret | ConvertTo-SecureString -AsPlainText -Force

$cred = New-Object -TypeName PSCredential -ArgumentList $MasterServiceprincipalAppId, $securesecret

Clear-AzContext -Force
Connect-AzAccount -ServicePrincipal -Credential $cred -Tenant $MasterTenantId

Set-AzContext -SubscriptionId $TargetsubID | out-Null

$getrgname = Get-AzResourceGroup -Name $targetgalleryrg -ErrorAction SilentlyContinue
if($getrgname){
    Write-Host "Resource Group Already Exists"
}
else{
    New-AzResourceGroup -Name $targetgalleryrg -Location $location -Force
}

$resourcegroupname = Get-AzResourceGroup -Name $targetgalleryrg
echo "$resourcegroupname"

#Creation of image gallery
$ErrorActionPreference = 'SilentlyContinue'
$getgallery = (Get-AzGallery -ResourceId "/subscriptions/$TargetsubID/resourceGroups/$targetgalleryrg/providers/Microsoft.Compute/galleries/$SharedGalleryName").Name
if($getgallery){
    Write-Verbose -Message "gallery exists" -Verbose
    $gallery = Get-AzGallery -ResourceId "/subscriptions/$TargetsubID/resourceGroups/$targetgalleryrg/providers/Microsoft.Compute/galleries/$SharedGalleryName"
}
else{
    $gallery = New-AzGallery -GalleryName $SharedGalleryName -ResourceGroupName $resourcegroupname.ResourceGroupName -Location $resourcegroupname.Location -Description 'Shared Image Gallery for my organization'
}

Set-AzContext -SubscriptionId $SourceSubID | out-Null
$Sourceimagedefinitionlocation = (Get-AzGalleryImageDefinition -ResourceId "/subscriptions/$SourceSubID/resourceGroups/$sourcegalleryrg/providers/Microsoft.Compute/galleries/$SharedGalleryName/images/$imagedef").Location

#get the imagedefinition
$ErrorActionPreference = 'SilentlyContinue'
Set-AzContext -SubscriptionId $TargetsubID | out-Null
$getimagedefinition = (Get-AzGalleryImageDefinition -ResourceId "/subscriptions/$TargetsubID/resourceGroups/$targetgalleryrg/providers/Microsoft.Compute/galleries/$SharedGalleryName/images/$imagedef").Name
if($getimagedefinition){
    Write-Verbose -Message "imagedefinition  exists" -Verbose
}
else{
#Creation of image definition

    $Publisher = $imagedef + "publisher"
    $offer = $imagedef + "offer"
    $Sku = $imagedef + "sku"

    $galleryImage = New-AzGalleryImageDefinition `
       -GalleryName $SharedGalleryName `
       -ResourceGroupName $resourcegroupname.ResourceGroupName `
       -Location $Sourceimagedefinitionlocation `
       -Name $imagedef  `
       -OsState generalized `
       -OsType Windows `
       -Publisher $Publisher  `
       -Offer $Offer `
       -Sku $Sku
}

Set-AzContext -SubscriptionId $SourceSubID | out-Null
#Source imager version
$IMage = "/subscriptions/$SourceSubID/resourceGroups/$sourcegalleryrg/providers/Microsoft.Compute/galleries/$SharedGalleryName/images/$imagedef/versions/$version"
Set-AzContext -SubscriptionId $SourceSubID | out-Null
$imageversionlocation = (Get-AzGalleryImageVersion -ResourceId "/subscriptions/$SourceSubID/resourceGroups/$sourcegalleryrg/providers/Microsoft.Compute/galleries/$SharedGalleryName/images/$imagedef/versions/$version").Location
$SourceTargetRegion = (Get-AzGalleryImageVersion -ResourceId "/subscriptions/$SourceSubID/resourceGroups/$sourcegalleryrg/providers/Microsoft.Compute/galleries/$SharedGalleryName/images/$imagedef/versions/$version").PublishingProfile.TargetRegions
$SourceTargetRegion.Count
$targetRegions = @()
$count = 0
foreach ($sigregion in $SourceTargetRegion) {
    $count++
    New-Variable -Name "'regions'+$count" -Value $sigregion.name -Force
    New-Variable -Name "'replicacount'+$count" -Value $sigregion.regionalreplicacount -Force
    ${'regions'+$count} = @{Name= (Get-Variable -Name "'regions'+$count").Value ;ReplicaCount=(Get-Variable -Name "'replicacount'+$count").Value}
    $targetRegions += ${'regions'+$count}
}
echo "******$targetRegions******"


Set-AzContext -SubscriptionId $TargetsubID | out-Null
$ErrorActionPreference = 'SilentlyContinue'
$getversion = (Get-AzGalleryImageVersion -ResourceId "/subscriptions/$TargetsubID/resourceGroups/$targetgalleryrg/providers/Microsoft.Compute/galleries/$SharedGalleryName/images/$imagedef/versions/$version").Name
if($getversion){
    Write-Verbose -Message "version  exists" -Verbose
}
else{
    
    # creating image version in destination
    New-AzGalleryImageVersion `
    -GalleryImageDefinitionName $imagedef `
    -GalleryImageVersionName $version `
    -GalleryName $SharedGalleryName `
    -ResourceGroupName $targetgalleryrg `
    -Location $imageversionlocation `
    -TargetRegion $targetRegions `
    -Source $IMage
    

}
