param(
    [Parameter(Mandatory = $true)][string]$ClientSPApplicationId,
    [Parameter(Mandatory = $true)][string]$ClientSPSecret,
    [Parameter(Mandatory = $true)][string]$ClientTenantID,
    [Parameter(Mandatory = $true)][string]$ClientSubscriptionID,
    [Parameter(Mandatory = $true)][string]$location,
    [Parameter(Mandatory = $true)][int]$ContractedNumberofWorkstations,
    [Parameter(Mandatory = $true)][string]$service

)

$securesecret = $ClientSPSecret | ConvertTo-SecureString -AsPlainText -Force
$cred = New-Object -TypeName PSCredential -ArgumentList $ClientSPApplicationId, $securesecret
Clear-AzContext -Force
Connect-AzAccount -ServicePrincipal -Credential $cred -Tenant $ClientTenantID
Set-AzContext -SubscriptionId $ClientSubscriptionID

if ($ContractedNumberofWorkstations.count -eq 0){
    
    $ContractedNumberofWorkstations = 200
}else{

    $ContractedNumberofWorkstations = 200+$ContractedNumberofWorkstations*4
}

$token =Invoke-RestMethod -Uri https://login.microsoftonline.com/$ClientTenantID/oauth2/token?api-version=1.0 -Method Post -Body @{"grant_type" = "client_credentials"; "resource" = "https://management.core.windows.net/"; "client_id" = "$ClientSPApplicationId"; "client_secret" = "$ClientSPSecret"}
$accesstoken = $token.access_token   
 
$Header = @{
   "authorization" = "Bearer $accesstoken"
}

#Registring Resource Providers.
$Providernamespaces = @("Microsoft.Compute","Microsoft.Capacity")

foreach($Names in $Providernamespaces){

    $Providers = @{
    Method      = "POST"
    Uri         = "https://management.azure.com/subscriptions/$ClientSubscriptionID/providers/$Names/register?api-version=2021-04-01"
    Headers     = $Header
    ContentType = "application/json"
    }
Invoke-RestMethod @Providers 
}

Start-Sleep -Seconds 60

$Body = '{ 
            "properties": { 
            "limit": ' + $ContractedNumberofWorkstations + ',
            "unit": "Count", 
            "name": { 
            "value": "' + $service + '"
            } 
            } 
        }' 
#sending an request to increase quota limit.
$Parameters = @{
    Method      = "PATCH"
    Uri         = "https://management.azure.com/subscriptions/$ClientSubscriptionID/providers/Microsoft.Capacity/resourceProviders/Microsoft.Compute/locations/$location/serviceLimits/$service"+"?api-version=2019-07-19-preview"
    Headers     = $Header
    ContentType = "application/json"
    Body        = $Body
}
Invoke-RestMethod @Parameters 
