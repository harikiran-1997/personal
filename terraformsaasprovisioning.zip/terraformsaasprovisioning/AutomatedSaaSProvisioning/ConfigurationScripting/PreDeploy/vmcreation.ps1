param(
    [Parameter(Mandatory=$true)][string]$ClientSPApplicationId,
    [Parameter(Mandatory=$true)][string]$ClientSPSecret,
    [Parameter(Mandatory=$true)][string]$ClientTenantID,
    [Parameter(Mandatory=$true)][string]$ClientSubscriptionID,
    [Parameter(Mandatory=$true)][string]$LabName,
    [Parameter(Mandatory=$true)][string]$galleryName,
    [Parameter(Mandatory=$true)][string]$imagename
)

$securesecret = $ClientSPSecret | ConvertTo-SecureString -AsPlainText -Force
$scriptpath = $PSScriptRoot
$cred = New-Object -TypeName PSCredential -ArgumentList $ClientSPApplicationId, $securesecret


Clear-AzContext -Force
Connect-AzAccount -ServicePrincipal -Credential $cred -Tenant $ClientTenantID
Set-AzContext -SubscriptionId $ClientSubscriptionID

$RGName = "rg-ODW-NDC-RG"
$vmname = "labvm"
$labVirtualNetworkName = "vn-ODW-NDC-VNET"
$labSubnetName = "ODW-NDC-SUBNET"
$ErrorActionPreference = 'SilentlyContinue'
$getvm = (Get-AzVM -ResourceGroupName $RGName -Name $vmname).Name
if($getvm){
     Write-Verbose -Message "vm already exists" -Verbose
}
else{
    New-AzResourceGroupDeployment `
        -ResourceGroupName $RGName `
        -TemplateFile "$scriptpath\Vmcreation.json" `
        -TemplateParameterFile "$scriptpath\vmcreationparameters.json" `
        -LabName $LabName `
        -imagename $imagename `
        -galleryName $galleryName `
        -labVirtualNetworkName $labVirtualNetworkName `
        -labSubnetName $labSubnetName

}
