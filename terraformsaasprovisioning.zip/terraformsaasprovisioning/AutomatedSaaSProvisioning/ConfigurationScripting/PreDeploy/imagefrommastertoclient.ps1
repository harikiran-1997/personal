param(

    [Parameter(Mandatory=$true)][string]$applicationId,
    [Parameter(Mandatory=$true)][string]$secret,
    [Parameter(Mandatory=$true)][string]$tenant1,
    [Parameter(Mandatory=$true)][string]$sourcegalleryrg,
    [Parameter(Mandatory=$true)][string]$SharedGalleryName,
    [Parameter(Mandatory=$true)][string]$imagedef,
    [Parameter(Mandatory=$true)][string]$version,
    [Parameter(Mandatory=$true)][string]$SourceSubID,
    [Parameter(Mandatory=$true)][string]$TargetsubID,
    [Parameter(Mandatory=$true)][string]$targetgalleryrg,
    [Parameter(Mandatory=$true)][string]$targetSigname

)

$securesecret = $secret | ConvertTo-SecureString -AsPlainText -Force
$cred = New-Object -TypeName PSCredential -ArgumentList $applicationId, $securesecret
Clear-AzContext -Force
Connect-AzAccount -ServicePrincipal -Credential $cred -Tenant $tenant1
Set-AzContext -SubscriptionId $TargetsubID | out-Null

$resourcegroupname = Get-AzResourceGroup -Name $targetgalleryrg

$ErrorActionPreference = 'SilentlyContinue'
$gallery = Get-AzGallery -ResourceId "/subscriptions/$TargetsubID/resourceGroups/$targetgalleryrg/providers/Microsoft.Compute/galleries/$targetSigname"
if($gallery.Name -EQ $targetSigname){
    Write-Verbose -Message "gallery exists" -Verbose
}
else{
    $gallery = New-AzGallery -GalleryName $targetSigname -ResourceGroupName $resourcegroupname.ResourceGroupName -Location $resourcegroupname.Location -Description 'Shared Image Gallery for my organization'
}

Set-AzContext -SubscriptionId $SourceSubID | out-Null
$Sourceimagedefinitionlocation = (Get-AzGalleryImageDefinition -ResourceId "/subscriptions/$SourceSubID/resourceGroups/$sourcegalleryrg/providers/Microsoft.Compute/galleries/$SharedGalleryName/images/$imagedef").Location


#get the imagedefinition
$ErrorActionPreference = 'SilentlyContinue'
Set-AzContext -SubscriptionId $TargetsubID | out-Null
$getimagedefinition = (Get-AzGalleryImageDefinition -ResourceId "/subscriptions/$TargetsubID/resourceGroups/$targetgalleryrg/providers/Microsoft.Compute/galleries/$targetSigname/images/$imagedef").Name
if($getimagedefinition){
    Write-Verbose -Message "imagedefinition  exists" -Verbose 
}
else{
#Creation of image definition

    $Publisher = $imagedef + "publisher"
    $offer = $imagedef + "offer"
    $Sku = $imagedef + "sku"

    $galleryImage = New-AzGalleryImageDefinition `
       -GalleryName $targetSigname `
       -ResourceGroupName $resourcegroupname.ResourceGroupName `
       -Location $Sourceimagedefinitionlocation `
       -Name $imagedef  `
       -OsState generalized `
       -OsType Windows `
       -Publisher $Publisher  `
       -Offer $Offer `
       -Sku $Sku
}


Set-AzContext -SubscriptionId $SourceSubID | out-Null
$IMage = "/subscriptions/$SourceSubID/resourceGroups/$sourcegalleryrg/providers/Microsoft.Compute/galleries/$SharedGalleryName/images/$imagedef/versions/$version"
$imageversionlocation = (Get-AzGalleryImageVersion -ResourceId "/subscriptions/$SourceSubID/resourceGroups/$sourcegalleryrg/providers/Microsoft.Compute/galleries/$SharedGalleryName/images/$imagedef/versions/$version").Location
$SourceTargetRegion = (Get-AzGalleryImageVersion -ResourceId "/subscriptions/$SourceSubID/resourceGroups/$sourcegalleryrg/providers/Microsoft.Compute/galleries/$SharedGalleryName/images/$imagedef/versions/$version").PublishingProfile.TargetRegions
$targetRegions = @()
$count = 0
foreach ($sigregion in $SourceTargetRegion) {
    $count++
    New-Variable -Name "'regions'+$count" -Value $sigregion.name -Force
    New-Variable -Name "'replicacount'+$count" -Value $sigregion.regionalreplicacount -Force
    ${'regions'+$count} = @{Name= (Get-Variable -Name "'regions'+$count").Value ;ReplicaCount=(Get-Variable -Name "'replicacount'+$count").Value}
    $targetRegions += ${'regions'+$count}
}

Set-AzContext -SubscriptionId $TargetsubID | out-Null

$ErrorActionPreference = 'SilentlyContinue'
$getversion = (Get-AzGalleryImageVersion -ResourceId "/subscriptions/$TargetsubID/resourceGroups/$targetgalleryrg/providers/Microsoft.Compute/galleries/$targetSigname/images/$imagedef/versions/$version").Name
if($getversion){
    Write-Verbose -Message "version  exists" -Verbose
}
else{
$job = New-AzGalleryImageVersion `
-GalleryImageDefinitionName $imagedef `
-GalleryImageVersionName $version `
-GalleryName $targetSigname `
-ResourceGroupName $targetgalleryrg `
-Location $imageversionlocation `
-TargetRegion $targetRegions `
-Source $IMage
}
