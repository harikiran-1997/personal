param(
    [Parameter(Mandatory=$true)][string]$ClientSPApplicationId,
    [Parameter(Mandatory=$true)][string]$ClientSPSecret,
    [Parameter(Mandatory=$true)][string]$location,
    [Parameter(Mandatory=$true)][string]$ClientTenantID,
    [Parameter(Mandatory=$true)][string]$ClientSubscriptionID,
    [Parameter(Mandatory=$true)][string]$labvnetrange,
    [Parameter(Mandatory=$true)][string]$labsubnetrange,
    [Parameter(Mandatory=$true)][string]$gatewaysubnetrange,
    [Parameter(Mandatory=$true)][string]$bastionsubnetrange
)

$RGName = "rg-ODW-NDC-RG"
$VNETName = "vn-ODW-NDC-VNET"
$subnetName = "ODW-NDC-SUBNET"
$NsgName = "ns-ODW-NDC-NSG"

$securesecret = $ClientSPSecret | ConvertTo-SecureString -AsPlainText -Force
$cred = New-Object -TypeName PSCredential -ArgumentList $ClientSPApplicationId, $securesecret
Clear-AzContext -Force
Connect-AzAccount -ServicePrincipal -Credential $cred -Tenant $ClientTenantID

Set-AzContext -SubscriptionId $ClientSubscriptionID 

#Resourcegroup creation for devtestlab
$ResourceGroup = (Get-AzResourceGroup | Where-Object {$_.ResourceGroupName -eq $RGName}).ResourceGroupName
if($ResourceGroup -eq $null){
    New-AzResourceGroup -Name $RGName -Location $location -Force
}
else{
    Write-Host "Resource Group Already Exists"
}

$virtualNetwork = Get-AzVirtualNetwork -ResourceGroupName $RGName -Name $VNETName -ErrorAction SilentlyContinue
if($virtualNetwork){
   Write-Verbose -Message "vnet already exists" -Verbose
 
}
else{
    $virtualNetwork = New-AzVirtualNetwork -ResourceGroupName $RGName -Location $location -Name $VNETName -AddressPrefix $labvnetrange -Force
    Add-AzVirtualNetworkSubnetConfig -Name $subnetName -AddressPrefix $labsubnetrange -VirtualNetwork $virtualNetwork
    $virtualNetwork | Set-AzVirtualNetwork
    Add-AzVirtualNetworkSubnetConfig -Name 'GatewaySubnet' -AddressPrefix $gatewaysubnetrange -VirtualNetwork $virtualNetwork
    $virtualNetwork | Set-AzVirtualNetwork
    Add-AzVirtualNetworkSubnetConfig -Name 'AzureBastionSubnet' -AddressPrefix $bastionsubnetrange -VirtualNetwork $virtualNetwork
    $virtualNetwork | Set-AzVirtualNetwork

}
# Get virtual network 1.
$vnet1 = Get-AzVirtualNetwork -ResourceGroupName $RGName -Name $VNETName

# Get the adds vnet for vnet2 peering.
$vnet2 = Get-AzVirtualNetwork -ResourceGroupName "rg-FC-RG" -Name "vn-FC-AADDSVNET"

# Peer VNet1 to VNet2.
$ErrorActionPreference = 'SilentlyContinue'
$vnetpeering1 = (Get-AzVirtualNetworkPeering -VirtualNetwork $VNETName -ResourceGroupName $RGName).Name
if($vnetpeering1){
   Write-Verbose -Message "vnet1tovnet2 peering already exists" -Verbose
}
else{
    Add-AzVirtualNetworkPeering -Name ($VNETName + '-addsvnet' + '-PEER') -VirtualNetwork $vnet1 -RemoteVirtualNetworkId $vnet2.Id
}
# Peer VNet2 to VNet1.
$ErrorActionPreference = 'SilentlyContinue'
$vnetpeering2 = (Get-AzVirtualNetworkPeering -VirtualNetwork "vn-FC-AADDSVNET" -ResourceGroupName "rg-FC-RG").Name
if($vnetpeering2){
   Write-Verbose -Message "vnet2tovnet1 peering already exists" -Verbose
}
else{
    Add-AzVirtualNetworkPeering -Name ('addsvnet-' + $VNETName + '-PEER') -VirtualNetwork $vnet2 -RemoteVirtualNetworkId $vnet1.Id
}

# Nsg Creation
$ErrorActionPreference = 'SilentlyContinue'
$getnsg = (Get-AzNetworkSecurityGroup -Name $NsgName -ResourceGroupName $RGName).Name
if($getnsg){
     Write-Verbose -Message "Nsg  exists" -Verbose
}
else{

    $rdpRule = New-AzNetworkSecurityRuleConfig -Name rdp-rule -Description "Allow RDP" -Access Allow -Protocol Tcp -Direction Inbound -Priority 100 -SourceAddressPrefix 207.68.190.32/27,13.106.78.32/27,13.106.174.32/27,13.106.4.96/27,170.52.59.0/24,203.163.252.66/32,52.224.188.46,38.111.9.140 -SourcePortRange * -DestinationAddressPrefix * -DestinationPortRange 3389
    $networkSecurityGroup = New-AzNetworkSecurityGroup -ResourceGroupName $RGName -Location $location -Name $NsgName -SecurityRules $rdpRule
    Set-AzVirtualNetworkSubnetConfig -Name $subnetName -VirtualNetwork $virtualNetwork -AddressPrefix $labsubnetrange -NetworkSecurityGroup $networkSecurityGroup
    $virtualNetwork | Set-AzVirtualNetwork
}
