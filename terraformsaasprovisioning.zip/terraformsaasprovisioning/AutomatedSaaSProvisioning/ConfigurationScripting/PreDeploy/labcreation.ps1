param(
    [Parameter(Mandatory=$true)][string]$ClientSPApplicationId,
    [Parameter(Mandatory=$true)][string]$ClientSPSecret,
    [Parameter(Mandatory=$true)][string]$ClientTenantID,
    [Parameter(Mandatory=$true)][string]$ClientSubscriptionID,
    [Parameter(Mandatory=$true)][string]$LabName,
    [Parameter(Mandatory=$true)][string]$existingSharedGalleryName,
    [Parameter(Mandatory=$true)][string]$timeZoneId,
    [Parameter(Mandatory=$false)][string]$VMAutoShutdownTime,
    [parameter(Mandatory=$true)]$artifactRepoUri,
    [parameter(Mandatory=$true)]$artifactRepoBranch,
    [parameter(Mandatory=$true)]$artifactRepoFolder,
    [parameter(Mandatory=$true)]$artifactRepoSecurityToken
)

$RGName = "rg-ODW-NDC-RG"
$existingSubnetName = "ODW-NDC-SUBNET"
$existingvnetname = "vn-ODW-NDC-VNET"
$sharedImageRG = "rg-SIG-RG"
$labVmShutDownTime = $VMAutoShutdownTime

$scriptpath = $PSScriptRoot
$securesecret = $ClientSPSecret | ConvertTo-SecureString -AsPlainText -Force
$cred = New-Object -TypeName PSCredential -ArgumentList $ClientSPapplicationId, $securesecret
Clear-AzContext -Force
Connect-AzAccount -ServicePrincipal -Credential $cred -Tenant $ClientTenantID
Set-AzContext -SubscriptionId $ClientSubscriptionID 

$conversion = $artifactRepoSecurityToken | ConvertTo-SecureString -AsPlainText -Force

$ErrorActionPreference = 'SilentlyContinue'
$getlab = (Get-AzResource -ResourceId "/subscriptions/$ClientSubscriptionID/resourcegroups/$RGName/providers/microsoft.devtestlab/labs/$LabName").Name
if($getlab){
    Write-Verbose -Message "dtl already exists" -Verbose
}
else{
    Write-host "Lab Name = $LabName"
    New-AzResourceGroupDeployment `
        -ResourceGroupName $RGName `
        -TemplateFile "$scriptpath\labcreation.json" `
        -newLabName $LabName `
        -existingSharedGalleryName $existingSharedGalleryName `
        -Rgname $RGName `
        -sharedImageRG $sharedImageRG `
        -existingSubnetName $existingSubnetName `
        -existingvnetname $existingvnetname `
        -timeZoneId $timeZoneId `
        -labVmShutDownTime $labVmShutDownTime `
        -artifactRepoSecurityToken $conversion `
        -artifactRepositoryDisplayName "private artifact" `
        -repositoryName  "private repo" `
        -artifactRepoUri $artifactRepoUri `
        -artifactRepoBranch $artifactRepoBranch `
        -artifactRepoFolder $artifactRepoFolder `
        -artifactRepoType "VsoGit"
} 
